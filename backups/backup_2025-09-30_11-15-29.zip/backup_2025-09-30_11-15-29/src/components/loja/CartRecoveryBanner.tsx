import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, ShoppingCart, Clock, Gift, ArrowRight } from 'lucide-react';
import { useCartRecovery } from '@/hooks/useCartRecovery';
import { useNavigate } from 'react-router-dom';

const CartRecoveryBanner = () => {
  const { 
    showRecoveryBanner, 
    recoveryData, 
    restoreCart, 
    clearRecoveryData,
    setShowRecoveryBanner 
  } = useCartRecovery();
  const navigate = useNavigate();

  if (!showRecoveryBanner || !recoveryData) {
    return null;
  }

  const handleRestoreCart = () => {
    restoreCart();
    navigate('/carrinho');
  };

  const handleDismiss = () => {
    setShowRecoveryBanner(false);
  };

  const handleContinueShopping = () => {
    setShowRecoveryBanner(false);
    navigate('/loja');
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-md mx-auto">
      <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0">
              <ShoppingCart className="h-6 w-6" />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-semibold text-sm">Carrinho abandonado</h3>
                <Badge variant="secondary" className="text-xs bg-white/20 text-white">
                  {recoveryData.itemCount} item{recoveryData.itemCount > 1 ? 's' : ''}
                </Badge>
              </div>
              
              <p className="text-xs opacity-90 mb-3">
                Você tem {recoveryData.itemCount} item{recoveryData.itemCount > 1 ? 's' : ''} 
                no valor de R$ {recoveryData.totalValue.toFixed(2)} esperando por você!
              </p>
              
              <div className="flex items-center gap-2 text-xs opacity-75 mb-3">
                <Clock className="h-3 w-3" />
                <span>Não perca sua seleção especial</span>
              </div>
              
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  onClick={handleRestoreCart}
                  className="bg-white/20 hover:bg-white/30 text-white border-white/30 flex-1"
                >
                  <Gift className="h-3 w-3 mr-1" />
                  Restaurar
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={handleContinueShopping}
                  className="bg-white/10 hover:bg-white/20 text-white border-white/30"
                >
                  <ArrowRight className="h-3 w-3 mr-1" />
                  Continuar
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={handleDismiss}
                  className="text-white hover:bg-white/10 p-1"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CartRecoveryBanner;
