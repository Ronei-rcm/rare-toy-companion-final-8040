import { useState, useEffect, useCallback } from 'react';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/hooks/use-toast';
import { useSettings } from '@/contexts/SettingsContext';

interface CartRecoveryData {
  lastActivity: number;
  itemCount: number;
  totalValue: number;
  items: any[];
  hasShownBanner: boolean;
  hasShownEmailPrompt: boolean;
}

const CART_RECOVERY_KEY = 'muhlstore-cart-recovery';
const INACTIVITY_THRESHOLD = 5 * 60 * 1000; // 5 minutos (reserva)

export const useCartRecovery = () => {
  const { state } = useCart();
  const { toast } = useToast();
  const { settings } = useSettings();
  const [showRecoveryBanner, setShowRecoveryBanner] = useState(false);
  const [showEmailPrompt, setShowEmailPrompt] = useState(false);
  const [recoveryData, setRecoveryData] = useState<CartRecoveryData | null>(null);

  // Salvar dados do carrinho para recuperação
  const saveCartForRecovery = useCallback(() => {
    if (state.itens.length === 0) return;

    const data: CartRecoveryData = {
      lastActivity: Date.now(),
      itemCount: state.quantidadeTotal,
      totalValue: state.total,
      items: state.itens,
      hasShownBanner: false,
      hasShownEmailPrompt: false
    };

    try {
      localStorage.setItem(CART_RECOVERY_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Erro ao salvar dados de recuperação:', error);
    }
  }, [state.itens, state.quantidadeTotal, state.total]);

  // Carregar dados de recuperação
  const loadRecoveryData = useCallback(() => {
    try {
      const saved = localStorage.getItem(CART_RECOVERY_KEY);
      if (saved) {
        const data = JSON.parse(saved) as CartRecoveryData;
        setRecoveryData(data);
        return data;
      }
    } catch (error) {
      console.error('Erro ao carregar dados de recuperação:', error);
    }
    return null;
  }, []);

  // Verificar se deve mostrar banner de recuperação
  const checkRecoveryBanner = useCallback(() => {
    const data = loadRecoveryData();
    if (!data) return;

    const timeSinceLastActivity = Date.now() - data.lastActivity;
    if (!settings.cart_recovery_enabled) return;
    const shouldShowBanner = 
      timeSinceLastActivity > (settings.cart_recovery_banner_delay_ms || 120000) && 
      !data.hasShownBanner && 
      data.itemCount > 0;

    if (shouldShowBanner) {
      setShowRecoveryBanner(true);
      // Marcar como mostrado
      const updatedData = { ...data, hasShownBanner: true };
      localStorage.setItem(CART_RECOVERY_KEY, JSON.stringify(updatedData));
    }
  }, [loadRecoveryData]);

  // Verificar se deve mostrar prompt de email
  const checkEmailPrompt = useCallback(() => {
    const data = loadRecoveryData();
    if (!data) return;

    const timeSinceLastActivity = Date.now() - data.lastActivity;
    if (!settings.cart_recovery_enabled) return;
    const shouldShowEmailPrompt = 
      timeSinceLastActivity > (settings.cart_recovery_email_delay_ms || 600000) && 
      !data.hasShownEmailPrompt && 
      data.itemCount > 0;

    if (shouldShowEmailPrompt) {
      setShowEmailPrompt(true);
      // Marcar como mostrado
      const updatedData = { ...data, hasShownEmailPrompt: true };
      localStorage.setItem(CART_RECOVERY_KEY, JSON.stringify(updatedData));
    }
  }, [loadRecoveryData]);

  // Limpar dados de recuperação
  const clearRecoveryData = useCallback(() => {
    try {
      localStorage.removeItem(CART_RECOVERY_KEY);
      setRecoveryData(null);
      setShowRecoveryBanner(false);
      setShowEmailPrompt(false);
    } catch (error) {
      console.error('Erro ao limpar dados de recuperação:', error);
    }
  }, []);

  // Restaurar carrinho
  const restoreCart = useCallback(() => {
    if (!recoveryData) return;

    // Aqui você implementaria a lógica para restaurar o carrinho
    // Por enquanto, apenas mostramos uma mensagem
    toast({
      title: 'Carrinho restaurado! 🎉',
      description: `${recoveryData.itemCount} itens foram restaurados do seu carrinho anterior.`,
      duration: 5000
    });

    clearRecoveryData();
  }, [recoveryData, toast, clearRecoveryData]);

  // Salvar dados quando o carrinho muda
  useEffect(() => {
    if (state.itens.length > 0) {
      saveCartForRecovery();
    }
  }, [state.itens, saveCartForRecovery]);

  // Verificar recuperação na inicialização
  useEffect(() => {
    loadRecoveryData();
    checkRecoveryBanner();
    checkEmailPrompt();
  }, [loadRecoveryData, checkRecoveryBanner, checkEmailPrompt]);

  // Verificar periodicamente se deve mostrar banner
  useEffect(() => {
    const interval = setInterval(() => {
      checkRecoveryBanner();
      checkEmailPrompt();
    }, 30000); // Verificar a cada 30 segundos

    return () => clearInterval(interval);
  }, [checkRecoveryBanner, checkEmailPrompt]);

  // Limpar dados quando o carrinho é finalizado
  useEffect(() => {
    if (state.itens.length === 0) {
      clearRecoveryData();
    }
  }, [state.itens.length, clearRecoveryData]);

  return {
    showRecoveryBanner,
    showEmailPrompt,
    recoveryData,
    restoreCart,
    clearRecoveryData,
    setShowRecoveryBanner,
    setShowEmailPrompt
  };
};
