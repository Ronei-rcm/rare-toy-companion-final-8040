import { useState, useEffect, useRef } from 'react';

interface AccessibilityOptions {
  announceChanges?: boolean;
  skipToContent?: boolean;
  focusManagement?: boolean;
}

export const useAccessibility = (options: AccessibilityOptions = {}) => {
  const [announcements, setAnnouncements] = useState<string[]>([]);
  const [isKeyboardUser, setIsKeyboardUser] = useState(false);
  const [focusableElements, setFocusableElements] = useState<HTMLElement[]>([]);
  const announcementRef = useRef<HTMLDivElement>(null);

  // Detectar se o usuário está usando teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        setIsKeyboardUser(true);
      }
    };

    const handleMouseDown = () => {
      setIsKeyboardUser(false);
    };

    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handleMouseDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handleMouseDown);
    };
  }, []);

  // Gerenciar anúncios para screen readers
  useEffect(() => {
    if (announcements.length > 0 && announcementRef.current) {
      const lastAnnouncement = announcements[announcements.length - 1];
      announcementRef.current.textContent = lastAnnouncement;
      
      // Limpar após 3 segundos
      setTimeout(() => {
        setAnnouncements(prev => prev.slice(1));
      }, 3000);
    }
  }, [announcements]);

  // Anunciar mudanças para screen readers
  const announce = (message: string) => {
    if (options.announceChanges) {
      setAnnouncements(prev => [...prev, message]);
    }
  };

  // Gerenciar foco
  const focusElement = (element: HTMLElement | null) => {
    if (element && options.focusManagement) {
      element.focus();
    }
  };

  // Trap focus dentro de um container
  const trapFocus = (container: HTMLElement) => {
    const focusableElements = container.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    ) as NodeListOf<HTMLElement>;

    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            lastElement.focus();
            e.preventDefault();
          }
        } else {
          if (document.activeElement === lastElement) {
            firstElement.focus();
            e.preventDefault();
          }
        }
      }
    };

    container.addEventListener('keydown', handleKeyDown);
    firstElement?.focus();

    return () => {
      container.removeEventListener('keydown', handleKeyDown);
    };
  };

  // Gerar IDs únicos para elementos
  const generateId = (prefix: string) => {
    return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
  };

  // Verificar se elemento está visível na viewport
  const isElementVisible = (element: HTMLElement) => {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  };

  // Scroll suave para elemento
  const scrollToElement = (element: HTMLElement, behavior: ScrollBehavior = 'smooth') => {
    element.scrollIntoView({
      behavior,
      block: 'center',
      inline: 'nearest'
    });
  };

  // Verificar se deve reduzir movimento
  const prefersReducedMotion = () => {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  };

  // Gerar ARIA labels dinâmicos
  const generateAriaLabel = (element: string, context?: string) => {
    const baseLabel = element;
    return context ? `${baseLabel}, ${context}` : baseLabel;
  };

  // Gerenciar estado de loading para screen readers
  const announceLoading = (item: string) => {
    announce(`${item} carregando...`);
  };

  const announceLoaded = (item: string) => {
    announce(`${item} carregado com sucesso`);
  };

  const announceError = (item: string) => {
    announce(`Erro ao carregar ${item}`);
  };

  return {
    isKeyboardUser,
    announce,
    focusElement,
    trapFocus,
    generateId,
    isElementVisible,
    scrollToElement,
    prefersReducedMotion,
    generateAriaLabel,
    announceLoading,
    announceLoaded,
    announceError,
    announcementRef
  };
};

export default useAccessibility;
