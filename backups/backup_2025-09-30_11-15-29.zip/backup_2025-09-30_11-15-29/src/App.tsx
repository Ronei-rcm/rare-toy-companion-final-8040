
import React, { Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { CartProvider } from "@/contexts/CartContext";
import { UserProvider } from "@/contexts/UserContext";
import { HomeConfigProvider } from "@/contexts/HomeConfigContext";
import { SettingsProvider } from "@/contexts/SettingsContext";
import ProtectedRoute from '@/components/auth/ProtectedRoute';

const Index = React.lazy(() => import("./pages/Index"));
const Loja = React.lazy(() => import("./pages/Loja"));
const ProdutoDetalhe = React.lazy(() => import("./pages/ProdutoDetalhe"));
const Carrinho = React.lazy(() => import("./pages/Carrinho"));
const Destaques = React.lazy(() => import("./pages/Destaques"));
const Admin = React.lazy(() => import("./pages/admin/Admin"));
const Dashboard = React.lazy(() => import("./pages/admin/Dashboard"));
const Produtos = React.lazy(() => import("./pages/admin/Produtos"));
const InstagramIntegracao = React.lazy(() => import("./pages/admin/InstagramIntegracao"));
const Clientes = React.lazy(() => import("./pages/admin/Clientes"));
const Pedidos = React.lazy(() => import("./pages/admin/Pedidos"));
const WhatsAppGrupos = React.lazy(() => import("./pages/admin/WhatsAppGrupos"));
const HomeConfig = React.lazy(() => import("./pages/admin/HomeConfig"));
const NotFound = React.lazy(() => import("./pages/NotFound"));
const Colecoes = React.lazy(() => import("./pages/Colecoes"));
const ColecaoDetalhe = React.lazy(() => import("./pages/ColecaoDetalhe"));
const Login = React.lazy(() => import("./pages/auth/Login"));
const Cadastro = React.lazy(() => import("./pages/auth/Cadastro"));
const MinhaConta = React.lazy(() => import("./pages/cliente/MinhaConta"));
const Colecao = React.lazy(() => import("./pages/Colecao"));
const Mercado = React.lazy(() => import("./pages/Mercado"));
const Sobre = React.lazy(() => import("./pages/Sobre"));
const Eventos = React.lazy(() => import("./pages/Eventos"));
const EventosAdmin = React.lazy(() => import("./pages/admin/EventosAdmin"));
const ColecoesAdmin = React.lazy(() => import("./pages/admin/ColecoesAdmin"));
const ConfiguracoesAdmin = React.lazy(() => import("./pages/admin/Configuracoes"));
const RecuperacaoAdmin = React.lazy(() => import("./pages/admin/Recuperacao"));
const SobreAdmin = React.lazy(() => import("./pages/admin/SobreAdmin"));
const AdminLogin = React.lazy(() => import("./pages/admin/AdminLogin"));

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <UserProvider>
          <HomeConfigProvider>
            <SettingsProvider>
            <CartProvider>
              <Toaster />
              <Sonner />
              <Router>
          <Suspense fallback={<div className="p-6 text-sm text-muted-foreground">Carregando...</div>}>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/loja" element={<Loja />} />
              <Route path="/produto/:id" element={<ProdutoDetalhe />} />
              <Route path="/carrinho" element={<Carrinho />} />
              <Route path="/destaques" element={<Destaques />} />
              
              <Route path="/colecao" element={<Colecoes />} />
              <Route path="/colecao/:id" element={<ColecaoDetalhe />} />
              <Route path="/collection" element={<Colecao />} />
              <Route path="/marketplace" element={<Mercado />} />
              <Route path="/about" element={<Sobre />} />
              <Route path="/eventos" element={<Eventos />} />
              
              {/* Rotas de autenticação e conta do cliente */}
              <Route path="/auth/login" element={<Login />} />
              <Route path="/auth/cadastro" element={<Cadastro />} />
              <Route path="/minha-conta" element={<ProtectedRoute><MinhaConta /></ProtectedRoute>} />
              <Route path="/minha-conta/pedido/:id" element={<ProtectedRoute>{React.createElement(React.lazy(() => import('./pages/cliente/PedidoDetalhe')))}</ProtectedRoute>} />
              
              {/* Rota de login administrativo */}
              <Route path="/admin/login" element={<AdminLogin />} />
              
              {/* Rotas administrativas */}
              <Route path="/admin" element={<Admin />}>
                <Route index element={<Dashboard />} />
                <Route path="produtos" element={<Produtos />} />
                <Route path="colecoes" element={<ColecoesAdmin />} />
                <Route path="instagram" element={<InstagramIntegracao />} />
                <Route path="clientes" element={<Clientes />} />
                <Route path="pedidos" element={<Pedidos />} />
                <Route path="home-config" element={<HomeConfig />} />
                <Route path="whatsapp-grupos" element={<WhatsAppGrupos />} />
                <Route path="configuracoes" element={<ConfiguracoesAdmin />} />
                <Route path="recuperacao" element={<RecuperacaoAdmin />} />
                <Route path="eventos" element={<EventosAdmin />} />
                <Route path="sobre" element={<SobreAdmin />} />
              </Route>
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
          </Router>
            </CartProvider>
            </SettingsProvider>
          </HomeConfigProvider>
        </UserProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
