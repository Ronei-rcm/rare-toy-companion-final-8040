
import React, { useEffect, useState } from 'react';
import Layout from '@/components/layout/Layout';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import ClienteProfile from '@/components/cliente/ClienteProfile';
import PedidosTab from '@/components/cliente/PedidosTab';
import EnderecosTab from '@/components/cliente/EnderecosTab';
import FavoritosTab from '@/components/cliente/FavoritosTab';
import DadosTab from '@/components/cliente/DadosTab';
import { useUser } from '@/contexts/UserContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';

const MinhaConta = () => {
  const navigate = useNavigate();
  const { user, isLoading } = useUser() as any;
  const [activeTab, setActiveTab] = useState('pedidos');
  
  // Sincronizar aba via querystring (?tab=enderecos)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tab = params.get('tab');
    const stored = localStorage.getItem('minha_conta_tab');
    if (tab) setActiveTab(tab);
    else if (stored) setActiveTab(stored);
  }, []);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    params.set('tab', activeTab);
    const url = `${window.location.pathname}?${params.toString()}`;
    window.history.replaceState({}, '', url);
    try { localStorage.setItem('minha_conta_tab', activeTab); } catch {}
  }, [activeTab]);
   
  const handleLogout = () => {
    toast.success('Logout realizado com sucesso');
    navigate('/');
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'pedidos':
        return <PedidosTab />;
      case 'enderecos':
        return <EnderecosTab />;
      case 'favoritos':
        return <FavoritosTab />;
      case 'dados':
        return <DadosTab />;
      default:
        return <PedidosTab />;
    }
  };

  return (
    <Layout>
      <div className="container py-8">
        {!isLoading && !user && (
          <div className="mb-6 p-4 rounded-lg border bg-amber-50 text-amber-900 flex items-center justify-between">
            <div>
              <div className="font-semibold">Você não está logado</div>
              <div className="text-sm opacity-80">Faça login para acessar sua área do cliente.</div>
            </div>
            <Link to="/auth/login">
              <button className="px-4 py-2 rounded-md border bg-white hover:bg-amber-100">Ir para login</button>
            </Link>
          </div>
        )}
        <div className="mb-6 p-4 rounded-lg border bg-gradient-to-r from-muted/50 to-transparent">
          {isLoading ? (
            <div className="flex items-center gap-3">
              <Skeleton className="h-12 w-12 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-40" />
                <Skeleton className="h-3 w-64" />
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarImage src={user?.avatar_url} alt={user?.nome} />
                <AvatarFallback>{user?.nome ? user.nome.charAt(0).toUpperCase() : 'U'}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-semibold">{user?.nome || 'Visitante'}</div>
                <div className="text-sm text-muted-foreground">{user?.email || 'Sem e-mail cadastrado'}</div>
              </div>
            </div>
          )}
        </div>
        {user && (
        <div className="flex flex-col md:flex-row gap-8">
          <ClienteProfile 
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            handleLogout={handleLogout}
          />
          <div className="flex-1">
            {renderTabContent()}
          </div>
        </div>
        )}
      </div>
    </Layout>
  );
};

export default MinhaConta;
