const API = 'http://177.67.33.248:3001';

export function resolveImage(src?: string): string {
  if (!src) return '/placeholder.png';
  if (/^https?:\/\//i.test(src)) return src; // já é absoluta
  if (src.startsWith('/')) return `${API}${src}`; // caminho relativo
  return `${API}/lovable-uploads/${src}`; // nome puro do arquivo
}

export default resolveImage;


