import { Produto } from '@/types/produto';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

export interface CreateProductData {
  nome: string;
  descricao?: string;
  preco: number;
  imagemUrl?: string;
  categoria: string;
  estoque: number;
  status?: 'ativo' | 'inativo' | 'esgotado';
  destaque?: boolean;
  promocao?: boolean;
  lancamento?: boolean;
  avaliacao?: number;
  totalAvaliacoes?: number;
  faixaEtaria?: string;
  peso?: string;
  dimensoes?: string;
  material?: string;
  marca?: string;
  origem?: string;
  fornecedor?: string;
  codigoBarras?: string;
  dataLancamento?: string;
}

export interface UpdateProductData extends Partial<CreateProductData> {
  id: string;
}

export const productsApi = {
  // Buscar todos os produtos
  async getProducts(): Promise<Produto[]> {
    try {
      console.log('🔄 Buscando produtos...');
      const response = await fetch(`${API_BASE_URL}/produtos`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('✅ Produtos carregados:', data.length);
      return data;
    } catch (error) {
      console.error('❌ Erro ao buscar produtos:', error);
      throw error;
    }
  },

  // Buscar produto por ID
  async getProduct(id: string): Promise<Produto> {
    try {
      console.log('🔄 Buscando produto:', id);
      const response = await fetch(`${API_BASE_URL}/produtos/${id}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('✅ Produto carregado:', data);
      return data;
    } catch (error) {
      console.error('❌ Erro ao buscar produto:', error);
      throw error;
    }
  },

  // Criar novo produto
  async createProduct(productData: CreateProductData): Promise<Produto> {
    try {
      console.log('🔄 Criando produto:', productData.nome);
      const response = await fetch(`${API_BASE_URL}/produtos`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(productData),
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('✅ Produto criado:', data);
      return data;
    } catch (error) {
      console.error('❌ Erro ao criar produto:', error);
      throw error;
    }
  },

  // Atualizar produto
  async updateProduct(id: string, productData: Partial<CreateProductData>): Promise<Produto> {
    try {
      console.log('🔄 Atualizando produto:', id);
      const response = await fetch(`${API_BASE_URL}/produtos/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(productData),
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('✅ Produto atualizado:', data);
      return data;
    } catch (error) {
      console.error('❌ Erro ao atualizar produto:', error);
      throw error;
    }
  },

  // Deletar produto
  async deleteProduct(id: string): Promise<void> {
    try {
      console.log('🔄 Deletando produto:', id);
      const response = await fetch(`${API_BASE_URL}/produtos/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      console.log('✅ Produto deletado:', id);
    } catch (error) {
      console.error('❌ Erro ao deletar produto:', error);
      throw error;
    }
  },

  // Buscar produtos por categoria
  async getProductsByCategory(categoria: string): Promise<Produto[]> {
    try {
      console.log('🔄 Buscando produtos por categoria:', categoria);
      const response = await fetch(`${API_BASE_URL}/produtos/categoria/${encodeURIComponent(categoria)}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('✅ Produtos por categoria carregados:', data.length);
      return data;
    } catch (error) {
      console.error('❌ Erro ao buscar produtos por categoria:', error);
      throw error;
    }
  },

  // Buscar produtos em destaque
  async getFeaturedProducts(): Promise<Produto[]> {
    try {
      console.log('🔄 Buscando produtos em destaque...');
      const response = await fetch(`${API_BASE_URL}/produtos/destaque`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('✅ Produtos em destaque carregados:', data.length);
      return data;
    } catch (error) {
      console.error('❌ Erro ao buscar produtos em destaque:', error);
      throw error;
    }
  },
};
