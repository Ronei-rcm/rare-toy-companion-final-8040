import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@/types/user';
import { usersApi } from '@/services/users-api';

interface UserContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  updateUser: (userData: Partial<User>) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Simular usuário logado (em produção, viria do localStorage/token)
  useEffect(() => {
    // Por enquanto, vamos usar o primeiro usuário da lista como exemplo
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const users = await usersApi.getUsers();
        if (users.length > 0) {
          setUser(users[0]); // Usar o primeiro usuário como exemplo
        }
      } catch (error) {
        console.error('Erro ao carregar usuário:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  const updateUser = async (userData: Partial<User>) => {
    if (!user) return;

    try {
      setIsLoading(true);
      await usersApi.updateUser(user.id, {
        nome: userData.nome || user.nome,
        email: userData.email || user.email,
        avatar_url: userData.avatar_url || user.avatar_url,
        telefone: userData.telefone || user.telefone,
        endereco: userData.endereco || user.endereco,
        cidade: userData.cidade || user.cidade,
        estado: userData.estado || user.estado,
        cep: userData.cep || user.cep,
      });

      // Atualizar o usuário local
      setUser({ ...user, ...userData });
    } catch (error) {
      console.error('Erro ao atualizar usuário:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    // Em produção, remover token do localStorage
  };

  return (
    <UserContext.Provider value={{ user, setUser, updateUser, logout, isLoading }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
