import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Produto } from '@/types/produto';

export interface ItemCarrinho {
  id: string;
  produto: Produto;
  quantidade: number;
  dataAdicionado: Date;
}

export interface CarrinhoState {
  itens: ItemCarrinho[];
  total: number;
  quantidadeTotal: number;
  isOpen: boolean;
  isLoading: boolean;
}

// Ações
type CarrinhoAction =
  | { type: 'ADD_ITEM'; payload: { produto: Produto; quantidade?: number } }
  | { type: 'REMOVE_ITEM'; payload: { id: string } }
  | { type: 'UPDATE_QUANTITY'; payload: { id: string; quantidade: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'TOGGLE_CART' }
  | { type: 'SET_CART_OPEN'; payload: boolean }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'LOAD_CART'; payload: ItemCarrinho[] };

// Estado inicial
const initialState: CarrinhoState = {
  itens: [],
  total: 0,
  quantidadeTotal: 0,
  isOpen: false,
  isLoading: false,
};

// Reducer
function carrinhoReducer(state: CarrinhoState, action: CarrinhoAction): CarrinhoState {
  switch (action.type) {
    case 'ADD_ITEM': {
      const { produto, quantidade = 1 } = action.payload;
      const itemExistente = state.itens.find(item => item.produto.id === produto.id);
      
      let novosItens: ItemCarrinho[];
      
      if (itemExistente) {
        novosItens = state.itens.map(item =>
          item.produto.id === produto.id
            ? { ...item, quantidade: item.quantidade + quantidade }
            : item
        );
      } else {
        const novoItem: ItemCarrinho = {
          id: `${produto.id}-${Date.now()}`,
          produto,
          quantidade,
          dataAdicionado: new Date(),
        };
        novosItens = [...state.itens, novoItem];
      }
      
      return {
        ...state,
        itens: novosItens,
        total: calcularTotal(novosItens),
        quantidadeTotal: calcularQuantidadeTotal(novosItens),
      };
    }
    
    case 'REMOVE_ITEM': {
      const novosItens = state.itens.filter(item => item.id !== action.payload.id);
      return {
        ...state,
        itens: novosItens,
        total: calcularTotal(novosItens),
        quantidadeTotal: calcularQuantidadeTotal(novosItens),
      };
    }
    
    case 'UPDATE_QUANTITY': {
      const { id, quantidade } = action.payload;
      if (quantidade <= 0) {
        return carrinhoReducer(state, { type: 'REMOVE_ITEM', payload: { id } });
      }
      
      const novosItens = state.itens.map(item =>
        item.id === id ? { ...item, quantidade } : item
      );
      
      return {
        ...state,
        itens: novosItens,
        total: calcularTotal(novosItens),
        quantidadeTotal: calcularQuantidadeTotal(novosItens),
      };
    }
    
    case 'CLEAR_CART':
      return {
        ...state,
        itens: [],
        total: 0,
        quantidadeTotal: 0,
      };
    
    case 'TOGGLE_CART':
      return {
        ...state,
        isOpen: !state.isOpen,
      };
    
    case 'SET_CART_OPEN':
      return {
        ...state,
        isOpen: action.payload,
      };
    
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };
    
    case 'LOAD_CART':
      return {
        ...state,
        itens: action.payload,
        total: calcularTotal(action.payload),
        quantidadeTotal: calcularQuantidadeTotal(action.payload),
      };
    
    default:
      return state;
  }
}

// Funções auxiliares
function calcularTotal(itens: ItemCarrinho[]): number {
  return itens.reduce((total, item) => total + (item.produto.preco * item.quantidade), 0);
}

function calcularQuantidadeTotal(itens: ItemCarrinho[]): number {
  return itens.reduce((total, item) => total + item.quantidade, 0);
}

// Contexto
const CartContext = createContext<{
  state: CarrinhoState;
  dispatch: React.Dispatch<CarrinhoAction>;
  addItem: (produto: Produto, quantidade?: number) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantidade: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
  setCartOpen: (open: boolean) => void;
} | null>(null);

// Provider
export function CartProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(carrinhoReducer, initialState);
  const { toast } = useToast();

  // Carregar carrinho do localStorage na inicialização
  useEffect(() => {
    const carrinhoSalvo = localStorage.getItem('muhlstore-cart');
    if (carrinhoSalvo) {
      try {
        const itens = JSON.parse(carrinhoSalvo);
        // Converter dataAdicionado de string para Date
        const itensComData = itens.map((item: any) => ({
          ...item,
          dataAdicionado: new Date(item.dataAdicionado),
        }));
        dispatch({ type: 'LOAD_CART', payload: itensComData });
      } catch (error) {
        console.error('Erro ao carregar carrinho do localStorage:', error);
      }
    }
  }, []);

  // Salvar carrinho no localStorage sempre que mudar
  useEffect(() => {
    localStorage.setItem('muhlstore-cart', JSON.stringify(state.itens));
  }, [state.itens]);

  // Funções de conveniência
  const addItem = async (produto: Produto, quantidade = 1) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    // Simular delay de API
    await new Promise(resolve => setTimeout(resolve, 300));
    
    dispatch({ type: 'ADD_ITEM', payload: { produto, quantidade } });
    dispatch({ type: 'SET_LOADING', payload: false });
    dispatch({ type: 'SET_CART_OPEN', payload: true });
    
    toast({
      title: 'Item adicionado! 🎉',
      description: `${produto.nome} foi adicionado ao seu carrinho.`,
    });
  };

  const removeItem = (id: string) => {
    const item = state.itens.find(i => i.id === id);
    dispatch({ type: 'REMOVE_ITEM', payload: { id } });
    if (item) {
      toast({
        title: 'Item removido',
        description: `${item.produto.nome} foi removido do carrinho.`,
        variant: 'destructive',
      });
    }
  };

  const updateQuantity = (id: string, quantidade: number) => {
    const itemAtual = state.itens.find(i => i.id === id);
    dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantidade } });

    const produtoNome = itemAtual?.produto.nome;
    if (produtoNome) {
      toast({
        title: 'Quantidade atualizada',
        description: `${produtoNome}: ${quantidade} unidade(s)`,
      });
    }

    // Se a quantidade aumentou, garantir que o drawer esteja visível
    if (itemAtual && quantidade > itemAtual.quantidade) {
      dispatch({ type: 'SET_CART_OPEN', payload: true });
    }
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
    toast({
      title: 'Carrinho limpo',
      description: 'Todos os itens foram removidos do carrinho.',
    });
  };

  const toggleCart = () => {
    dispatch({ type: 'TOGGLE_CART' });
  };

  const setCartOpen = (open: boolean) => {
    dispatch({ type: 'SET_CART_OPEN', payload: open });
  };

  return (
    <CartContext.Provider
      value={{
        state,
        dispatch,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        toggleCart,
        setCartOpen,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

// Hook personalizado
export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart deve ser usado dentro de um CartProvider');
  }
  return context;
}
