
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Menu, X, ShoppingCart, Settings } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import CarrinhoDrawer from '@/components/loja/CarrinhoDrawer';
import { useHomeConfig } from '@/contexts/HomeConfigContext';
import { useUser } from '@/contexts/UserContext';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { state, toggleCart, setCartOpen } = useCart();
  const [badgeBump, setBadgeBump] = useState(false);
  const { config } = useHomeConfig();
  const { user } = useUser();
  
  // Verificar se o usuário é admin
  const isAdmin = user?.id === '1' || user?.email === 'admin@exemplo.com' || 
                  localStorage.getItem('admin_token') !== null;

  useEffect(() => {
    if (state.quantidadeTotal > 0) {
      setBadgeBump(true);
      const t = setTimeout(() => setBadgeBump(false), 300);
      return () => clearTimeout(t);
    }
  }, [state.quantidadeTotal]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 z-50 px-6 py-4 transition-all duration-300',
        isScrolled ? 'glass-morphism shadow-md' : 'bg-transparent'
      )}
    >
      <div className="container max-w-7xl mx-auto">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <div className="flex items-center">
              <img 
                src={config.theme.logoUrl || '/src/assets/muhlstore-mario-starwars-logo.png'} 
                alt="MuhlStore Logo" 
                className="h-10 mr-2"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = '/src/assets/muhlstore-mario-starwars-logo.png';
                }}
              />
              <span className="font-bold text-xl tracking-tight text-primary">MuhlStore Galaxy</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLinks className="text-sm" isAdmin={isAdmin} />
          </nav>

          {/* Carrinho Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleCart}
            className="relative"
            aria-label="Abrir carrinho"
          >
            <ShoppingCart className="h-5 w-5" />
            {state.quantidadeTotal > 0 && (
              <span className={`absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium ${badgeBump ? 'animate-bounce' : ''}`}>
                {state.quantidadeTotal > 99 ? '99+' : state.quantidadeTotal}
              </span>
            )}
          </Button>

          {/* Mobile menu button */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden focus:outline-none"
            onClick={toggleMenu}
            aria-label="Alternar menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div 
        className={cn(
          'fixed inset-0 top-16 glass-morphism md:hidden z-40 transform transition-transform duration-300 ease-in-out',
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        )}
      >
        <nav className="flex flex-col items-center justify-center h-full space-y-8 text-lg">
          <NavLinks onClick={() => setIsMenuOpen(false)} isAdmin={isAdmin} />
        </nav>
      </div>

      {/* Carrinho Drawer */}
      <CarrinhoDrawer />
    </header>
  );
};

// Helper component for navigation links
const NavLinks = ({ className, onClick, isAdmin }: { className?: string; onClick?: () => void; isAdmin?: boolean }) => (
  <>
    <Link 
      to="/" 
      className={cn("hover-lift font-medium text-foreground", className)} 
      onClick={onClick}
    >
      Início
    </Link>
    <Link 
      to="/colecao" 
      className={cn("hover-lift font-medium text-foreground", className)} 
      onClick={onClick}
    >
      Coleções
    </Link>
    <Link 
      to="/marketplace" 
      className={cn("hover-lift font-medium text-foreground", className)} 
      onClick={onClick}
    >
      Mercado
    </Link>
    <a
      href="http://177.67.33.248:8040/loja"
      className={cn("hover-lift font-medium text-foreground", className)}
      onClick={onClick}
      target="_blank" rel="noopener noreferrer"
    >
      Loja
    </a>
    <Link 
      to="/about" 
      className={cn("hover-lift font-medium text-foreground", className)} 
      onClick={onClick}
    >
      Sobre
    </Link>
    <Link 
      to="/eventos" 
      className={cn("hover-lift font-medium text-foreground", className)} 
      onClick={onClick}
    >
      Eventos
    </Link>
    <Link 
      to="/auth/login" 
      className={cn("hover-lift font-medium text-foreground", className)} 
      onClick={onClick}
    >
      Login
    </Link>
    {/* Link para painel admin se o usuário for admin */}
    {isAdmin && (
      <Link 
        to="/admin" 
        className={cn("hover-lift font-medium text-orange-600 hover:text-orange-700 flex items-center gap-1", className)} 
        onClick={onClick}
      >
        <Settings className="h-4 w-4" />
        Admin
      </Link>
    )}
    {/* Removido botão duplicado de carrinho para evitar duas entradas no header */}
  </>
);

export default Header;
