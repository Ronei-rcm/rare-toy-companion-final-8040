
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingBag, Package, Truck, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PedidosTab = () => {
  const navigate = useNavigate();
  
  // Dados simulados de pedidos
  const pedidos = [
    {
      id: 'PED-001',
      data: '15/03/2024',
      status: 'Entregue',
      valor: 349.90,
      itens: 3,
      produtos: ['Action Figure Batman', 'Coleção Marvel', 'Boneco Funko Pop']
    },
    {
      id: 'PED-002',
      data: '02/04/2024',
      status: 'Em trânsito',
      valor: 129.90,
      itens: 1,
      produtos: ['Camiseta Super Herói']
    },
    {
      id: 'PED-003',
      data: '28/04/2024',
      status: 'Processando',
      valor: 89.90,
      itens: 2,
      produtos: ['Caneca Personalizada', 'Adesivo Coleção']
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Entregue':
        return <CheckCircle className="h-4 w-4" />;
      case 'Em trânsito':
        return <Truck className="h-4 w-4" />;
      case 'Processando':
        return <Clock className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Entregue':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Em trânsito':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Processando':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Meus Pedidos</h2>
        <p className="text-muted-foreground">Acompanhe o status dos seus pedidos</p>
      </div>

      {pedidos.length > 0 ? (
        <div className="space-y-4">
          {pedidos.map(pedido => (
            <Card key={pedido.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">Pedido {pedido.id}</CardTitle>
                    <CardDescription>
                      Realizado em {pedido.data}
                    </CardDescription>
                  </div>
                  <Badge className={`flex items-center gap-1 ${getStatusColor(pedido.status)}`}>
                    {getStatusIcon(pedido.status)}
                    {pedido.status}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        {pedido.itens} item{pedido.itens > 1 ? 's' : ''}
                      </span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-lg">R$ {pedido.valor.toFixed(2)}</div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm font-medium text-muted-foreground">Produtos:</p>
                    <div className="flex flex-wrap gap-1">
                      {pedido.produtos.map((produto, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {produto}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      Ver detalhes
                    </Button>
                    {pedido.status === 'Entregue' && (
                      <Button variant="outline" size="sm" className="flex-1">
                        Comprar novamente
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ShoppingBag className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Nenhum pedido encontrado</h3>
            <p className="text-muted-foreground text-center mb-6">
              Você ainda não fez nenhum pedido. Que tal começar suas compras?
            </p>
            <Button onClick={() => navigate('/loja')} className="px-6">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Ir às compras
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PedidosTab;
