import React from 'react';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerFooter } from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Loader2 } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'react-router-dom';

const CarrinhoDrawer = () => {
  const { state, removeItem, updateQuantity, toggleCart, setCartOpen } = useCart();
  const { toast } = useToast();

  const handleRemoveItem = (id: string) => {
    removeItem(id);
  };

  const handleUpdateQuantity = (id: string, novaQuantidade: number) => {
    if (novaQuantidade <= 0) {
      handleRemoveItem(id);
      return;
    }
    updateQuantity(id, novaQuantidade);
  };

  const handleFinalizarCompra = () => {
    setCartOpen(false);
    toast({
      title: 'Redirecionando...',
      description: 'Você será direcionado para a página de checkout.',
    });
  };

  return (
    <Drawer open={state.isOpen} onOpenChange={setCartOpen}>
      <DrawerContent className="max-h-[80vh]">
        <DrawerHeader>
          <DrawerTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5" />
            Meu Carrinho ({state.quantidadeTotal} {state.quantidadeTotal === 1 ? 'item' : 'itens'})
          </DrawerTitle>
        </DrawerHeader>

        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {state.itens.length === 0 ? (
            <div className="text-center py-8">
              <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Seu carrinho está vazio</h3>
              <p className="text-muted-foreground mb-4">
                Que tal adicionar alguns brinquedos incríveis?
              </p>
              <Button onClick={toggleCart} asChild>
                <Link to="/loja">
                  Ver Produtos
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {state.itens.map((item, index) => (
                <div key={item.id}>
                  <div className="flex gap-3">
                    {/* Imagem do produto */}
                    <div className="w-16 h-16 flex-shrink-0">
                      <AspectRatio ratio={1}>
                        <img
                          src={item.produto.imagemUrl}
                          alt={item.produto.nome}
                          className="object-cover w-full h-full rounded-md"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = '/placeholder.svg';
                          }}
                        />
                      </AspectRatio>
                    </div>

                    {/* Informações do produto */}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm truncate">{item.produto.nome}</h4>
                      {item.produto.cor && (
                        <p className="text-xs text-muted-foreground">Cor: {item.produto.cor}</p>
                      )}
                      
                      <div className="flex items-center justify-between mt-2">
                        {/* Controles de quantidade */}
                        <div className="flex items-center gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => handleUpdateQuantity(item.id, item.quantidade - 1)}
                          disabled={state.isLoading}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="text-sm w-6 text-center">{item.quantidade}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => handleUpdateQuantity(item.id, item.quantidade + 1)}
                            disabled={state.isLoading}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>

                        {/* Preço */}
                        <div className="text-right">
                          <div className="font-medium text-sm">
                            R$ {(item.produto.preco * item.quantidade).toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Botão remover */}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-muted-foreground hover:text-destructive"
                      onClick={() => handleRemoveItem(item.id)}
                      disabled={state.isLoading}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                  
                  {index < state.itens.length - 1 && <Separator className="my-3" />}
                </div>
              ))}
            </div>
          )}
        </div>

        {state.itens.length > 0 && (
          <>
            <Separator />
            <DrawerFooter className="space-y-3">
              {/* Resumo do pedido */}
              <div className="flex justify-between items-center text-lg font-semibold">
                <span>Total:</span>
                <span>R$ {state.total.toFixed(2)}</span>
              </div>
              {state.isLoading && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Atualizando carrinho...
                </div>
              )}

              {/* Botões de ação */}
              <div className="flex gap-2">
                <Button variant="outline" onClick={toggleCart} className="flex-1" disabled={state.isLoading}>
                  Continuar Comprando
                </Button>
                <Button onClick={handleFinalizarCompra} className="flex-1" disabled={state.isLoading}>
                  Finalizar Compra
                </Button>
              </div>

              <Button variant="link" asChild className="text-sm">
                <Link to="/carrinho" onClick={toggleCart}>
                  Ver carrinho completo
                  <ArrowRight className="h-3 w-3 ml-1" />
                </Link>
              </Button>
            </DrawerFooter>
          </>
        )}
      </DrawerContent>
    </Drawer>
  );
};

export default CarrinhoDrawer;
