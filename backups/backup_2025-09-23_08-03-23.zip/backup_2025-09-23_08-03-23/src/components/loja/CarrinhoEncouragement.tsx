import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Gift, Star, Truck, Shield, Heart } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useProducts } from '@/hooks/useProducts';
import { AspectRatio } from '@/components/ui/aspect-ratio';

const CarrinhoEncouragement = () => {
  const { state } = useCart();

  // Mensagens de incentivo baseadas no valor do carrinho
  const getEncouragementMessage = () => {
    if (state.total === 0) {
      return {
        title: "🎁 Comece sua jornada de descobertas!",
        message: "Explore nossa coleção de brinquedos únicos e encontre o presente perfeito!",
        icon: <Gift className="h-6 w-6" />,
        color: "bg-gradient-to-r from-purple-500 to-pink-500"
      };
    } else if (state.total < 100) {
      return {
        title: "🌟 Você está no caminho certo!",
        message: "Adicione mais R$ " + (100 - state.total).toFixed(2) + " e ganhe frete grátis!",
        icon: <Truck className="h-6 w-6" />,
        color: "bg-gradient-to-r from-blue-500 to-cyan-500"
      };
    } else if (state.total < 200) {
      return {
        title: "🎉 Parabéns! Frete grátis conquistado!",
        message: "Adicione mais R$ " + (200 - state.total).toFixed(2) + " e ganhe 5% de desconto!",
        icon: <Star className="h-6 w-6" />,
        color: "bg-gradient-to-r from-green-500 to-emerald-500"
      };
    } else {
      return {
        title: "🏆 Você é incrível!",
        message: "Você ganhou 5% de desconto e frete grátis! Continue assim!",
        icon: <Heart className="h-6 w-6" />,
        color: "bg-gradient-to-r from-yellow-500 to-orange-500"
      };
    }
  };

  const { products, loading } = useProducts();

  // Sugestões de produtos complementares dinâmicas
  const encouragement = getEncouragementMessage();
  const carrinhoIds = new Set(state.itens.map(i => i.produto.id));
  const categoriasCarrinho = new Set(state.itens.map(i => i.produto.categoria).filter(Boolean));
  const candidatos = products
    .filter(p => !carrinhoIds.has(p.id))
    .filter(p => categoriasCarrinho.size === 0 || categoriasCarrinho.has(p.categoria))
    .slice(0, 3);

  return (
    <div className="space-y-4">
      {/* Mensagem de incentivo */}
      <Card className={`${encouragement.color} text-white border-0`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            {encouragement.icon}
            <div>
              <h3 className="font-semibold text-lg">{encouragement.title}</h3>
              <p className="text-sm opacity-90">{encouragement.message}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Selos de segurança e benefícios */}
      <Card className="bg-muted/30">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="flex flex-col items-center gap-2">
              <Shield className="h-6 w-6 text-green-600" />
              <span className="text-xs font-medium">Compra Segura</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Truck className="h-6 w-6 text-blue-600" />
              <span className="text-xs font-medium">Entrega Rápida</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Heart className="h-6 w-6 text-red-600" />
              <span className="text-xs font-medium">Garantia</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Star className="h-6 w-6 text-yellow-600" />
              <span className="text-xs font-medium">Qualidade</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sugestões complementares com base no carrinho */}
      {state.total > 0 && (
        <Card className="border-dashed border-2 border-primary/20">
          <CardContent className="p-4">
            <h4 className="font-semibold text-sm mb-3 text-center">Você também pode gostar</h4>
            {loading ? (
              <div className="text-xs text-muted-foreground text-center">Carregando sugestões...</div>
            ) : candidatos.length === 0 ? (
              <div className="text-xs text-muted-foreground text-center">Sem sugestões no momento</div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {candidatos.map((p) => (
                  <div key={p.id} className="rounded-md border bg-card">
                    <AspectRatio ratio={1.2}>
                      <img
                        src={p.imagemUrl}
                        alt={p.nome}
                        className="object-cover w-full h-full rounded-t-md"
                        onError={(e) => { (e.target as HTMLImageElement).src = '/placeholder.svg'; }}
                      />
                    </AspectRatio>
                    <div className="p-2 space-y-1">
                      <div className="text-xs font-medium line-clamp-2">{p.nome}</div>
                      <div className="text-xs text-primary font-semibold">R$ {p.preco.toFixed(2)}</div>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-[10px]">{p.categoria}</Badge>
                        <AddSuggestionButton produto={p} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Mensagem motivacional baseada na quantidade */}
      {state.quantidadeTotal > 0 && (
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-purple-700">
              {state.quantidadeTotal === 1 
                ? "🎯 Ótima escolha! Que tal adicionar mais um brinquedo para completar a diversão?"
                : `🎊 Incrível! Você tem ${state.quantidadeTotal} itens no carrinho. Está preparado para muita diversão!`
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CarrinhoEncouragement;

// Botão para adicionar sugestão ao carrinho
import { Produto } from '@/types/produto';
import { useToast } from '@/hooks/use-toast';
import { useCart as useCartContext } from '@/contexts/CartContext';

const AddSuggestionButton = ({ produto }: { produto: Produto }) => {
  const { addItem, state } = useCartContext();
  const { toast } = useToast();
  const [adding, setAdding] = React.useState(false);

  const handleAdd = async () => {
    setAdding(true);
    try {
      await addItem(produto, 1);
    } finally {
      setAdding(false);
    }
  };

  return (
    <Button size="sm" variant="outline" className="text-[10px]" onClick={handleAdd} disabled={adding || state.isLoading}>
      {adding ? 'Adicionando...' : 'Adicionar'}
    </Button>
  );
};
