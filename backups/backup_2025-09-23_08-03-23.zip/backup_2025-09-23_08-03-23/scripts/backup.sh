#!/usr/bin/env bash
set -euo pipefail

# Diretórios
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKUP_DIR="$PROJECT_ROOT/backups"
TIMESTAMP="$(date +"%Y-%m-%d_%H-%M-%S")"
BACKUP_NAME="backup_${TIMESTAMP}"
WORK_DIR="${BACKUP_DIR}/${BACKUP_NAME}"

mkdir -p "$WORK_DIR"

# Metadados do backup
{
  echo "project_path=$PROJECT_ROOT"
  echo "timestamp=$TIMESTAMP"
  echo "hostname=$(hostname)"
  echo "kernel=$(uname -sr)"
} > "$WORK_DIR/backup.meta"

# Carregar variáveis de ambiente do projeto (.env) SEM sobrescrever as já definidas
if [ -f "$PROJECT_ROOT/.env" ]; then
  set +u
  while IFS='=' read -r key value; do
    # Ignora linhas vazias e comentários
    if [[ -z "$key" || "$key" =~ ^\s*# ]]; then
      continue
    fi
    # Remove espaços e possíveis aspas envolventes
    key=$(echo "$key" | xargs)
    value=$(echo "$value" | sed -e 's/^\s*\"\{0,1\}//' -e 's/\"\{0,1\}\s*$//')
    # Só exporta se a variável NÃO estiver definida no ambiente
    if [ -z "${!key:+set}" ]; then
      export "$key=$value"
    fi
  done < "$PROJECT_ROOT/.env"
  set -u
fi

# Dump do MySQL via docker-compose (se disponível)
if command -v docker-compose >/dev/null 2>&1 && [ -f "$PROJECT_ROOT/docker-compose.yml" ]; then
  echo "[info] Tentando exportar dump MySQL do serviço 'mysql' (se existir)..."
  set +e
  MYSQL_SERVICE_NAME=${MYSQL_SERVICE_NAME:-mysql}
  MYSQL_SERVICE=$(docker-compose -f "$PROJECT_ROOT/docker-compose.yml" ps --services | grep -E "^${MYSQL_SERVICE_NAME}$" || true)
  set -e
  if [ -n "$MYSQL_SERVICE" ]; then
    echo "[info] Exportando dump..."
    # Variáveis usuais via .env ou defaults
    DB_USER=${DB_USER:-rare_toy_user}
    DB_NAME=${DB_NAME:-rare_toy_companion}
    DB_PASSWORD=${DB_PASSWORD:-${MYSQL_PASSWORD:-}}
    if [ -n "$DB_PASSWORD" ]; then
      PASS_ENV="-e MYSQL_PWD=$DB_PASSWORD"
      PASS_FLAG=""
    else
      PASS_ENV=""
      PASS_FLAG="--skip-password"
    fi
    if docker-compose -f "$PROJECT_ROOT/docker-compose.yml" exec -T $PASS_ENV "$MYSQL_SERVICE" sh -lc "mysqldump -u \"$DB_USER\" $PASS_FLAG \"$DB_NAME\"" > "$WORK_DIR/mysql_dump.sql"; then
      echo "[ok] Dump MySQL salvo em mysql_dump.sql"
    else
      echo "[warn] Não foi possível gerar o dump MySQL sem interação. Pulei esta etapa." >&2
      rm -f "$WORK_DIR/mysql_dump.sql" || true
    fi
  else
    echo "[info] Serviço mysql não encontrado no docker-compose. Pulei dump."
  fi
else
  echo "[info] docker-compose não encontrado ou docker-compose.yml ausente. Tentando dump MySQL local..."
  set +e
  if command -v mysqldump >/dev/null 2>&1; then
    DB_HOST=${DB_HOST:-127.0.0.1}
    DB_PORT=${DB_PORT:-3306}
    DB_USER=${DB_USER:-rare_toy_user}
    DB_NAME=${DB_NAME:-rare_toy_companion}
    DB_PASSWORD=${DB_PASSWORD:-}
    if [ -n "$DB_PASSWORD" ]; then
      export MYSQL_PWD="$DB_PASSWORD"
      PASS_FLAG=""
    else
      PASS_FLAG="--skip-password"
    fi
    if mysqldump -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" $PASS_FLAG "$DB_NAME" > "$WORK_DIR/mysql_dump.sql"; then
      echo "[ok] Dump MySQL local salvo em mysql_dump.sql"
    else
      echo "[warn] Não foi possível gerar o dump MySQL local. Pulei esta etapa." >&2
      rm -f "$WORK_DIR/mysql_dump.sql" || true
    fi
  else
    echo "[info] mysqldump não encontrado. Pulei dump do banco."
  fi
  set -e
fi

# Arquivos para incluir no backup (código + configs importantes)
INCLUDE_LIST=()
for path in \
  package.json \
  package-lock.json \
  ecosystem.config.cjs \
  docker-compose.yml \
  README.md \
  components.json \
  eslint.config.js \
  postcss.config.js \
  tailwind.config.ts \
  tsconfig.json \
  tsconfig.app.json \
  tsconfig.node.json \
  vite.config.ts \
  .env \
  .env.local \
  .env.production \
  server.cjs server.js server-*.cjs \
  src public scripts database supabase; do
  if [ -e "$PROJECT_ROOT/$path" ]; then
    INCLUDE_LIST+=("$path")
  fi
done

# Copia conteúdo para a pasta de trabalho
for item in "${INCLUDE_LIST[@]}"; do
  rsync -a --exclude node_modules --exclude .git "$PROJECT_ROOT/$item" "$WORK_DIR/"
done

# Gera ZIP final
ZIP_FILE="${BACKUP_DIR}/${BACKUP_NAME}.zip"
(
  cd "$WORK_DIR/.."
  zip -r "$(basename "$ZIP_FILE")" "$(basename "$WORK_DIR")" >/dev/null
)

# Limpa pasta de staging (mantém somente o zip e meta dentro do zip)
rm -rf "$WORK_DIR"

echo "[ok] Backup gerado: $ZIP_FILE"
