const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.SERVER_PORT || 3001;

// Middleware
app.use(cors({
  origin: [
    'http://localhost:8040', 
    'http://localhost:3000', 
    'http://127.0.0.1:8040',
    'http://177.67.33.248:8040'
  ],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Disable trust proxy to avoid rate limiting issues
app.set('trust proxy', false);

// Corrigir URLs duplicadas do tipo /http://host/... → redirecionar para o caminho correto
app.get(/^\/https?:\/\/[^/]+(\/.*)$/i, (req, res) => {
  try {
    const match = req.path.match(/^\/https?:\/\/[^/]+(\/.*)$/i);
    const target = match && match[1] ? match[1] : '/';
    return res.redirect(301, target);
  } catch (e) {
    return res.status(404).end();
  }
});

// Serve static files from public directory (com headers para evitar ORB)
app.use('/lovable-uploads', (req, res, next) => {
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('Access-Control-Allow-Origin', '*');
  next();
}, express.static(path.join(__dirname, 'public/lovable-uploads')));
// Também servir uploads padrão
// servir /uploads do mesmo diretório base do multer
app.use('/uploads', (req, res, next) => {
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('Access-Control-Allow-Origin', '*');
  next();
}, express.static(path.join(__dirname, 'public')));
// Logar chaves do body para rotas de coleções
app.use((req, _res, next) => {
  if (req.path.startsWith('/api/collections')) {
    try {
      const keys = req.body && typeof req.body === 'object' ? Object.keys(req.body) : [];
      console.log(`📥 ${req.method} ${req.path}`, keys.length ? { keys } : {});
    } catch {}
  }
  next();
});

// Fallback: se o frontend pedir apenas o nome do arquivo (ex.: 1758....jpg),
// tentamos servir a partir de /public/uploads/collections ou /public/lovable-uploads
app.get('/:fileName', async (req, res, next) => {
  try {
    const fileName = req.params.fileName;
    if (!fileName || !/(\.jpg|\.jpeg|\.png|\.webp)$/i.test(fileName)) return next();
  const tryPaths = [
      path.join(__dirname, 'public', 'lovable-uploads', fileName),
      path.join(__dirname, 'public', fileName)
    ];
    for (const p of tryPaths) {
      if (fs.existsSync(p)) {
        return res.sendFile(p);
      }
    }
    return res.status(404).send('Not found');
  } catch (_) {
    return next();
  }
});

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'public/lovable-uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    cb(null, uniqueSuffix + extension);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  }
});

// MySQL connection pool
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST || 'localhost',
  user: process.env.MYSQL_USER || 'rare_toy_user',
  password: process.env.MYSQL_PASSWORD || 'RSM_Rg51gti66',
  database: process.env.MYSQL_DATABASE || 'loja_brinquedos_sustentavel',
  port: parseInt(process.env.MYSQL_PORT || '3307'),
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Transform database item to frontend format
const transformCarouselItem = (dbItem) => ({
  id: dbItem.id || '',
  nome: dbItem.title || '',
  imagem: dbItem.image_url || '',
  badge: dbItem.badge || 'Novo',
  descricao: dbItem.subtitle || '',
  ativo: dbItem.active === 1 || dbItem.active === true,
  order_index: dbItem.order_index || 0,
  button_text: dbItem.button_text || 'Ver Mais',
  button_link: dbItem.button_link || '#'
});

// Transform frontend item to database format
const transformToDatabase = (item) => ({
  id: item.id || null,
  title: item.nome || null,
  subtitle: item.descricao || null,
  image_url: item.imagem || null,
  badge: item.badge || null,
  button_text: item.button_text || 'Ver Mais',
  button_link: item.button_link || '#',
  active: item.ativo !== undefined ? item.ativo : false,
  order_index: item.order_index || 0
});

// Filter out undefined values to prevent SQL errors
const filterUndefined = (obj) => {
  const filtered = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      filtered[key] = value;
    }
  }
  return filtered;
};

// Routes

// GET /api/carousel - Get all carousel items
app.get('/api/carousel', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM carousel_items ORDER BY order_index ASC, created_at ASC'
    );
    const items = rows.map(transformCarouselItem);
    res.json(items);
  } catch (error) {
    console.error('Error fetching carousel items:', error);
    res.status(500).json({ error: 'Failed to fetch carousel items' });
  }
});

// GET /api/carousel/active - Get active carousel items only
app.get('/api/carousel/active', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM carousel_items WHERE active = true ORDER BY order_index ASC, created_at ASC'
    );
    const items = rows.map(transformCarouselItem);
    res.json(items);
  } catch (error) {
    console.error('Error fetching active carousel items:', error);
    res.status(500).json({ error: 'Failed to fetch active carousel items' });
  }
});

// POST /api/carousel - Create new carousel item
app.post('/api/carousel', async (req, res) => {
  try {
    const item = req.body;
    const dbItem = filterUndefined(transformToDatabase(item));
    const newId = require('crypto').randomUUID();
    
    const [result] = await pool.execute(
      `INSERT INTO carousel_items 
       (id, title, subtitle, image_url, badge, button_text, button_link, active, order_index, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        newId,
        dbItem.title,
        dbItem.subtitle,
        dbItem.image_url,
        dbItem.badge,
        dbItem.button_text,
        dbItem.button_link,
        dbItem.active,
        dbItem.order_index
      ]
    );

    // Fetch the created item
    const [rows] = await pool.execute('SELECT * FROM carousel_items WHERE id = ?', [newId]);
    const createdItem = transformCarouselItem(rows[0]);
    
    res.status(201).json(createdItem);
  } catch (error) {
    console.error('Error creating carousel item:', error);
    res.status(500).json({ error: 'Failed to create carousel item' });
  }
});

// PUT /api/carousel/:id - Update carousel item
app.put('/api/carousel/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const item = req.body;
    const dbItem = filterUndefined(transformToDatabase(item));
    
    await pool.execute(
      `UPDATE carousel_items 
       SET title = ?, subtitle = ?, image_url = ?, button_text = ?, button_link = ?, 
           active = ?, order_index = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        dbItem.title,
        dbItem.subtitle,
        dbItem.image_url,
        dbItem.button_text,
        dbItem.button_link,
        dbItem.active,
        dbItem.order_index,
        id
      ]
    );

    // Fetch the updated item
    const [rows] = await pool.execute('SELECT * FROM carousel_items WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Carousel item not found' });
    }
    
    const updatedItem = transformCarouselItem(rows[0]);
    res.json(updatedItem);
  } catch (error) {
    console.error('Error updating carousel item:', error);
    res.status(500).json({ error: 'Failed to update carousel item' });
  }
});

// DELETE /api/carousel/:id - Delete carousel item
app.delete('/api/carousel/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const [result] = await pool.execute('DELETE FROM carousel_items WHERE id = ?', [id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Carousel item not found' });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting carousel item:', error);
    res.status(500).json({ error: 'Failed to delete carousel item' });
  }
});

// PUT /api/carousel/:id/toggle - Toggle item active status
app.put('/api/carousel/:id/toggle', async (req, res) => {
  try {
    const { id } = req.params;
    const { ativo } = req.body;
    
    await pool.execute(
      'UPDATE carousel_items SET active = ?, updated_at = NOW() WHERE id = ?',
      [ativo, id]
    );

    // Fetch the updated item
    const [rows] = await pool.execute('SELECT * FROM carousel_items WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Carousel item not found' });
    }
    
    const updatedItem = transformCarouselItem(rows[0]);
    res.json(updatedItem);
  } catch (error) {
    console.error('Error toggling carousel item:', error);
    res.status(500).json({ error: 'Failed to toggle carousel item' });
  }
});

// POST /api/carousel/bulk - Save all carousel items (bulk update)
app.post('/api/carousel/bulk', async (req, res) => {
  try {
    const items = req.body;
    
    // Start transaction
    const connection = await pool.getConnection();
    await connection.beginTransaction();
    
    try {
      // Get all existing items
      const [existingRows] = await connection.execute('SELECT id FROM carousel_items');
      const existingIds = new Set(existingRows.map(row => row.id));
      const newItemIds = new Set(items.map(item => item.id));

      // Delete items that were removed
      for (const existingRow of existingRows) {
        if (!newItemIds.has(existingRow.id)) {
          await connection.execute('DELETE FROM carousel_items WHERE id = ?', [existingRow.id]);
        }
      }

      // Update or create items
      for (let i = 0; i < items.length; i++) {
        const item = { ...items[i], order_index: i };
        const dbItem = filterUndefined(transformToDatabase(item));
        
        if (existingIds.has(item.id)) {
          // Update existing item
          await connection.execute(
            `UPDATE carousel_items 
             SET title = ?, subtitle = ?, image_url = ?, button_text = ?, button_link = ?, 
                 active = ?, order_index = ?, updated_at = NOW()
             WHERE id = ?`,
            [
              dbItem.title,
              dbItem.subtitle,
              dbItem.image_url,
              dbItem.button_text,
              dbItem.button_link,
              dbItem.active,
              dbItem.order_index,
              item.id
            ]
          );
        } else {
          // Create new item
          const newId = item.id || require('crypto').randomUUID();
          await connection.execute(
            `INSERT INTO carousel_items 
             (id, title, subtitle, image_url, button_text, button_link, active, order_index, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
            [
              newId,
              dbItem.title,
              dbItem.subtitle,
              dbItem.image_url,
              dbItem.button_text,
              dbItem.button_link,
              dbItem.active,
              dbItem.order_index
            ]
          );
        }
      }

      await connection.commit();
      res.json({ success: true });
      
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
    
  } catch (error) {
    console.error('Error saving carousel items:', error);
    res.status(500).json({ error: 'Failed to save carousel items' });
  }
});

// POST /api/upload - Upload image
app.post('/api/upload', upload.single('image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      filename: req.file.filename
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Upload failed', message: error.message });
  }
});

// ==================== PRODUTOS API ====================

// Buscar todos os produtos
app.get('/api/produtos', async (req, res) => {
  try {
    console.log('🔄 Buscando produtos...');
    const [rows] = await pool.execute(`
      SELECT 
        id, nome, descricao, preco, imagem_url as imagemUrl, categoria, estoque, 
        status, destaque, promocao, lancamento, avaliacao, total_avaliacoes as totalAvaliacoes,
        faixa_etaria as faixaEtaria, peso, dimensoes, material, marca, origem, fornecedor,
        codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt
      FROM products 
      ORDER BY created_at DESC
    `);
    
    console.log(`✅ ${rows.length} produtos encontrados`);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produtos = rows.map(produto => ({
      ...produto,
      preco: parseFloat(produto.preco),
      avaliacao: produto.avaliacao ? parseFloat(produto.avaliacao) : null,
      imagemUrl: produto.imagemUrl ? `http://177.67.33.248:3001${produto.imagemUrl}` : null
    }));
    
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar produtos em destaque
app.get('/api/produtos/destaque', async (req, res) => {
  try {
    console.log('🔄 Buscando produtos em destaque...');
    
    const [rows] = await pool.execute(
      'SELECT *, imagem_url as imagemUrl, total_avaliacoes as totalAvaliacoes, faixa_etaria as faixaEtaria, codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt FROM products WHERE destaque = true ORDER BY created_at DESC'
    );
    
    console.log(`✅ ${rows.length} produtos em destaque encontrados`);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produtos = rows.map(produto => ({
      ...produto,
      preco: parseFloat(produto.preco),
      avaliacao: produto.avaliacao ? parseFloat(produto.avaliacao) : null,
      imagemUrl: produto.imagemUrl ? `http://177.67.33.248:3001${produto.imagemUrl}` : null
    }));
    
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos em destaque:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar todas as categorias com contagem de produtos
app.get('/api/categorias', async (req, res) => {
  try {
    console.log('🔄 Buscando categorias...');
    
    const [rows] = await pool.execute(`
      SELECT 
        categoria as nome,
        COUNT(*) as quantidade,
        MIN(preco) as precoMinimo,
        MAX(preco) as precoMaximo,
        AVG(avaliacao) as avaliacaoMedia,
        MAX(created_at) as ultimoProduto
      FROM products 
      WHERE status = 'ativo' 
      GROUP BY categoria 
      ORDER BY quantidade DESC, categoria ASC
    `);
    
    console.log(`✅ ${rows.length} categorias encontradas`);
    
    // Adicionar ícones e cores baseadas na categoria
    const categoriasComIcones = rows.map(categoria => {
      const iconMap = {
        'Action Figures': '⚔️',
        'Colecionáveis': '👑',
        'Vintage': '⭐',
        'Gaming': '🎮',
        'Edição Limitada': '🛡️',
        'Bonecos de Ação': '🤖',
        'Carrinhos': '🚗',
        'Bonecas': '👸',
        'Jogos': '🎲',
        'Colecionáveis': '💎'
      };
      
      const colorMap = {
        'Action Figures': 'from-blue-500 to-blue-600',
        'Colecionáveis': 'from-purple-500 to-purple-600',
        'Vintage': 'from-yellow-500 to-orange-500',
        'Gaming': 'from-green-500 to-green-600',
        'Edição Limitada': 'from-red-500 to-red-600',
        'Bonecos de Ação': 'from-indigo-500 to-indigo-600',
        'Carrinhos': 'from-orange-500 to-orange-600',
        'Bonecas': 'from-pink-500 to-pink-600',
        'Jogos': 'from-teal-500 to-teal-600',
        'Colecionáveis': 'from-amber-500 to-amber-600'
      };
      
      return {
        ...categoria,
        id: categoria.nome.toLowerCase().replace(/\s+/g, '-'),
        icon: iconMap[categoria.nome] || '📦',
        cor: colorMap[categoria.nome] || 'from-gray-500 to-gray-600',
        descricao: `Encontre ${categoria.quantidade} produtos incríveis`,
        precoMinimo: parseFloat(categoria.precoMinimo),
        precoMaximo: parseFloat(categoria.precoMaximo),
        avaliacaoMedia: categoria.avaliacaoMedia ? parseFloat(categoria.avaliacaoMedia).toFixed(1) : null
      };
    });
    
    res.json(categoriasComIcones);
  } catch (error) {
    console.error('❌ Erro ao buscar categorias:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar produtos por categoria
app.get('/api/produtos/categoria/:categoria', async (req, res) => {
  try {
    const { categoria } = req.params;
    console.log(`🔄 Buscando produtos da categoria: ${categoria}`);
    
    const [rows] = await pool.execute(
      'SELECT *, imagem_url as imagemUrl, total_avaliacoes as totalAvaliacoes, faixa_etaria as faixaEtaria, codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt FROM products WHERE categoria = ? ORDER BY created_at DESC',
      [categoria]
    );
    
    console.log(`✅ ${rows.length} produtos encontrados na categoria ${categoria}`);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produtos = rows.map(produto => ({
      ...produto,
      preco: parseFloat(produto.preco),
      avaliacao: produto.avaliacao ? parseFloat(produto.avaliacao) : null,
      imagemUrl: produto.imagemUrl ? `http://177.67.33.248:3001${produto.imagemUrl}` : null
    }));
    
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos por categoria:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar estatísticas gerais da loja
app.get('/api/stats', async (req, res) => {
  try {
    console.log('🔄 Buscando estatísticas da loja...');
    
    const [statsRows] = await pool.execute(`
      SELECT 
        COUNT(*) as totalProdutos,
        COUNT(CASE WHEN status = 'ativo' THEN 1 END) as produtosAtivos,
        COUNT(CASE WHEN destaque = true THEN 1 END) as produtosDestaque,
        COUNT(CASE WHEN promocao = true THEN 1 END) as produtosPromocao,
        AVG(avaliacao) as avaliacaoMedia,
        SUM(total_avaliacoes) as totalAvaliacoes,
        MIN(preco) as precoMinimo,
        MAX(preco) as precoMaximo,
        AVG(preco) as precoMedio
      FROM products
    `);
    
    const [categoriasRows] = await pool.execute(`
      SELECT COUNT(DISTINCT categoria) as totalCategorias
      FROM products WHERE status = 'ativo'
    `);
    
    const stats = {
      ...statsRows[0],
      totalCategorias: categoriasRows[0].totalCategorias,
      avaliacaoMedia: statsRows[0].avaliacaoMedia ? parseFloat(statsRows[0].avaliacaoMedia).toFixed(1) : null,
      precoMedio: parseFloat(statsRows[0].precoMedio).toFixed(2)
    };
    
    console.log('✅ Estatísticas carregadas:', stats);
    res.json(stats);
  } catch (error) {
    console.error('❌ Erro ao buscar estatísticas:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar compras recentes simuladas (para demonstração)
app.get('/api/compras-recentes', async (req, res) => {
  try {
    console.log('🔄 Buscando compras recentes...');
    
    // Buscar produtos aleatórios para simular compras recentes
    const [rows] = await pool.execute(`
      SELECT 
        p.nome as produto,
        p.categoria,
        p.preco,
        p.imagem_url as imagemUrl,
        NOW() - INTERVAL FLOOR(RAND() * 1440) MINUTE as dataCompra,
        CONCAT(
          CASE FLOOR(RAND() * 4)
            WHEN 0 THEN 'João'
            WHEN 1 THEN 'Maria'
            WHEN 2 THEN 'Pedro'
            WHEN 3 THEN 'Ana'
          END,
          ' ',
          CASE FLOOR(RAND() * 4)
            WHEN 0 THEN 'Silva'
            WHEN 1 THEN 'Santos'
            WHEN 2 THEN 'Costa'
            WHEN 3 THEN 'Oliveira'
          END
        ) as cliente,
        CASE FLOOR(RAND() * 5)
          WHEN 0 THEN 'São Paulo'
          WHEN 1 THEN 'Rio de Janeiro'
          WHEN 2 THEN 'Belo Horizonte'
          WHEN 3 THEN 'Salvador'
          WHEN 4 THEN 'Brasília'
        END as cidade
      FROM products p
      WHERE p.status = 'ativo'
      ORDER BY RAND()
      LIMIT 10
    `);
    
    const compras = rows.map(compra => ({
      ...compra,
      preco: parseFloat(compra.preco),
      imagemUrl: compra.imagemUrl ? `http://177.67.33.248:3001${compra.imagemUrl}` : null,
      tempoAtras: Math.floor(Math.random() * 30) + 1 // 1-30 minutos atrás
    }));
    
    console.log(`✅ ${compras.length} compras recentes simuladas`);
    res.json(compras);
  } catch (error) {
    console.error('❌ Erro ao buscar compras recentes:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar produto por ID
app.get('/api/produtos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando produto ID: ${id}`);
    
    const [rows] = await pool.execute(
      'SELECT *, imagem_url as imagemUrl, total_avaliacoes as totalAvaliacoes, faixa_etaria as faixaEtaria, codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt FROM products WHERE id = ?',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    console.log('✅ Produto encontrado:', rows[0].nome);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produto = {
      ...rows[0],
      preco: parseFloat(rows[0].preco),
      avaliacao: rows[0].avaliacao ? parseFloat(rows[0].avaliacao) : null,
      imagemUrl: rows[0].imagemUrl ? `http://177.67.33.248:3001${rows[0].imagemUrl}` : null
    };
    
    res.json(produto);
  } catch (error) {
    console.error('❌ Erro ao buscar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Criar novo produto
app.post('/api/produtos', async (req, res) => {
  try {
    const produtoData = req.body;
    console.log('🔄 Criando produto:', produtoData.nome);
    
    // Criar produto com campos obrigatórios
    const [result] = await pool.execute(`
      INSERT INTO products (
        id, nome, preco, categoria, imagem_url, descricao, estoque, status,
        destaque, promocao, lancamento, avaliacao, total_avaliacoes,
        faixa_etaria, peso, dimensoes, material, marca, origem, fornecedor,
        codigo_barras, data_lancamento
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      require('crypto').randomUUID(),
      produtoData.nome,
      produtoData.preco,
      produtoData.categoria,
      produtoData.imagemUrl || null,
      produtoData.descricao || null,
      produtoData.estoque || 0,
      produtoData.status || 'ativo',
      produtoData.destaque || false,
      produtoData.promocao || false,
      produtoData.lancamento || false,
      produtoData.avaliacao || 0,
      produtoData.totalAvaliacoes || 0,
      produtoData.faixaEtaria || null,
      produtoData.peso || null,
      produtoData.dimensoes || null,
      produtoData.material || null,
      produtoData.marca || null,
      produtoData.origem || null,
      produtoData.fornecedor || null,
      produtoData.codigoBarras || null,
      produtoData.dataLancamento || null
    ]);
    
    console.log('✅ Produto criado com ID:', result.insertId);
    res.status(201).json({ id: result.insertId, ...produtoData });
  } catch (error) {
    console.error('❌ Erro ao criar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar produto
app.put('/api/produtos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const produtoData = req.body;
    console.log(`🔄 Atualizando produto ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE products SET 
        nome = ?, descricao = ?, preco = ?, imagem_url = ?, categoria = ?, 
        estoque = ?, status = ?, destaque = ?, promocao = ?, lancamento = ?,
        avaliacao = ?, total_avaliacoes = ?, faixa_etaria = ?, peso = ?, 
        dimensoes = ?, material = ?, marca = ?, origem = ?, fornecedor = ?,
        codigo_barras = ?, data_lancamento = ?, updated_at = NOW()
      WHERE id = ?
    `, [
      produtoData.nome,
      produtoData.descricao || null,
      produtoData.preco,
      produtoData.imagemUrl || null,
      produtoData.categoria,
      produtoData.estoque || 0,
      produtoData.status || 'ativo',
      produtoData.destaque || false,
      produtoData.promocao || false,
      produtoData.lancamento || false,
      produtoData.avaliacao || 0,
      produtoData.totalAvaliacoes || 0,
      produtoData.faixaEtaria || null,
      produtoData.peso || null,
      produtoData.dimensoes || null,
      produtoData.material || null,
      produtoData.marca || null,
      produtoData.origem || null,
      produtoData.fornecedor || null,
      produtoData.codigoBarras || null,
      produtoData.dataLancamento || null,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    console.log('✅ Produto atualizado');
    res.json({ id, ...produtoData });
  } catch (error) {
    console.error('❌ Erro ao atualizar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Deletar produto
app.delete('/api/produtos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando produto ID: ${id}`);
    
    const [result] = await pool.execute(
      'DELETE FROM products WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    console.log('✅ Produto deletado');
    res.json({ message: 'Produto deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// ==================== EVENTOS API ====================

// Buscar todos os eventos
app.get('/api/events', async (req, res) => {
  try {
    console.log('🔄 Buscando eventos...');
    const [rows] = await pool.execute(`
      SELECT 
        id, titulo, descricao, data_evento, local, numero_vagas,
        vagas_limitadas, imagem_url, ativo, feira_fechada, renda_total,
        participantes_confirmados, created_at, updated_at
      FROM events 
      ORDER BY data_evento ASC
    `);
    
    console.log(`✅ ${rows.length} eventos encontrados`);
    
    // Converter renda_total de string para number e corrigir URLs de imagem
    const eventos = rows.map(evento => ({
      ...evento,
      renda_total: evento.renda_total ? parseFloat(evento.renda_total) : null,
      imagem_url: evento.imagem_url ? `http://177.67.33.248:3001${evento.imagem_url}` : null
    }));
    
    res.json(eventos);
  } catch (error) {
    console.error('❌ Erro ao buscar eventos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar evento por ID
app.get('/api/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando evento ID: ${id}`);
    
    const [rows] = await pool.execute(
      'SELECT * FROM events WHERE id = ?',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Evento encontrado:', rows[0].titulo);
    
    // Converter renda_total de string para number e corrigir URLs de imagem
    const evento = {
      ...rows[0],
      renda_total: rows[0].renda_total ? parseFloat(rows[0].renda_total) : null,
      imagem_url: rows[0].imagem_url ? `http://177.67.33.248:3001${rows[0].imagem_url}` : null
    };
    
    res.json(evento);
  } catch (error) {
    console.error('❌ Erro ao buscar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Criar novo evento
app.post('/api/events', async (req, res) => {
  try {
    const eventoData = req.body;
    console.log('🔄 Criando evento:', eventoData.titulo);
    
    const [result] = await pool.execute(`
      INSERT INTO events (
        id, titulo, descricao, data_evento, local, numero_vagas,
        vagas_limitadas, imagem_url, ativo, feira_fechada, renda_total,
        participantes_confirmados
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      require('crypto').randomUUID(),
      eventoData.titulo,
      eventoData.descricao || null,
      eventoData.data_evento,
      eventoData.local || null,
      eventoData.numero_vagas || null,
      eventoData.vagas_limitadas || false,
      eventoData.imagem_url || null,
      eventoData.ativo !== false,
      eventoData.feira_fechada || false,
      eventoData.renda_total || null,
      eventoData.participantes_confirmados || null
    ]);
    
    console.log('✅ Evento criado com ID:', result.insertId);
    res.status(201).json({ id: result.insertId, ...eventoData });
  } catch (error) {
    console.error('❌ Erro ao criar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar evento
app.put('/api/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const eventoData = req.body;
    console.log(`🔄 Atualizando evento ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE events SET 
        titulo = ?, descricao = ?, data_evento = ?, local = ?,
        numero_vagas = ?, vagas_limitadas = ?, imagem_url = ?, ativo = ?,
        feira_fechada = ?, renda_total = ?, participantes_confirmados = ?, updated_at = NOW()
      WHERE id = ?
    `, [
      eventoData.titulo,
      eventoData.descricao || null,
      eventoData.data_evento,
      eventoData.local || null,
      eventoData.numero_vagas || null,
      eventoData.vagas_limitadas || false,
      eventoData.imagem_url || null,
      eventoData.ativo !== false,
      eventoData.feira_fechada || false,
      eventoData.renda_total || null,
      eventoData.participantes_confirmados || null,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Evento atualizado');
    res.json({ id, ...eventoData });
  } catch (error) {
    console.error('❌ Erro ao atualizar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Fechar feira e registrar renda total
app.post('/api/events/:id/fechar-feira', async (req, res) => {
  try {
    const { id } = req.params;
    const { renda_total, participantes_confirmados } = req.body;
    console.log(`🔄 Fechando feira do evento ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE events SET 
        feira_fechada = true, 
        renda_total = ?, 
        participantes_confirmados = ?,
        updated_at = NOW()
      WHERE id = ?
    `, [
      renda_total || 0,
      participantes_confirmados || 0,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Feira fechada com sucesso');
    res.json({ 
      message: 'Feira fechada com sucesso',
      renda_total: renda_total || 0,
      participantes_confirmados: participantes_confirmados || 0
    });
  } catch (error) {
    console.error('❌ Erro ao fechar feira:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Deletar evento
app.delete('/api/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando evento ID: ${id}`);
    
    const [result] = await pool.execute(
      'DELETE FROM events WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Evento deletado');
    res.json({ message: 'Evento deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// ================================
// ROTAS DE USUÁRIOS
// ================================

// Buscar todos os usuários
app.get('/api/users', async (req, res) => {
  try {
    console.log('🔄 Buscando usuários...');
    const [rows] = await pool.execute(`
      SELECT 
        id, email, avatar_url, nome, telefone, endereco, cidade, estado, cep,
        created_at, updated_at
      FROM users 
      ORDER BY created_at DESC
    `);
    
    console.log(`✅ ${rows.length} usuários encontrados`);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar usuários:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar usuário por ID
app.get('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando usuário ID: ${id}`);
    
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE id = ?',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }
    
    console.log('✅ Usuário encontrado:', rows[0].nome);
    res.json(rows[0]);
  } catch (error) {
    console.error('❌ Erro ao buscar usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Criar novo usuário
app.post('/api/users', async (req, res) => {
  try {
    const userData = req.body;
    console.log('🔄 Criando usuário:', userData.nome);
    
    const [result] = await pool.execute(`
      INSERT INTO users (
        id, email, avatar_url, nome, telefone, endereco, cidade, estado, cep
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      require('crypto').randomUUID(),
      userData.email,
      userData.avatar_url || null,
      userData.nome,
      userData.telefone || null,
      userData.endereco || null,
      userData.cidade || null,
      userData.estado || null,
      userData.cep || null
    ]);
    
    console.log('✅ Usuário criado com ID:', result.insertId);
    res.status(201).json({ id: result.insertId, ...userData });
  } catch (error) {
    console.error('❌ Erro ao criar usuário:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email já está em uso' });
    } else {
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
});

// Atualizar usuário
app.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const userData = req.body;
    console.log(`🔄 Atualizando usuário ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE users SET 
        email = ?, avatar_url = ?, nome = ?, telefone = ?, endereco = ?, cidade = ?, 
        estado = ?, cep = ?, updated_at = NOW()
      WHERE id = ?
    `, [
      userData.email,
      userData.avatar_url || null,
      userData.nome,
      userData.telefone || null,
      userData.endereco || null,
      userData.cidade || null,
      userData.estado || null,
      userData.cep || null,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }
    
    console.log('✅ Usuário atualizado');
    res.json({ message: 'Usuário atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar usuário:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email já está em uso' });
    } else {
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
});

// Deletar usuário
app.delete('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando usuário ID: ${id}`);
    
    const [result] = await pool.execute(
      'DELETE FROM users WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }
    
    console.log('✅ Usuário deletado');
    res.json({ message: 'Usuário deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Health check endpoint
// ===== COLECÕES API =====

// GET /api/collections - Buscar todas as coleções
app.get('/api/collections', async (req, res) => {
  try {
    const { admin, status } = req.query;
    // paginação e filtro
    const page = Math.max(parseInt(req.query.page || '1', 10), 1);
    const pageSize = Math.min(Math.max(parseInt(req.query.pageSize || '12', 10), 1), 100);
    const q = (req.query.q || '').toString().trim();
    const sort = (req.query.sort || 'created_at').toString();
    const order = ((req.query.order || 'desc').toString().toUpperCase() === 'ASC') ? 'ASC' : 'DESC';
    console.log('🔄 Buscando coleções...');
    
    // Verificar qual banco está sendo usado
    const [dbCheck] = await pool.execute('SELECT DATABASE() as current_db');
    console.log('📊 Banco atual:', dbCheck[0].current_db);
    
    const whereParts = [];
    const vals = [];
    if (q) { whereParts.push('(nome LIKE ? OR descricao LIKE ?)'); vals.push(`%${q}%`, `%${q}%`); }
    const whereSql = whereParts.length ? `WHERE ${whereParts.join(' AND ')}` : '';

    const allowSort = new Set(['created_at','updated_at','nome','id']);
    const sortCol = allowSort.has(sort) ? sort : 'created_at';

    const [countRows] = await pool.execute(`SELECT COUNT(*) as total FROM collections ${whereSql}`, vals);
    const total = (Array.isArray(countRows) && countRows[0] && (countRows[0].total ?? countRows[0]['COUNT(*)'])) ? (countRows[0].total ?? countRows[0]['COUNT(*)']) : 0;

    const offset = (page - 1) * pageSize;
    const limitNum = Number.isFinite(pageSize) ? Math.max(0, Math.floor(pageSize)) : 12;
    const offsetNum = Number.isFinite(offset) ? Math.max(0, Math.floor(offset)) : 0;
    // detectar colunas opcionais
    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSetList = cols.map(c => c.COLUMN_NAME);
    const hasAtivo = colSetList.includes('ativo');
    const hasDestaque = colSetList.includes('destaque');
    const hasTags = colSetList.includes('tags');
    const hasOrdem = colSetList.includes('ordem');

    const optionalCols = [
      hasAtivo ? 'ativo' : null,
      hasDestaque ? 'destaque' : null,
      hasTags ? 'tags' : null,
      hasOrdem ? 'ordem' : null,
    ].filter(Boolean).join(', ');

    const selectCols = `id, nome, descricao, imagem_url${optionalCols ? ', ' + optionalCols : ''}, NOW() as created_at, NOW() as updated_at`;
    const sql = `SELECT ${selectCols} FROM collections ${whereSql} ORDER BY ${sortCol} ${order} LIMIT ${limitNum} OFFSET ${offsetNum}`;
    const [rows] = await pool.execute(sql, vals);
    
    console.log(`✅ ${rows.length} coleções encontradas`);
    
    const host = req.get('host');
    const proto = req.protocol || 'http';
    const toPublic = (p) => p ? `${proto}://${host}${p.startsWith('/') ? '' : '/'}${p}` : null;

    const colecoes = rows.map(colecao => ({
      id: colecao.id.toString(),
      nome: colecao.nome,
      descricao: colecao.descricao,
      imagem_url: colecao.imagem_url || null,
      imagem: colecao.imagem_url ? toPublic(colecao.imagem_url) : null,
      produtos: parseInt(colecao.total_produtos) || 0,
      preco: 'R$ 0,00 - R$ 0,00',
      destaque: typeof colecao.destaque !== 'undefined' ? Boolean(colecao.destaque) : false,
      status: typeof colecao.ativo !== 'undefined' ? (colecao.ativo ? 'ativo' : 'inativo') : 'ativo',
      tags: typeof colecao.tags !== 'undefined' && colecao.tags ? (typeof colecao.tags === 'string' ? JSON.parse(colecao.tags) : colecao.tags) : [],
      ordem: typeof colecao.ordem !== 'undefined' ? (colecao.ordem || 0) : 0,
      created_at: colecao.created_at,
      updated_at: colecao.updated_at
    }));
    
    const withMeta = req.query.withMeta === '1' || req.query.withMeta === 'true';
    if (withMeta) {
      return res.json({ items: colecoes, page, pageSize, total, hasMore: offset + rows.length < total });
    }
    res.json(colecoes);
  } catch (error) {
    console.error('❌ Erro ao buscar coleções:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/collections/:id - Buscar coleção específica
app.get('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando coleção ${id}...`);
    // não dependemos de coluna ativo (alguns bancos não têm)
    const [rows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    const host = req.get('host');
    const proto = req.protocol || 'http';
    const imgPath = rows[0].imagem_url ?? rows[0].image_url;
    const imagemAbs = imgPath ? `${proto}://${host}${imgPath.startsWith('/') ? '' : '/'}${imgPath}` : null;

    const colecao = {
      id: rows[0].id?.toString?.() ?? rows[0].id,
      nome: rows[0].nome ?? rows[0].name,
      descricao: rows[0].descricao ?? rows[0].description,
      imagem_url: imgPath || null,
      imagem: imagemAbs,
      created_at: rows[0].created_at,
      updated_at: rows[0].updated_at
    };

    console.log(`✅ Coleção encontrada: ${colecao.nome}`);
    res.json(colecao);
  } catch (error) {
    console.error('❌ Erro ao buscar coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/collections/:id/full - coleção com produtos e imagem resolvida
app.get('/api/collections/:id/full', async (req, res) => {
  try {
    const { id } = req.params;
    const [cRows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    if (!cRows || cRows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });
    const host = req.get('host');
    const proto = req.protocol || 'http';
    const imgPath = cRows[0].imagem_url ?? cRows[0].image_url;
    const imagemAbs = imgPath ? `${proto}://${host}${imgPath.startsWith('/') ? '' : '/'}${imgPath}` : null;
    const colecao = {
      id: cRows[0].id?.toString?.() ?? cRows[0].id,
      nome: cRows[0].nome ?? cRows[0].name,
      descricao: cRows[0].descricao ?? cRows[0].description,
      imagem_url: imgPath || null,
      imagem: imagemAbs,
      created_at: cRows[0].created_at,
      updated_at: cRows[0].updated_at
    };

    const [links] = await pool.execute('SELECT * FROM collection_products WHERE collection_id = ? ORDER BY order_index ASC, created_at ASC', [id]);
    res.json({ ...colecao, products_count: links.length, links });
  } catch (error) {
    console.error('❌ Erro ao buscar coleção completa:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Opcional: suporte a slug (rota amigável)
app.get('/api/collections/slug/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    // slug é derivado do nome (lowercase, hifens). Buscar por nome aproximado
    const nomeAlvo = slug.replace(/-/g, ' ');
    const [rows] = await pool.execute('SELECT * FROM collections WHERE LOWER(nome) = LOWER(?) LIMIT 1', [nomeAlvo]);
    if (!rows || rows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });
    const host = req.get('host');
    const proto = req.protocol || 'http';
    const imgPath = rows[0].imagem_url ?? rows[0].image_url;
    const imagemAbs = imgPath ? `${proto}://${host}${imgPath.startsWith('/') ? '' : '/'}${imgPath}` : null;
    res.json({
      id: rows[0].id?.toString?.() ?? rows[0].id,
      nome: rows[0].nome,
      descricao: rows[0].descricao,
      imagem_url: imgPath || null,
      imagem: imagemAbs
    });
  } catch (error) {
    console.error('❌ Erro ao buscar coleção por slug:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PATCH toggles dinâmicos (ativo/destaque) - atualiza apenas colunas existentes
app.patch('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const body = req.body || {};
    const [exists] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    if (!exists || exists.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSet = new Set(cols.map(c => c.COLUMN_NAME));
    const parts = [];
    const vals = [];
    if (colSet.has('ativo') && typeof body.ativo !== 'undefined') { parts.push('ativo = ?'); vals.push(!!body.ativo); }
    if (colSet.has('destaque') && typeof body.destaque !== 'undefined') { parts.push('destaque = ?'); vals.push(!!body.destaque); }
    if (parts.length === 0) return res.status(400).json({ error: 'Nenhum campo suportado informado' });

    const sql = `UPDATE collections SET ${parts.join(', ')}, updated_at = NOW() WHERE id = ?`;
    await pool.execute(sql, [...vals, id]);

    const [rows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (error) {
    console.error('❌ Erro ao atualizar toggles da coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/collections/:id/products - Buscar produtos de uma coleção
app.get('/api/collections/:id/products', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando produtos da coleção ${id}...`);
    
    // Verificar se a coleção existe
    const [collectionRows] = await pool.execute('SELECT id, nome FROM collections WHERE id = ?', [id]);
    if (collectionRows.length === 0) {
      return res.status(404).json({ error: 'Coleção não encontrada' });
    }
    
    // Buscar produtos vinculados na tabela collection_products
    const [linkRows] = await pool.execute(`
      SELECT 
        cp.id, cp.collection_id, cp.product_id, cp.order_index,
        p.id as product_id, p.nome, p.preco, p.categoria, p.imagem_url, p.descricao, 
        p.estoque, p.status, p.destaque, p.promocao, p.lancamento, p.avaliacao, 
        p.total_avaliacoes, p.faixa_etaria, p.peso, p.dimensoes, p.material, 
        p.marca, p.origem, p.fornecedor, p.codigo_barras, p.data_lancamento, 
        p.created_at, p.updated_at
      FROM collection_products cp
      LEFT JOIN products p ON cp.product_id = p.id
      WHERE cp.collection_id = ?
      ORDER BY cp.order_index ASC, cp.created_at ASC
    `, [id]);
    
    const produtos = linkRows.map(link => ({
      id: link.id,
      collection_id: link.collection_id,
      product_id: link.product_id,
      order_index: link.order_index,
      product: link.product_id ? {
        id: link.product_id,
        nome: link.nome,
        preco: parseFloat(link.preco || 0),
        categoria: link.categoria,
        imagem_url: link.imagem_url,
        descricao: link.descricao,
        estoque: link.estoque,
        status: link.status,
        destaque: link.destaque,
        promocao: link.promocao,
        lancamento: link.lancamento,
        avaliacao: link.avaliacao ? parseFloat(link.avaliacao) : null,
        total_avaliacoes: link.total_avaliacoes,
        faixa_etaria: link.faixa_etaria,
        peso: link.peso,
        dimensoes: link.dimensoes,
        material: link.material,
        marca: link.marca,
        origem: link.origem,
        fornecedor: link.fornecedor,
        codigo_barras: link.codigo_barras,
        data_lancamento: link.data_lancamento,
        created_at: link.created_at,
        updated_at: link.updated_at
      } : null
    }));
    
    console.log(`✅ ${produtos.length} produtos encontrados na coleção ${collectionRows[0].nome}`);
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos da coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Utilitário simples: salvar imagem base64 (opcional)
const UPLOAD_DIR = path.join(__dirname, 'public', 'lovable-uploads');
try { fs.mkdirSync(UPLOAD_DIR, { recursive: true }); } catch {}
app.use('/uploads', express.static(path.join(process.cwd(), 'public', 'uploads')));

function saveBase64ImageToCollectionsBase64(dataUrl) {
  try {
    if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:')) return null;
    const m = dataUrl.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!m) return null;
    const ext = (m[1].split('/')[1] || 'png').toLowerCase();
    const buf = Buffer.from(m[2], 'base64');
    const filename = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, filename), buf);
    return `/uploads/collections/${filename}`;
  } catch {
    return null;
  }
}

// POST /api/collections - Criar nova coleção
app.post('/api/collections', async (req, res) => {
  try {
    const { nome, descricao, imagem, name, description, image_url, destaque, ativo, tags, ordem } = req.body || {};
    const finalName = (name ?? nome) || '';
    const finalDescription = (description ?? descricao) || '';
    let finalImageUrl = (image_url ?? imagem) || null;
    console.log(`🔄 Criando coleção: ${finalName}`);
    
    // Validar dados obrigatórios
    if (!finalName || !finalDescription) {
      return res.status(400).json({ error: 'Nome e descrição são obrigatórios' });
    }
    // Salvar base64 se enviado
    if (finalImageUrl && typeof finalImageUrl === 'string' && finalImageUrl.startsWith('data:')) {
      const saved = saveBase64ImageToCollectionsBase64(finalImageUrl);
      if (saved) finalImageUrl = saved;
    }
    
    // Inserção alinhada ao schema PT (id varchar, nome, descricao, imagem_url)
    const newId = require('crypto').randomUUID();
    // detectar colunas opcionais
    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSet = new Set(cols.map(c => c.COLUMN_NAME));
    const extraCols = [];
    const extraVals = [];
    if (colSet.has('destaque')) { extraCols.push('destaque'); extraVals.push(!!destaque); }
    if (colSet.has('ativo')) { extraCols.push('ativo'); extraVals.push(ativo === false ? 0 : 1); }
    if (colSet.has('tags')) { extraCols.push('tags'); extraVals.push(tags ? JSON.stringify(tags) : JSON.stringify([])); }
    if (colSet.has('ordem')) { extraCols.push('ordem'); extraVals.push(Number.isFinite(ordem) ? ordem : 0); }

    const baseCols = ['id','nome','descricao','imagem_url','created_at','updated_at'];
    const basePlace = ['?','?','?','?','NOW()','NOW()'];
    const sql = `INSERT INTO collections (${baseCols.concat(extraCols).join(',')}) VALUES (${basePlace.concat(extraCols.map(()=>'?')).join(',')})`;
    await pool.execute(sql, [newId, finalName, finalDescription, finalImageUrl, ...extraVals]);
    
    const host = req.get('host');
    const proto = req.protocol || 'http';
    const publicUrl = finalImageUrl ? `${proto}://${host}${finalImageUrl.startsWith('/') ? '' : '/'}${finalImageUrl}` : null;
    const novaColecao = {
      id: newId,
      nome: finalName,
      descricao: finalDescription,
      imagem_url: finalImageUrl,
      imagem: publicUrl,
      produtos: 0,
      preco: 'R$ 0,00 - R$ 0,00',
      destaque: false,
      status: 'ativo',
      tags: [],
      ordem: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    console.log(`✅ Coleção criada com sucesso: ${finalName}`);
    res.status(201).json(novaColecao);
  } catch (error) {
    console.error('❌ Erro ao criar coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// PUT /api/collections/:id - Atualizar coleção
app.put('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, descricao, imagem, name, description, image_url, destaque, ativo, tags, ordem } = req.body || {};
    const finalName = (name ?? nome) || '';
    const finalDescription = (description ?? descricao) || '';
    let finalImageUrl = (image_url ?? imagem) || null;
    console.log(`🔄 Atualizando coleção ${id}: ${finalName}`);
    
    // Validar dados obrigatórios
    if (!finalName || !finalDescription) {
      return res.status(400).json({ error: 'Nome e descrição são obrigatórios' });
    }
    // Salvar base64 se enviado
    if (finalImageUrl && typeof finalImageUrl === 'string' && finalImageUrl.startsWith('data:')) {
      const saved = saveBase64ImageToCollectionsBase64(finalImageUrl);
      if (saved) finalImageUrl = saved;
    }

    // Update alinhado ao schema PT
    // detectar colunas opcionais para update
    const [cols2] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSet2 = new Set(cols2.map(c => c.COLUMN_NAME));
    const parts = ['nome = ?','descricao = ?','imagem_url = ?'];
    const params = [finalName, finalDescription, finalImageUrl];
    if (colSet2.has('destaque') && typeof destaque !== 'undefined') { parts.push('destaque = ?'); params.push(!!destaque); }
    if (colSet2.has('ativo') && typeof ativo !== 'undefined') { parts.push('ativo = ?'); params.push(ativo ? 1 : 0); }
    if (colSet2.has('tags') && typeof tags !== 'undefined') { parts.push('tags = ?'); params.push(tags ? JSON.stringify(tags) : JSON.stringify([])); }
    if (colSet2.has('ordem') && typeof ordem !== 'undefined') { parts.push('ordem = ?'); params.push(Number.isFinite(ordem) ? ordem : 0); }
    const sql = `UPDATE collections SET ${parts.join(', ')}, updated_at = NOW() WHERE id = ?`;
    await pool.execute(sql, [...params, id]);
    
    // Buscar coleção atualizada
    const [rows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    const host2 = req.get('host');
    const proto2 = req.protocol || 'http';
    const imgPath = rows[0].imagem_url ?? rows[0].image_url;
    const colecaoAtualizada = {
      id: rows[0].id.toString(),
      nome: rows[0].nome ?? rows[0].name,
      descricao: rows[0].descricao ?? rows[0].description,
      imagem_url: imgPath || null,
      imagem: imgPath ? `${proto2}://${host2}${imgPath.startsWith('/') ? '' : '/'}${imgPath}` : null,
      created_at: rows[0].created_at,
      updated_at: rows[0].updated_at
    };
    
    console.log(`✅ Coleção atualizada com sucesso: ${nome}`);
    res.json(colecaoAtualizada);
  } catch (error) {
    console.error('❌ Erro ao atualizar coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// DELETE /api/collections/:id - Deletar coleção
app.delete('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando coleção ${id}`);
    await pool.execute('DELETE FROM collections WHERE id = ?', [id]);
    console.log(`✅ Coleção deletada com sucesso`);
    res.json({ success: true });
  } catch (error) {
    console.error('❌ Erro ao deletar coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/debug/collections-schema - Inspeciona colunas da tabela collections
app.get('/api/debug/collections-schema', async (req, res) => {
  try {
    const [cols] = await pool.execute("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections' ORDER BY ORDINAL_POSITION");
    res.json({
      database: process.env.MYSQL_DATABASE,
      table: 'collections',
      columns: cols
    });
  } catch (error) {
    console.error('❌ Erro ao ler schema de collections:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// Ensure link table collection_products exists
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS collection_products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        collection_id VARCHAR(191) NOT NULL,
        product_id INT NOT NULL,
        order_index INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_collection (collection_id),
        INDEX idx_product (product_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    console.log('✅ Checked/created table: collection_products');

    // Garantir que as colunas collection_id e product_id são VARCHAR(191) (podem existir como INT em bancos antigos)
    try {
      const [colInfo] = await pool.execute(
        "SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collection_products' AND COLUMN_NAME IN ('collection_id', 'product_id')"
      );
      
      for (const col of colInfo) {
        if (col.COLUMN_NAME === 'collection_id' && (col.DATA_TYPE.toLowerCase() !== 'varchar' || Number(col.CHARACTER_MAXIMUM_LENGTH || 0) < 191)) {
          console.log('🛠️ Alterando tipo de collection_id para VARCHAR(191) em collection_products...');
          await pool.execute('ALTER TABLE collection_products MODIFY collection_id VARCHAR(191) NOT NULL');
          console.log('✅ collection_id agora é VARCHAR(191)');
        }
        if (col.COLUMN_NAME === 'product_id' && (col.DATA_TYPE.toLowerCase() !== 'varchar' || Number(col.CHARACTER_MAXIMUM_LENGTH || 0) < 191)) {
          console.log('🛠️ Alterando tipo de product_id para VARCHAR(191) em collection_products...');
          await pool.execute('ALTER TABLE collection_products MODIFY product_id VARCHAR(191) NOT NULL');
          console.log('✅ product_id agora é VARCHAR(191)');
        }
      }
    } catch (e) {
      console.warn('⚠️ Não foi possível verificar/alterar colunas:', e?.message || e);
    }
  } catch (err) {
    console.error('❌ Failed ensuring collection_products table:', { message: err?.message, code: err?.code });
  }
})();

// Criar tabelas para página Sobre
(async () => {
  try {
    // Tabela para conteúdo da página Sobre
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS sobre_content (
        id VARCHAR(191) PRIMARY KEY,
        section VARCHAR(100) NOT NULL,
        title VARCHAR(255),
        subtitle VARCHAR(255),
        description TEXT,
        image_url VARCHAR(500),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        metadata JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_section (section)
      )
    `);
    console.log('✅ Tabela sobre_content criada/verificada');

    // Tabela para valores da empresa
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS company_values (
        id VARCHAR(191) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        icon VARCHAR(100),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela company_values criada/verificada');

    // Tabela para equipe
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS team_members (
        id VARCHAR(191) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        position VARCHAR(255),
        description TEXT,
        image_url VARCHAR(500),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela team_members criada/verificada');

    // Tabela para estatísticas
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS company_stats (
        id VARCHAR(191) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        value VARCHAR(100) NOT NULL,
        icon VARCHAR(100),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela company_stats criada/verificada');

    // Tabela para informações de contato
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS contact_info (
        id VARCHAR(191) PRIMARY KEY,
        type VARCHAR(100) NOT NULL,
        title VARCHAR(255) NOT NULL,
        value VARCHAR(255) NOT NULL,
        icon VARCHAR(100),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela contact_info criada/verificada');

  } catch (err) {
    console.error('❌ Erro ao criar tabelas da página Sobre:', { message: err?.message, code: err?.code });
  }
})();

// GET /api/collections/:id/products - Listar produtos vinculados
app.get('/api/collections/:id/products', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔎 Listando produtos da coleção ${id}`);
    const [links] = await pool.execute('SELECT * FROM collection_products WHERE collection_id = ? ORDER BY order_index ASC, created_at ASC', [id]);
    console.log(`🔢 Vínculos encontrados: ${links.length}`);

    // Detect optional product columns to enrich response
    let productDetailsMap = {};
    if (links.length > 0) {
      const productIds = links.map(l => l.product_id);
      const [prodCols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products'");
      const prodColNames = new Set(prodCols.map(c => c.COLUMN_NAME));
      const idCol = prodColNames.has('id') ? 'id' : null;
      const nameCol = prodColNames.has('name') ? 'name' : (prodColNames.has('nome') ? 'nome' : null);
      const imageCol = prodColNames.has('image_url') ? 'image_url' : (prodColNames.has('imagem_url') ? 'imagem_url' : null);
      const priceCol = prodColNames.has('price') ? 'price' : (prodColNames.has('preco') ? 'preco' : null);

      if (idCol) {
        const [rows] = await pool.query(`SELECT * FROM products WHERE ${idCol} IN (${productIds.map(() => '?').join(',')})`, productIds);
        console.log(`🧾 Produtos carregados: ${rows.length}`);
        productDetailsMap = rows.reduce((acc, row) => {
          acc[row[idCol]] = {
            id: row[idCol],
            name: nameCol ? row[nameCol] : undefined,
            image_url: imageCol ? row[imageCol] : undefined,
            price: priceCol ? row[priceCol] : undefined
          };
          return acc;
        }, {});
      }
    }

    const result = links.map(l => ({
      id: l.id,
      collection_id: l.collection_id,
      product_id: l.product_id,
      order_index: l.order_index,
      product: productDetailsMap[l.product_id] || null
    }));
    res.json(result);
  } catch (error) {
    console.error('❌ Erro ao listar produtos da coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// POST /api/collections/:id/products - Vincular produto à coleção
app.post('/api/collections/:id/products', async (req, res) => {
  try {
    const { id } = req.params;
    const { product_id, order_index } = req.body || {};
    if (!product_id) {
      return res.status(400).json({ error: 'product_id é obrigatório' });
    }

    // Checar existência de coleção
    const [cRows] = await pool.execute('SELECT id FROM collections WHERE id = ?', [id]);
    if (!cRows || cRows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    // Checar existência de produto (se tabela products existir)
    try {
      const [pRows] = await pool.execute('SELECT id FROM products WHERE id = ?', [product_id]);
      if (!pRows || pRows.length === 0) return res.status(404).json({ error: 'Produto não encontrado' });
    } catch (e) {
      // Se não existir a tabela products, segue sem validar
    }

    const ord = Number.isFinite(order_index) ? order_index : 0;
    const [result] = await pool.execute(
      'INSERT INTO collection_products (collection_id, product_id, order_index, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
      [id, product_id, ord]
    );

    res.status(201).json({ id: result.insertId, collection_id: id, product_id, order_index: ord });
  } catch (error) {
    console.error('❌ Erro ao adicionar produto na coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// DELETE /api/collections/:id/products/:productId - Remover vínculo
app.delete('/api/collections/:id/products/:productId', async (req, res) => {
  try {
    const { id, productId } = req.params;
    await pool.execute('DELETE FROM collection_products WHERE collection_id = ? AND product_id = ?', [id, productId]);
    res.json({ success: true });
  } catch (error) {
    console.error('❌ Erro ao remover produto da coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// PATCH /api/collections/:id/products/reorder - Reordenar produtos vinculados
app.patch('/api/collections/:id/products/reorder', async (req, res) => {
  try {
    const { id } = req.params;
    const { product_ids } = req.body || {};
    if (!Array.isArray(product_ids) || product_ids.length === 0) {
      return res.status(400).json({ error: 'product_ids é obrigatório (array)' });
    }

    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      for (let i = 0; i < product_ids.length; i++) {
        await connection.execute(
          'UPDATE collection_products SET order_index = ?, updated_at = NOW() WHERE collection_id = ? AND product_id = ?',
          [i, id, product_ids[i]]
        );
      }
      await connection.commit();
    } catch (e) {
      await connection.rollback();
      throw e;
    } finally {
      connection.release();
    }

    res.json({ success: true });
  } catch (error) {
    console.error('❌ Erro ao reordenar produtos da coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// DEBUG: resumo de coleção e vínculos
app.get('/api/debug/collections/:id/summary', async (req, res) => {
  try {
    const { id } = req.params;
    const [[cRows], [lRows]] = await Promise.all([
      pool.execute('SELECT * FROM collections WHERE id = ?', [id]),
      pool.execute('SELECT * FROM collection_products WHERE collection_id = ?', [id])
    ]);
    const collection = cRows && cRows[0] ? cRows[0] : null;
    res.json({ collection, links_count: lRows.length, sample_links: lRows.slice(0, 5) });
  } catch (error) {
    console.error('❌ Debug summary error:', error);
    res.status(500).json({ error: 'debug_failed' });
  }
});

// PUT /api/collections/reorder - Reordenar coleções
app.put('/api/collections/reorder', async (req, res) => {
  try {
    const { ids } = req.body;
    console.log('🔄 Reordenando coleções...');
    
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Lista de IDs é obrigatória' });
    }
    
    // Atualizar ordem de cada coleção (se a coluna ordem existir)
    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const hasOrdem = cols.some((c) => c.COLUMN_NAME === 'ordem');
    for (let i = 0; i < ids.length; i++) {
      if (hasOrdem) {
        await pool.execute('UPDATE collections SET ordem = ?, updated_at = NOW() WHERE id = ?', [i, ids[i]]);
      } else {
        await pool.execute('UPDATE collections SET updated_at = NOW() WHERE id = ?', [ids[i]]);
      }
    }
    
    console.log(`✅ ${ids.length} coleções reordenadas com sucesso`);
    res.json({ message: 'Coleções reordenadas com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao reordenar coleções:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/collections/seed - Popular coleções de exemplo
app.post('/api/collections/seed', async (req, res) => {
  try {
    console.log('🔄 Populando coleções de exemplo...');
    
    const colecoesExemplo = [
      {
        nome: 'Action Figures Premium',
        descricao: 'Bonecos de ação de alta qualidade com detalhes incríveis e articulações avançadas',
        imagem_url: '/lovable-uploads/action-figures-collection.jpg',
        destaque: true
      },
      {
        nome: 'Colecionáveis Vintage',
        descricao: 'Itens raros e vintage para colecionadores apaixonados por peças únicas',
        imagem_url: '/lovable-uploads/vintage-collection.jpg',
        destaque: true
      },
      {
        nome: 'Brinquedos Educativos',
        descricao: 'Jogos e brinquedos que estimulam o aprendizado e desenvolvimento infantil',
        imagem_url: '/lovable-uploads/educational-toys.jpg',
        destaque: false
      },
      {
        nome: 'Pelúcias Premium',
        descricao: 'Pelúcias macias e fofas, perfeitas para conforto e decoração',
        imagem_url: '/lovable-uploads/plush-toys.jpg',
        destaque: false
      },
      {
        nome: 'Jogos de Tabuleiro',
        descricao: 'Clássicos e modernos jogos de tabuleiro para diversão em família',
        imagem_url: '/lovable-uploads/board-games.jpg',
        destaque: true
      },
      {
        nome: 'Carrinhos e Veículos',
        descricao: 'Carros, caminhões e veículos de todos os tipos para pequenos motoristas',
        imagem_url: '/lovable-uploads/vehicles-collection.jpg',
        destaque: false
      }
    ];
    
    for (const colecao of colecoesExemplo) {
      await pool.execute(
        'INSERT IGNORE INTO collections (nome, descricao, imagem_url, destaque, ativo, created_at, updated_at) VALUES (?, ?, ?, ?, 1, NOW(), NOW())',
        [colecao.nome, colecao.descricao, colecao.imagem_url, colecao.destaque]
      );
    }
    
    console.log(`✅ ${colecoesExemplo.length} coleções de exemplo criadas`);
    res.json({ message: `${colecoesExemplo.length} coleções de exemplo criadas com sucesso` });
  } catch (error) {
    console.error('❌ Erro ao popular coleções:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Upload de imagem para coleções
app.post('/api/collections/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    }

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    const fullUrl = `http://177.67.33.248:3001${imageUrl}`;
    
    console.log(`✅ Imagem de coleção enviada: ${req.file.filename}`);
    
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      fullUrl: fullUrl,
      filename: req.file.filename 
    });
  } catch (error) {
    console.error('❌ Erro no upload de imagem:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Upload direto da imagem da coleção (multipart) e atualizar registro
app.post('/api/collections/:id/image', upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    if (!req.file) return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    // garantir que a coleção existe
    const [rows] = await pool.execute('SELECT id FROM collections WHERE id = ?', [id]);
    if (!rows || rows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    await pool.execute('UPDATE collections SET imagem_url = ?, updated_at = NOW() WHERE id = ?', [imageUrl, id]);

    const host = req.get('host');
    const proto = req.protocol || 'http';
    const fullUrl = `${proto}://${host}${imageUrl}`;
    res.json({ success: true, id, imagem_url: imageUrl, imagem: fullUrl, filename: req.file.filename });
  } catch (error) {
    console.error('❌ Erro ao atualizar imagem da coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rota para verificar estrutura da tabela collections
app.get('/api/debug/collections-structure', async (req, res) => {
  try {
    const [rows] = await pool.execute('DESCRIBE collections');
    res.json({ structure: rows });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Rota para adicionar colunas faltantes
app.post('/api/debug/fix-collections-table', async (req, res) => {
  try {
    console.log('🔄 Verificando e corrigindo estrutura da tabela collections...');
    
    // Verificar se a coluna destaque existe
    const [columns] = await pool.execute("SHOW COLUMNS FROM collections LIKE 'destaque'");
    if (columns.length === 0) {
      await pool.execute('ALTER TABLE collections ADD COLUMN destaque BOOLEAN DEFAULT FALSE');
      console.log('✅ Coluna destaque adicionada');
    }
    
    // Verificar se a coluna tags existe
    const [tagsColumns] = await pool.execute("SHOW COLUMNS FROM collections LIKE 'tags'");
    if (tagsColumns.length === 0) {
      await pool.execute('ALTER TABLE collections ADD COLUMN tags JSON');
      console.log('✅ Coluna tags adicionada');
    }
    
    // Verificar se a coluna ordem existe
    const [ordemColumns] = await pool.execute("SHOW COLUMNS FROM collections LIKE 'ordem'");
    if (ordemColumns.length === 0) {
      await pool.execute('ALTER TABLE collections ADD COLUMN ordem INT DEFAULT 0');
      console.log('✅ Coluna ordem adicionada');
    }
    
    res.json({ message: 'Estrutura da tabela corrigida com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao corrigir tabela:', error);
    res.status(500).json({ error: error.message });
  }
});

// ===== PÁGINA SOBRE API =====

// GET /api/sobre/content - Buscar conteúdo da página Sobre
app.get('/api/sobre/content', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM sobre_content 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar conteúdo da página Sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/content/:section - Atualizar conteúdo de uma seção
app.put('/api/sobre/content/:section', async (req, res) => {
  try {
    const { section } = req.params;
    const { title, subtitle, description, image_url, metadata } = req.body;
    
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO sobre_content (id, section, title, subtitle, description, image_url, metadata, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, TRUE)
      ON DUPLICATE KEY UPDATE
        title = VALUES(title),
        subtitle = VALUES(subtitle),
        description = VALUES(description),
        image_url = VALUES(image_url),
        metadata = VALUES(metadata),
        updated_at = CURRENT_TIMESTAMP
    `, [id, section, title, subtitle, description, image_url, JSON.stringify(metadata || {})]);
    
    res.json({ success: true, message: 'Conteúdo atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar conteúdo da página Sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/values - Buscar valores da empresa
app.get('/api/sobre/values', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM company_values 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar valores da empresa:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/values - Criar novo valor
app.post('/api/sobre/values', async (req, res) => {
  try {
    const { title, description, icon, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO company_values (id, title, description, icon, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, TRUE)
    `, [id, title, description, icon, order_index || 0]);
    
    res.json({ success: true, id, message: 'Valor criado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar valor:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/values/:id - Atualizar valor
app.put('/api/sobre/values/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, icon, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE company_values 
      SET title = ?, description = ?, icon = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [title, description, icon, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Valor atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar valor:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/values/:id - Deletar valor
app.delete('/api/sobre/values/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM company_values WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Valor deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar valor:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/team - Buscar membros da equipe
app.get('/api/sobre/team', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM team_members 
      WHERE is_active = 1 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar membros da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/team - Criar novo membro da equipe
app.post('/api/sobre/team', async (req, res) => {
  try {
    const { name, position, description, image_url, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO team_members (id, name, position, description, image_url, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, ?, TRUE)
    `, [id, name, position, description, image_url, order_index || 0]);
    
    res.json({ success: true, id, message: 'Membro da equipe criado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/team/:id - Atualizar membro da equipe
app.put('/api/sobre/team/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, position, description, image_url, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE team_members 
      SET name = ?, position = ?, description = ?, image_url = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [name, position, description, image_url, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Membro da equipe atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/team/:id - Deletar membro da equipe
app.delete('/api/sobre/team/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM team_members WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Membro da equipe deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/stats - Buscar estatísticas da empresa
app.get('/api/sobre/stats', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM company_stats 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar estatísticas da empresa:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/stats - Criar nova estatística
app.post('/api/sobre/stats', async (req, res) => {
  try {
    const { title, value, icon, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO company_stats (id, title, value, icon, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, TRUE)
    `, [id, title, value, icon, order_index || 0]);
    
    res.json({ success: true, id, message: 'Estatística criada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar estatística:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/stats/:id - Atualizar estatística
app.put('/api/sobre/stats/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, value, icon, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE company_stats 
      SET title = ?, value = ?, icon = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [title, value, icon, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Estatística atualizada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar estatística:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/stats/:id - Deletar estatística
app.delete('/api/sobre/stats/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM company_stats WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Estatística deletada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar estatística:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/contact - Buscar informações de contato
app.get('/api/sobre/contact', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM contact_info 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar informações de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/contact - Criar nova informação de contato
app.post('/api/sobre/contact', async (req, res) => {
  try {
    const { type, title, value, icon, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO contact_info (id, type, title, value, icon, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, ?, TRUE)
    `, [id, type, title, value, icon, order_index || 0]);
    
    res.json({ success: true, id, message: 'Informação de contato criada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar informação de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/contact/:id - Atualizar informação de contato
app.put('/api/sobre/contact/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { type, title, value, icon, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE contact_info 
      SET type = ?, title = ?, value = ?, icon = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [type, title, value, icon, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Informação de contato atualizada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar informação de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/contact/:id - Deletar informação de contato
app.delete('/api/sobre/contact/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM contact_info WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Informação de contato deletada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar informação de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// ===== UPLOAD DE IMAGENS PARA PÁGINA SOBRE =====

// Upload de imagem geral para página sobre
app.post('/api/sobre/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    }

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    const fullUrl = `http://177.67.33.248:3001${imageUrl}`;
    
    console.log(`✅ Imagem da página sobre enviada: ${req.file.filename}`);
    
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      fullUrl: fullUrl,
      filename: req.file.filename 
    });
  } catch (error) {
    console.error('❌ Erro no upload de imagem da página sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Upload de imagem para membro da equipe
app.post('/api/sobre/team/:id/image', upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    if (!req.file) return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    
    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    const fullUrl = `http://177.67.33.248:3001${imageUrl}`;
    
    // Atualizar o registro do membro da equipe
    await pool.execute(
      'UPDATE team_members SET image_url = ? WHERE id = ?',
      [fullUrl, id]
    );
    
    console.log(`✅ Imagem do membro da equipe ${id} atualizada: ${req.file.filename}`);
    
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      fullUrl: fullUrl,
      filename: req.file.filename 
    });
  } catch (error) {
    console.error('❌ Erro no upload de imagem do membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.get('/api/health', async (req, res) => {
  try {
    await pool.execute('SELECT 1');
    res.json({ status: 'healthy', database: 'connected' });
  } catch (error) {
    res.status(500).json({ status: 'unhealthy', database: 'disconnected', error: error.message });
  }
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Carousel API server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🎠 Carousel API: http://localhost:${PORT}/api/carousel`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down server...');
  await pool.end();
  process.exit(0);
});
