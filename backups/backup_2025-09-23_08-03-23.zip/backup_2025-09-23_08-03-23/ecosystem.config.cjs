module.exports = {
  apps: [
    {
      name: "api",
      script: "server.cjs",
      exec_mode: "fork",
      instances: 1,
      watch: false,
      time: true,
      env_file: ".env",
      env: {
        NODE_ENV: "development",
        SERVER_PORT: process.env.SERVER_PORT || 3001
      },
      autorestart: true,
      max_memory_restart: "300M"
    },
    {
      name: "web",
      cwd: __dirname,
      script: "npm",
      args: "run preview:pm2",
      exec_mode: "fork",
      instances: 1,
      watch: false,
      time: true,
      env_file: ".env",
      env: {
        NODE_ENV: "production",
        PORT: process.env.VITE_PORT || 8040
      },
      autorestart: true,
      max_memory_restart: "300M"
    }
  ]
};


