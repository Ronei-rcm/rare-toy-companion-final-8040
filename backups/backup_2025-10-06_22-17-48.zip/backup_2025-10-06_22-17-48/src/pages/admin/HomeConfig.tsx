import React from 'react';
import HomeManager from '@/components/admin/HomeManager';

const HomeConfig = () => {
  return (
    <div className="p-6">
      <HomeManager />
    </div>
  );
};

export default HomeConfig;