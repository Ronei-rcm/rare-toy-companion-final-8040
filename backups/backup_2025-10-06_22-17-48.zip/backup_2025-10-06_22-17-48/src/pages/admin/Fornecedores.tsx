import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Building2, 
  Mail, 
  Phone, 
  MapPin,
  Star,
  Package,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Edit,
  Trash2,
  Eye,
  Calendar,
  DollarSign
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import FornecedorModal from '@/components/admin/FornecedorModal';
import FornecedorStats from '@/components/admin/FornecedorStats';

interface Fornecedor {
  id: string;
  nome: string;
  email: string;
  telefone: string;
  endereco: string;
  cidade: string;
  estado: string;
  cep: string;
  cnpj: string;
  contato: string;
  status: 'ativo' | 'inativo' | 'pendente';
  avaliacao: number;
  totalProdutos: number;
  vendasMes: number;
  ultimaAtualizacao: string;
  dataCadastro: string;
  observacoes?: string;
  categorias: string[];
  prazoEntrega: number;
  condicoesPagamento: string;
}

const Fornecedores: React.FC = () => {
  const { toast } = useToast();
  const [fornecedores, setFornecedores] = useState<Fornecedor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [showModal, setShowModal] = useState(false);
  const [editingFornecedor, setEditingFornecedor] = useState<Fornecedor | null>(null);

  // Dados mockados para demonstração
  const mockFornecedores: Fornecedor[] = [
    {
      id: '1',
      nome: 'Brinquedos & Cia Ltda',
      email: 'contato@brinquedosecia.com.br',
      telefone: '(11) 3456-7890',
      endereco: 'Rua das Flores, 123',
      cidade: 'São Paulo',
      estado: 'SP',
      cep: '01234-567',
      cnpj: '12.345.678/0001-90',
      contato: 'João Silva',
      status: 'ativo',
      avaliacao: 4.8,
      totalProdutos: 156,
      vendasMes: 12500,
      ultimaAtualizacao: '2024-01-15',
      dataCadastro: '2023-06-15',
      categorias: ['Brinquedos Educativos', 'Jogos'],
      prazoEntrega: 7,
      condicoesPagamento: '30 dias'
    },
    {
      id: '2',
      nome: 'Distribuidora Kids',
      email: 'vendas@distribuidorakids.com',
      telefone: '(21) 9876-5432',
      endereco: 'Av. Principal, 456',
      cidade: 'Rio de Janeiro',
      estado: 'RJ',
      cep: '20000-000',
      cnpj: '98.765.432/0001-10',
      contato: 'Maria Santos',
      status: 'ativo',
      avaliacao: 4.5,
      totalProdutos: 89,
      vendasMes: 8900,
      ultimaAtualizacao: '2024-01-10',
      dataCadastro: '2023-08-20',
      categorias: ['Brinquedos de Bebê', 'Roupas'],
      prazoEntrega: 5,
      condicoesPagamento: '15 dias'
    },
    {
      id: '3',
      nome: 'Importadora Toys',
      email: 'import@importadoratoys.com',
      telefone: '(31) 1234-5678',
      endereco: 'Rua Industrial, 789',
      cidade: 'Belo Horizonte',
      estado: 'MG',
      cep: '30000-000',
      cnpj: '11.222.333/0001-44',
      contato: 'Pedro Costa',
      status: 'pendente',
      avaliacao: 0,
      totalProdutos: 0,
      vendasMes: 0,
      ultimaAtualizacao: '2024-01-20',
      dataCadastro: '2024-01-20',
      categorias: ['Importados'],
      prazoEntrega: 15,
      condicoesPagamento: 'À vista'
    }
  ];

  useEffect(() => {
    loadFornecedores();
  }, []);

  const loadFornecedores = async () => {
    try {
      setLoading(true);
      // Simular carregamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFornecedores(mockFornecedores);
    } catch (error) {
      toast({
        title: 'Erro ao carregar fornecedores',
        description: 'Não foi possível carregar a lista de fornecedores',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (fornecedor: Fornecedor) => {
    setEditingFornecedor(fornecedor);
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    try {
      // Simular exclusão
      await new Promise(resolve => setTimeout(resolve, 500));
      setFornecedores(prev => prev.filter(f => f.id !== id));
      toast({
        title: 'Fornecedor excluído',
        description: 'Fornecedor removido com sucesso',
      });
    } catch (error) {
      toast({
        title: 'Erro ao excluir',
        description: 'Não foi possível excluir o fornecedor',
        variant: 'destructive'
      });
    }
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    try {
      setFornecedores(prev => 
        prev.map(f => f.id === id ? { ...f, status: newStatus as any } : f)
      );
      toast({
        title: 'Status atualizado',
        description: `Fornecedor ${newStatus === 'ativo' ? 'ativado' : 'desativado'}`,
      });
    } catch (error) {
      toast({
        title: 'Erro ao atualizar status',
        description: 'Não foi possível alterar o status',
        variant: 'destructive'
      });
    }
  };

  const filteredFornecedores = fornecedores.filter(fornecedor => {
    const matchesSearch = fornecedor.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         fornecedor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         fornecedor.cnpj.includes(searchTerm);
    const matchesStatus = statusFilter === 'todos' || fornecedor.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      ativo: 'default',
      inativo: 'secondary',
      pendente: 'outline'
    } as const;

    const colors = {
      ativo: 'text-green-600',
      inativo: 'text-gray-600',
      pendente: 'text-yellow-600'
    };

    return (
      <Badge variant={variants[status as keyof typeof variants]} className={colors[status as keyof typeof colors]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ativo':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'inativo':
        return <AlertCircle className="h-4 w-4 text-gray-600" />;
      case 'pendente':
        return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Fornecedores</h1>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-6 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Fornecedores</h1>
          <p className="text-muted-foreground">
            Gerencie seus fornecedores e parceiros comerciais
          </p>
        </div>
        <Button onClick={() => setShowModal(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Novo Fornecedor
        </Button>
      </div>

      {/* Stats Cards */}
      <FornecedorStats fornecedores={fornecedores} />

      {/* Filtros e Busca */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Buscar fornecedores..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 border rounded-md text-sm"
              >
                <option value="todos">Todos os status</option>
                <option value="ativo">Ativo</option>
                <option value="inativo">Inativo</option>
                <option value="pendente">Pendente</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Fornecedores */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Lista de Fornecedores ({filteredFornecedores.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fornecedor</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Avaliação</TableHead>
                  <TableHead>Produtos</TableHead>
                  <TableHead>Vendas/Mês</TableHead>
                  <TableHead>Última Atualização</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredFornecedores.map((fornecedor) => (
                  <TableRow key={fornecedor.id}>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">{fornecedor.nome}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {fornecedor.cidade}, {fornecedor.estado}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          CNPJ: {fornecedor.cnpj}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {fornecedor.email}
                        </div>
                        <div className="text-sm flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {fornecedor.telefone}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Contato: {fornecedor.contato}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(fornecedor.status)}
                        {getStatusBadge(fornecedor.status)}
                      </div>
                    </TableCell>
                    <TableCell>
                      {fornecedor.avaliacao > 0 ? (
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="font-medium">{fornecedor.avaliacao}</span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">Sem avaliação</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        <span>{fornecedor.totalProdutos}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4 text-green-600" />
                        <span>R$ {fornecedor.vendasMes.toLocaleString()}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        {new Date(fornecedor.ultimaAtualizacao).toLocaleDateString('pt-BR')}
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(fornecedor)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            Ver Detalhes
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {fornecedor.status === 'ativo' ? (
                            <DropdownMenuItem 
                              onClick={() => handleStatusChange(fornecedor.id, 'inativo')}
                              className="text-yellow-600"
                            >
                              <AlertCircle className="h-4 w-4 mr-2" />
                              Desativar
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem 
                              onClick={() => handleStatusChange(fornecedor.id, 'ativo')}
                              className="text-green-600"
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Ativar
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem 
                            onClick={() => handleDelete(fornecedor.id)}
                            className="text-red-600"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Modal de Fornecedor */}
      <FornecedorModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingFornecedor(null);
        }}
        fornecedor={editingFornecedor}
        onSave={(fornecedor) => {
          if (editingFornecedor) {
            setFornecedores(prev => 
              prev.map(f => f.id === fornecedor.id ? fornecedor : f)
            );
          } else {
            setFornecedores(prev => [...prev, { ...fornecedor, id: Date.now().toString() }]);
          }
          setShowModal(false);
          setEditingFornecedor(null);
        }}
      />
    </div>
  );
};

export default Fornecedores;
