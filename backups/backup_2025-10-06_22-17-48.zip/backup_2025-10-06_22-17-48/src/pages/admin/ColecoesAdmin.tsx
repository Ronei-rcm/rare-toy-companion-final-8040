import React from 'react';
import CollectionManager from '@/components/admin/CollectionManager';

const ColecoesAdmin = () => {
  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-foreground">Gerenciar Coleções</h1>
        <p className="text-muted-foreground mt-2">
          Crie, edite e organize as coleções da sua loja
        </p>
      </div>
      
      <CollectionManager />
    </div>
  );
};

export default ColecoesAdmin;
