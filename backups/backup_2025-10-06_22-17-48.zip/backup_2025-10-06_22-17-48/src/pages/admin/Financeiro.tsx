import React, { useState, useEffect } from 'react';
import { useFinancialData } from '@/hooks/useFinancialData';
import FinancialIntegration from '@/components/admin/FinancialIntegration';
import FinancialTransactionModal from '@/components/admin/FinancialTransactionModal';
import FinancialCharts from '@/components/admin/FinancialCharts';
import FinancialExport from '@/components/admin/FinancialExport';
import FinancialAlerts from '@/components/admin/FinancialAlerts';
import FinancialDashboard from '@/components/admin/FinancialDashboard';
import FinancialGoals from '@/components/admin/FinancialGoals';
import FinancialForecast from '@/components/admin/FinancialForecast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  User,
  Building,
  CreditCard,
  AlertCircle,
  CheckCircle,
  Clock,
  Target,
  PieChart,
  BarChart3
} from 'lucide-react';

// Componente para o gráfico de fluxo de caixa (simulado)
const CashFlowChart = () => {
  const data = [
    { month: 'Jan', entradas: 8500, saidas: 3200 },
    { month: 'Fev', entradas: 9200, saidas: 4100 },
    { month: 'Mar', entradas: 7800, saidas: 3800 },
    { month: 'Abr', entradas: 10500, saidas: 4200 },
    { month: 'Mai', entradas: 12350, saidas: 5280 },
    { month: 'Jun', entradas: 9800, saidas: 3900 },
  ];

  const maxValue = Math.max(...data.map(d => Math.max(d.entradas, d.saidas)));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Fluxo de Caixa Mensal
        </CardTitle>
        <CardDescription>Entradas vs Saídas dos últimos 6 meses</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {data.map((item, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-medium">{item.month}</span>
                <span className="text-muted-foreground">
                  Saldo: R$ {(item.entradas - item.saidas).toLocaleString('pt-BR')}
                </span>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-xs text-green-600">Entradas</span>
                  <span className="text-xs font-medium">R$ {item.entradas.toLocaleString('pt-BR')}</span>
                </div>
                <Progress value={(item.entradas / maxValue) * 100} className="h-2" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-xs text-red-600">Saídas</span>
                  <span className="text-xs font-medium">R$ {item.saidas.toLocaleString('pt-BR')}</span>
                </div>
                <Progress value={(item.saidas / maxValue) * 100} className="h-2" />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente para a tabela de lançamentos financeiros
const FinancialTransactions = ({ transactions: propTransactions = [] }: { transactions?: any[] }) => {
  const transactions = propTransactions.length > 0 ? propTransactions : [
    {
      id: 1,
      data: '2024-05-15',
      descricao: 'Venda de Produtos - Cliente João Silva',
      categoria: 'Venda',
      origem: 'Cliente',
      tipo: 'Entrada',
      valor: 245.80,
      status: 'Pago'
    },
    {
      id: 2,
      data: '2024-05-14',
      descricao: 'Pagamento Fornecedor - Brinquedos ABC',
      categoria: 'Fornecedor',
      origem: 'Fornecedor',
      tipo: 'Saída',
      valor: 1200.00,
      status: 'Pago'
    },
    {
      id: 3,
      data: '2024-05-13',
      descricao: 'Evento Workshop - Brinquedos Educativos',
      categoria: 'Evento',
      origem: 'Evento',
      tipo: 'Entrada',
      valor: 890.00,
      status: 'Pago'
    },
    {
      id: 4,
      data: '2024-05-12',
      descricao: 'Marketing Digital - Facebook Ads',
      categoria: 'Marketing',
      origem: 'Marketing',
      tipo: 'Saída',
      valor: 350.00,
      status: 'Pendente'
    },
    {
      id: 5,
      data: '2024-05-11',
      descricao: 'Venda de Produtos - Cliente Maria Santos',
      categoria: 'Venda',
      origem: 'Cliente',
      tipo: 'Entrada',
      valor: 180.50,
      status: 'Atrasado'
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Pago':
        return <Badge className="bg-green-100 text-green-800 border-green-200"><CheckCircle className="h-3 w-3 mr-1" />Pago</Badge>;
      case 'Pendente':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200"><Clock className="h-3 w-3 mr-1" />Pendente</Badge>;
      case 'Atrasado':
        return <Badge className="bg-red-100 text-red-800 border-red-200"><AlertCircle className="h-3 w-3 mr-1" />Atrasado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getTypeIcon = (tipo: string) => {
    return tipo === 'Entrada' ? 
      <ArrowUpRight className="h-4 w-4 text-green-600" /> : 
      <ArrowDownRight className="h-4 w-4 text-red-600" />;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Lançamentos Financeiros</CardTitle>
        <CardDescription>Histórico detalhado de todas as movimentações</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Descrição</TableHead>
              <TableHead>Categoria</TableHead>
              <TableHead>Origem</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Valor</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell className="font-medium">{transaction.data}</TableCell>
                <TableCell>{transaction.descricao}</TableCell>
                <TableCell>
                  <Badge variant="outline">{transaction.categoria}</Badge>
                </TableCell>
                <TableCell>{transaction.origem}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {getTypeIcon(transaction.tipo)}
                    {transaction.tipo}
                  </div>
                </TableCell>
                <TableCell className={`font-medium ${
                  transaction.tipo === 'Entrada' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.tipo === 'Entrada' ? '+' : '-'}R$ {transaction.valor.toLocaleString('pt-BR')}
                </TableCell>
                <TableCell>{getStatusBadge(transaction.status)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

// Componente para widgets do painel lateral
const SidebarWidgets = () => {
  const contasAPagar = [
    { id: 1, descricao: 'Fornecedor Brinquedos ABC', valor: 1200, vencimento: '2024-05-20' },
    { id: 2, descricao: 'Marketing Digital', valor: 350, vencimento: '2024-05-18' },
    { id: 3, descricao: 'Aluguel Loja', valor: 2500, vencimento: '2024-05-25' }
  ];

  const contasAReceber = [
    { id: 1, descricao: 'Cliente João Silva', valor: 245.80, vencimento: '2024-05-16' },
    { id: 2, descricao: 'Evento Workshop', valor: 890, vencimento: '2024-05-20' },
    { id: 3, descricao: 'Cliente Maria Santos', valor: 180.50, vencimento: '2024-05-15' }
  ];

  const eventosFaturamento = [
    { nome: 'Workshop Brinquedos Educativos', faturamento: 890, participantes: 15 },
    { nome: 'Feira de Brinquedos', faturamento: 1200, participantes: 25 },
    { nome: 'Curso Montagem', faturamento: 650, participantes: 12 }
  ];

  const topFornecedores = [
    { nome: 'Brinquedos ABC Ltda', despesa: 1200, percentual: 35 },
    { nome: 'Educacional XYZ', despesa: 890, percentual: 26 },
    { nome: 'Criativo Toys', despesa: 650, percentual: 19 },
    { nome: 'Infantil Plus', despesa: 420, percentual: 12 },
    { nome: 'Diversão Kids', despesa: 280, percentual: 8 }
  ];

  return (
    <div className="space-y-6">
      {/* Contas a Pagar */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600">
            <AlertCircle className="h-5 w-5" />
            Contas a Pagar
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {contasAPagar.map((conta) => (
              <div key={conta.id} className="flex justify-between items-center p-3 bg-red-50 rounded-lg border border-red-200">
                <div>
                  <p className="text-sm font-medium">{conta.descricao}</p>
                  <p className="text-xs text-red-600">Vence: {conta.vencimento}</p>
                </div>
                <span className="font-bold text-red-700">R$ {conta.valor.toLocaleString('pt-BR')}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Contas a Receber */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-600">
            <CheckCircle className="h-5 w-5" />
            Contas a Receber
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {contasAReceber.map((conta) => (
              <div key={conta.id} className="flex justify-between items-center p-3 bg-green-50 rounded-lg border border-green-200">
                <div>
                  <p className="text-sm font-medium">{conta.descricao}</p>
                  <p className="text-xs text-green-600">Vence: {conta.vencimento}</p>
                </div>
                <span className="font-bold text-green-700">R$ {conta.valor.toLocaleString('pt-BR')}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Resumo por Evento */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Resumo por Evento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {eventosFaturamento.map((evento, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{evento.nome}</span>
                  <span className="text-sm font-bold text-green-600">R$ {evento.faturamento.toLocaleString('pt-BR')}</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{evento.participantes} participantes</span>
                  <span>R$ {(evento.faturamento / evento.participantes).toFixed(2)}/pessoa</span>
                </div>
                <Progress value={75} className="h-1" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Fornecedores */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Top Fornecedores
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topFornecedores.map((fornecedor, index) => (
              <div key={index} className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{fornecedor.nome}</span>
                  <span className="text-sm font-bold">R$ {fornecedor.despesa.toLocaleString('pt-BR')}</span>
                </div>
                <Progress value={fornecedor.percentual} className="h-1" />
                <span className="text-xs text-muted-foreground">{fornecedor.percentual}% do total</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const Financeiro = () => {
  const { loading, summary, transactions, orders, suppliers, events, refreshData } = useFinancialData();
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  const handleNewTransaction = () => {
    setEditingTransaction(null);
    setShowTransactionModal(true);
  };

  const handleEditTransaction = (transaction: any) => {
    setEditingTransaction(transaction);
    setShowTransactionModal(true);
  };

  const handleSaveTransaction = (transactionData: any) => {
    // Aqui você implementaria a lógica para salvar a transação
    console.log('Salvando transação:', transactionData);
    // Por enquanto, apenas fecha o modal
    setShowTransactionModal(false);
    setEditingTransaction(null);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Financeiro — Controle e Integração</h1>
          <p className="text-gray-600 mt-2">Controle total do fluxo financeiro da loja</p>
        </div>
        <Button 
          className="bg-orange-500 hover:bg-orange-600 text-white"
          onClick={handleNewTransaction}
        >
          <Plus className="h-4 w-4 mr-2" />
          Novo Lançamento Financeiro
        </Button>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Faturamento Total</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">R$ 12.350,00</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              +18% em relação ao mês anterior
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas com Fornecedores</CardTitle>
            <Building className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">R$ 5.280,00</div>
            <div className="flex items-center text-xs text-red-600">
              <TrendingDown className="h-3 w-3 mr-1" />
              +5% em relação ao mês anterior
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lucro Líquido</CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">R$ 7.070,00</div>
            <div className="flex items-center text-xs text-blue-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              +22% em relação ao mês anterior
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo Projetado</CardTitle>
            <PieChart className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">R$ 8.450,00</div>
            <div className="flex items-center text-xs text-orange-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              Projeção para o próximo mês
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Abas */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-9">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="transactions">Lançamentos</TabsTrigger>
          <TabsTrigger value="goals">Metas</TabsTrigger>
          <TabsTrigger value="forecast">Previsões</TabsTrigger>
          <TabsTrigger value="reports">Relatórios</TabsTrigger>
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
          <TabsTrigger value="export">Exportar</TabsTrigger>
          <TabsTrigger value="integration">Integração</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          <FinancialDashboard 
            orders={orders}
            suppliers={suppliers}
            events={events}
            transactions={transactions}
            summary={summary}
            onRefresh={refreshData}
            loading={loading}
          />
        </TabsContent>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Área Principal - Gráfico e Tabela */}
            <div className="lg:col-span-2 space-y-6">
              <CashFlowChart />
              <FinancialTransactions transactions={transactions} />
            </div>

            {/* Painel Lateral - Widgets */}
            <div className="space-y-6">
              <FinancialIntegration 
                orders={orders}
                events={events}
                suppliers={suppliers}
                onRefresh={refreshData}
                loading={loading}
              />
              <SidebarWidgets />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Lançamentos Financeiros</h2>
            <Button onClick={handleNewTransaction} className="bg-orange-500 hover:bg-orange-600">
              <Plus className="h-4 w-4 mr-2" />
              Novo Lançamento
            </Button>
          </div>
          <FinancialTransactions transactions={transactions} />
        </TabsContent>

        <TabsContent value="goals" className="space-y-6">
          <FinancialGoals 
            orders={orders}
            suppliers={suppliers}
            events={events}
            transactions={transactions}
            summary={summary}
          />
        </TabsContent>

        <TabsContent value="forecast" className="space-y-6">
          <FinancialForecast 
            orders={orders}
            suppliers={suppliers}
            events={events}
            transactions={transactions}
            summary={summary}
          />
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <FinancialCharts 
            orders={orders}
            suppliers={suppliers}
            events={events}
            transactions={transactions}
          />
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          <FinancialAlerts 
            orders={orders}
            suppliers={suppliers}
            events={events}
            transactions={transactions}
            summary={summary}
          />
        </TabsContent>

        <TabsContent value="export" className="space-y-6">
          <FinancialExport 
            orders={orders}
            suppliers={suppliers}
            events={events}
            transactions={transactions}
            summary={summary}
          />
        </TabsContent>

        <TabsContent value="integration" className="space-y-6">
          <FinancialIntegration 
            orders={orders}
            events={events}
            suppliers={suppliers}
            onRefresh={refreshData}
            loading={loading}
          />
        </TabsContent>
      </Tabs>

      {/* Modal de Transação */}
      <FinancialTransactionModal
        isOpen={showTransactionModal}
        onClose={() => {
          setShowTransactionModal(false);
          setEditingTransaction(null);
        }}
        onSave={handleSaveTransaction}
        transaction={editingTransaction}
      />
    </div>
  );
};

export default Financeiro;
