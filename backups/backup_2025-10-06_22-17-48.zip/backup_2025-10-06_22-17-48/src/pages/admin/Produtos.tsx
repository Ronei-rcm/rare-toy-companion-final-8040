import React from 'react';
import { ProductsManager } from '@/components/admin/ProductsManager';

const Produtos = () => {
  return (
    <div className="p-6">
      <ProductsManager />
    </div>
  );
};

export default Produtos;
