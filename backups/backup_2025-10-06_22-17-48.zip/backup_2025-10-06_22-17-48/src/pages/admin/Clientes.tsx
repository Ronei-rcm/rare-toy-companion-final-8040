
import React from 'react';
import { UsersManager } from '@/components/admin/UsersManager';

const Clientes = () => {
  return (
    <div className="p-6">
      <UsersManager />
    </div>
  );
};

export default Clientes;
