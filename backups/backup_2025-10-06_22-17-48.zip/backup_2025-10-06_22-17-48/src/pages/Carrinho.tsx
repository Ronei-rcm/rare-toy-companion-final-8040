
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import CarrinhoItems from '@/components/loja/CarrinhoItems';
import CarrinhoResumo from '@/components/loja/CarrinhoResumo';
import CarrinhoEncouragement from '@/components/loja/CarrinhoEncouragement';
import CheckoutRapido from '@/components/loja/CheckoutRapido';
import SelosSeguranca from '@/components/loja/SelosSeguranca';
import { Button } from '@/components/ui/button';
import { ShoppingBag, ArrowLeft, Loader2, Zap } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useUser } from '@/contexts/UserContext';

const Carrinho = () => {
  const { state } = useCart();
  const [showCheckoutRapido, setShowCheckoutRapido] = useState(false);
  const { user } = useUser() as any;
  const navigate = useNavigate();
  
  // Scroll para o topo ao carregar a página
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Meu Carrinho</h1>
          <div className="flex gap-2">
            {state.itens.length > 0 && (
              <Button onClick={() => {
                if (!user) {
                  navigate('/auth/login?redirect=/carrinho');
                } else {
                  setShowCheckoutRapido(true);
                }
              }} className="flex items-center gap-2">
                <Zap size={16} /> Checkout Rápido
              </Button>
            )}
            <Link to="/loja">
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft size={16} /> Continuar Comprando
              </Button>
            </Link>
          </div>
        </div>

        <div className="mb-6 rounded-md border p-4 bg-muted/30 flex items-center justify-between text-sm">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center rounded-full bg-green-100 text-green-800 px-2 py-0.5 border border-green-200 text-xs">Frete grátis acima de R$ 200</span>
            <span className="inline-flex items-center rounded-full bg-amber-100 text-amber-900 px-2 py-0.5 border border-amber-200 text-xs">PIX 5% OFF</span>
          </div>
          <div className="font-medium">Subtotal: R$ {state.total.toFixed(2)}</div>
        </div>

        {!user && (
          <div className="mb-6 p-4 rounded-md border bg-amber-50 text-amber-900 flex items-center justify-between">
            <div>
              <div className="font-semibold">Faça login para finalizar a compra</div>
              <div className="text-sm opacity-80">Entrar ou cadastrar-se é rapidinho.</div>
            </div>
            <div className="flex gap-2">
              <Link to="/auth/login?redirect=/carrinho" className="underline">Entrar</Link>
              <Link to="/auth/cadastro" className="underline">Cadastrar</Link>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {state.isLoading ? (
              <div className="p-6 border rounded-lg bg-muted/30 flex items-center gap-3">
                <Loader2 className="h-5 w-5 animate-spin" />
                Atualizando carrinho...
              </div>
            ) : (
              <CarrinhoItems />
            )}
            {state.itens.length > 0 && <CarrinhoEncouragement />}
          </div>
          
          <div className="lg:col-span-1 space-y-6">
            <CarrinhoResumo />
            <SelosSeguranca variant="full" showContact={true} />
          </div>
        </div>

        <div className="mt-12 flex justify-center">
          <div className="max-w-lg w-full p-6 border border-gray-200 rounded-lg bg-muted/30">
            <h3 className="text-lg font-medium mb-4 flex items-center">
              <ShoppingBag className="mr-2 h-5 w-5 text-primary" /> 
              Seu carrinho está vazio?
            </h3>
            <p className="text-muted-foreground mb-4">
              Explore nossa coleção de brinquedos e encontre o presente perfeito para as crianças!
            </p>
            <Link to="/loja">
              <Button className="w-full">Ver Catálogo</Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Checkout Rápido */}
      <CheckoutRapido 
        isOpen={showCheckoutRapido} 
        onClose={() => setShowCheckoutRapido(false)}
        variant="page"
      />
    </Layout>
  );
};

export default Carrinho;
