import React from 'react';
import { createPortal } from 'react-dom';
import CartToast from './CartToast';
import { CartToastData } from './CartToast';

interface CartToastContainerProps {
  toasts: CartToastData[];
  onRemoveToast: (id: string) => void;
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'top-center';
  className?: string;
}

const CartToastContainer: React.FC<CartToastContainerProps> = ({
  toasts,
  onRemoveToast,
  position = 'top-right',
  className = '',
}) => {
  const getPositionClasses = () => {
    switch (position) {
      case 'top-left':
        return 'top-4 left-4';
      case 'top-center':
        return 'top-4 left-1/2 transform -translate-x-1/2';
      case 'bottom-right':
        return 'bottom-4 right-4';
      case 'bottom-left':
        return 'bottom-4 left-4';
      default:
        return 'top-4 right-4';
    }
  };

  if (typeof window === 'undefined') return null;

  const container = document.getElementById('toast-container') || document.body;

  return createPortal(
    <div
      className={`fixed z-[9999] ${getPositionClasses()} space-y-2 pointer-events-none ${className}`}
      style={{ pointerEvents: 'none' }}
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto"
          style={{ pointerEvents: 'auto' }}
        >
          <CartToast
            toast={toast}
            onClose={onRemoveToast}
          />
        </div>
      ))}
    </div>,
    container
  );
};

export default CartToastContainer;
