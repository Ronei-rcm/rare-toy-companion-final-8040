import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X, ShoppingBag, Clock, Gift, ArrowRight, Percent } from 'lucide-react';
import { useCartRecovery } from '@/hooks/useCartRecovery';
import { useCart } from '@/contexts/CartContext';
import { cn } from '@/lib/utils';

interface CartRecoveryBannerProps {
  className?: string;
}

const CartRecoveryBanner: React.FC<CartRecoveryBannerProps> = ({ className }) => {
  const { showRecoveryBanner, recoveryData, restoreCart, clearRecoveryData, setShowRecoveryBanner } = useCartRecovery();
  const { setCartOpen } = useCart();

  if (!showRecoveryBanner || !recoveryData) return null;

  const timeAgo = Math.floor((Date.now() - recoveryData.lastActivity) / (1000 * 60)); // minutos
  const isHighValue = recoveryData.totalValue > 100;
  const isMultipleItems = recoveryData.itemCount > 1;

  const getUrgencyMessage = () => {
    if (timeAgo < 5) return "Você acabou de sair!";
    if (timeAgo < 15) return "Ainda está por aí?";
    if (timeAgo < 30) return "Seu carrinho está esperando!";
    return "Não perca seus itens selecionados!";
  };

  const getIncentiveMessage = () => {
    if (isHighValue) return "Complete sua compra e ganhe frete grátis!";
    if (isMultipleItems) return "Que tal finalizar essa seleção incrível?";
    return "Finalize sua compra em poucos cliques!";
  };

  const handleRestoreCart = () => {
    restoreCart();
    setCartOpen(true);
    setShowRecoveryBanner(false);
  };

  const handleDismiss = () => {
    setShowRecoveryBanner(false);
  };

  return (
    <div className={cn("fixed top-4 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md mx-4", className)}>
      <Card className="border-2 border-primary/20 bg-gradient-to-r from-primary/5 to-secondary/5 shadow-lg animate-in slide-in-from-top-4 duration-500">
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-primary/10 rounded-full">
                <ShoppingBag className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-sm">Carrinho Salvo</h3>
                <p className="text-xs text-muted-foreground">{getUrgencyMessage()}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-muted-foreground hover:text-foreground"
              onClick={handleDismiss}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>

          <div className="space-y-3">
            {/* Informações do carrinho */}
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Clock className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">
                  {timeAgo} min atrás
                </span>
              </div>
              <Badge variant="secondary" className="text-xs">
                {recoveryData.itemCount} item{recoveryData.itemCount !== 1 ? 's' : ''}
              </Badge>
            </div>

            {/* Valor do carrinho */}
            <div className="bg-muted/30 rounded-md p-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Valor total:</span>
                <span className="font-semibold text-primary">
                  R$ {recoveryData.totalValue.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Incentivo */}
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Gift className="h-3 w-3" />
              <span>{getIncentiveMessage()}</span>
            </div>

            {/* Botões de ação */}
            <div className="flex gap-2">
              <Button
                onClick={handleRestoreCart}
                size="sm"
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                <ShoppingBag className="h-3 w-3 mr-1" />
                Restaurar Carrinho
              </Button>
              <Button
                onClick={handleDismiss}
                variant="outline"
                size="sm"
                className="px-3"
              >
                Depois
              </Button>
            </div>

            {/* Oferta especial */}
            {isHighValue && (
              <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded-md">
                <div className="flex items-center gap-2 text-xs text-green-700">
                  <Percent className="h-3 w-3" />
                  <span className="font-medium">Oferta especial: 5% OFF no PIX!</span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CartRecoveryBanner;