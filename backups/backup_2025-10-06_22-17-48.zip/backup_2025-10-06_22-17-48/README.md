# Rare Toy Companion

## Visão Geral

Aplicação React + Vite + Tailwind com servidor Node/Express para gerenciamento de coleções de brinquedos raros. Sistema completo com painel administrativo, API RESTful, upload de imagens e gerenciamento de conteúdo dinâmico. Orquestração local com PM2 e suporte opcional a Docker para serviços (ex.: MySQL).

## ✨ Funcionalidades Principais

### 🎯 **Frontend Público**
- **Página Inicial**: Hero section com carrossel de imagens
- **Marketplace**: Catálogo de produtos com filtros e busca
- **Loja**: Seção de produtos em destaque
- **Eventos**: Calendário e informações de eventos
- **Sobre**: Página institucional com equipe, valores e estatísticas
- **Coleções**: Páginas dinâmicas de coleções de brinquedos

### 🛠️ **Painel Administrativo**
- **Gerenciamento de Coleções**: CRUD completo com upload de imagens
- **Gerenciamento de Produtos**: Catálogo com categorias e tags
- **Gerenciamento de Eventos**: Calendário e conteúdo dinâmico
- **Gerenciamento de Funcionários**: Sistema completo de RH com folha de pagamento
- **Gerenciamento Financeiro**: Controle total de receitas, despesas e integração
- **Gerenciamento de Fornecedores**: Cadastro e controle de fornecedores
- **Gerenciamento de Clientes**: Cadastro e relacionamento com clientes
- **Gerenciamento de Conteúdo**: Página "Sobre" totalmente editável
- **Upload de Imagens**: Sistema robusto com preview e validação
- **Drag & Drop**: Reordenação intuitiva de itens

### 🔧 **API Backend**
- **RESTful API**: Endpoints completos para todas as funcionalidades
- **Upload de Imagens**: Suporte a multipart/form-data e base64
- **Paginação e Filtros**: Sistema avançado de consultas
- **Validação de Dados**: Middleware de validação robusto
- **CORS e Segurança**: Configurações de segurança implementadas
- **Sistema de Pagamento**: PIX com QR Code automático
- **WhatsApp Business**: Webhook e automação de mensagens

## Requisitos

- Node.js LTS (sugestão: gerenciar com nvm)
- npm
- PM2 global (`npm i -g pm2`)
- Opcional: Docker/Docker Compose para serviços

## Desenvolvimento

Clone o repositório e instale dependências:

```sh
git clone <SUA_URL_GIT>
cd <NOME_DO_SEU_PROJETO>
npm i
npm run dev
```

## Execução com PM2

PM2 é usado para gerenciar o backend Node (`server.cjs`) e o preview do frontend Vite.

Arquitetura PM2: ver `ecosystem.config.cjs`.

Comandos principais:

```sh
# Iniciar todos os apps definidos
pm2 start ecosystem.config.cjs

# Ver logs
pm2 logs

# Status
pm2 status

# Reiniciar
pm2 restart all

# Parar
pm2 stop all
```

### Variáveis de Ambiente (Frontend)

- Defina a base da API no frontend via `VITE_API_URL`. Recomendado usar same-origin com proxy:

```
VITE_API_URL=/api
```

- Em produção, configure seu proxy/reverso (ex.: Nginx) para encaminhar `/api` ao backend Node (porta 3001):

```
location /api/ {
  proxy_pass http://127.0.0.1:3001/api/;
  proxy_http_version 1.1;
  proxy_set_header Host $host;
  proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
}
```

Após editar `.env`/`.env.production`, faça o rebuild:

```
npm run build && pm2 reload web-frontend
```

## Scripts npm úteis

- `npm run dev`: inicia Vite em modo desenvolvimento
- `npm run build`: build de produção
- `npm run preview:pm2`: preview de produção na porta 8040
- `npm run server`: inicia `server.cjs` (Node/Express)
- `npm run dev:full`: inicia servidor e Vite em paralelo
- `npm run docker:*`: auxiliares para subir/derrubar serviços docker
- `npm run mysql:test`: teste de conexão com MySQL
- `npm run backup`: gera backup zipado com carimbo de data/hora

## 🚀 Tecnologias

### **Frontend**
- **React 18** - Biblioteca de interface
- **TypeScript** - Tipagem estática
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Framework de estilos
- **shadcn/ui** - Componentes de interface
- **Framer Motion** - Animações e transições
- **React Query** - Gerenciamento de estado e cache
- **React Router** - Roteamento
- **Sonner** - Notificações toast

### **Backend**
- **Node.js** - Runtime JavaScript
- **Express.js** - Framework web
- **MySQL** - Banco de dados relacional
- **Multer** - Upload de arquivos
- **CORS** - Cross-origin resource sharing
- **dotenv** - Gerenciamento de variáveis de ambiente

### **DevOps & Deploy**
- **PM2** - Gerenciador de processos
- **Docker** - Containerização (opcional)
- **Git** - Controle de versão
- **WhatsApp Webhook Server** - Servidor dedicado para webhook (porta 3002)

## 📁 Estrutura do Projeto

```
rare-toy-companion-final-8040/
├── src/
│   ├── components/          # Componentes reutilizáveis
│   ├── pages/              # Páginas da aplicação
│   │   ├── admin/          # Painel administrativo
│   │   └── public/         # Páginas públicas
│   ├── api/                # Serviços de API
│   ├── hooks/              # Custom hooks
│   └── utils/              # Utilitários
├── public/                 # Arquivos estáticos
├── server.cjs             # Servidor Node.js principal
├── whatsapp-webhook-server.js # Servidor webhook WhatsApp
├── proxy-server.cjs       # Proxy para frontend
├── ecosystem.config.cjs   # Configuração PM2
├── package.json           # Dependências e scripts
├── MANUAL_WHATSAPP.md     # Manual de configuração WhatsApp
├── PRÓXIMOS_PASSOS.md     # Roadmap e próximas funcionalidades
└── README.md             # Documentação principal
```

## 🎨 Funcionalidades Detalhadas

### **Gerenciamento de Coleções**
- ✅ CRUD completo (Criar, Ler, Atualizar, Deletar)
- ✅ Upload de imagens com preview
- ✅ Reordenação por drag & drop
- ✅ Sistema de tags e categorias
- ✅ Status ativo/inativo
- ✅ Paginação e filtros avançados
- ✅ URLs amigáveis (slugs)

### **Gerenciamento de Produtos**
- ✅ Catálogo completo com imagens
- ✅ Vinculação com coleções (relacionamento many-to-many)
- ✅ Sistema de categorias e tags
- ✅ Preços e descrições detalhadas
- ✅ Status de disponibilidade

### **Sistema de Gestão de Funcionários (RH)**
- ✅ **CRUD Completo**: Cadastro, edição e exclusão de funcionários
- ✅ **Dados Pessoais**: Nome, email, telefone, CPF, RG, endereço completo
- ✅ **Dados Profissionais**: Cargo, departamento, salário, tipo de contrato
- ✅ **Sistema de Benefícios**: 10+ benefícios configuráveis por funcionário
- ✅ **Folha de Pagamento**: Controle de salários, descontos e horas extras
- ✅ **Status de Funcionários**: Ativo, inativo, férias, licença
- ✅ **Filtros e Busca**: Por nome, cargo, departamento e status
- ✅ **Dashboard de RH**: Estatísticas e métricas em tempo real
- ✅ **Integração Financeira**: Exportação automática para módulo financeiro

### **Página "Sobre" Dinâmica**
- ✅ **Seção Hero**: Título, subtítulo, descrição e imagem
- ✅ **Valores da Empresa**: Lista editável com ícones
- ✅ **Equipe**: Membros com fotos, cargos e descrições
- ✅ **Estatísticas**: Números e métricas da empresa
- ✅ **Contato**: Informações de contato organizadas por tipo
- ✅ **Upload de Imagens**: Sistema específico para cada seção

### **Sistema de Upload**
- ✅ Suporte a múltiplos formatos (JPG, PNG, GIF, WebP)
- ✅ Validação de tamanho e tipo
- ✅ Preview em tempo real
- ✅ Otimização automática
- ✅ URLs absolutas e relativas

### **Sistema Financeiro Integrado**
- ✅ **Dashboard em Tempo Real**: Métricas avançadas e KPIs financeiros
- ✅ **Controle de Receitas**: Integração automática com vendas e eventos
- ✅ **Controle de Despesas**: Integração com fornecedores e funcionários
- ✅ **Sistema de Metas**: Definição e acompanhamento de objetivos financeiros
- ✅ **Análise de Tendências**: IA para previsões e insights financeiros
- ✅ **Relatórios Avançados**: Exportação em CSV, JSON e TXT
- ✅ **Alertas Inteligentes**: Notificações para baixo faturamento e gastos elevados
- ✅ **Integração Total**: Funcionários, fornecedores, vendas e eventos
- ✅ **Fluxo de Caixa**: Controle mensal de entradas e saídas
- ✅ **Transações Manuais**: Lançamentos financeiros personalizados

### **Sistema de Pagamento PIX**
- ✅ Configuração de chave PIX (email, CPF, CNPJ, telefone, aleatória)
- ✅ Geração de QR Code automático no carrinho
- ✅ Código PIX copia e cola
- ✅ Integração com checkout completo
- ✅ Validação de configurações

### **WhatsApp Business Integration**
- ✅ Webhook para receber mensagens automaticamente
- ✅ Comandos automáticos (!catalogo, !pedido, !contato, !status, !ajuda)
- ✅ Respostas automáticas para saudações
- ✅ Envio manual de mensagens via painel
- ✅ Estatísticas em tempo real
- ✅ Histórico completo de conversas
- ✅ Validação de assinatura de webhook

### **Interface Administrativa**
- ✅ Design moderno com glassmorphism
- ✅ Animações suaves com Framer Motion
- ✅ Validação de formulários em tempo real
- ✅ Feedback visual com toasts
- ✅ Responsividade completa
- ✅ Tema consistente com gradientes

## 💾 Backup e Restauração

O projeto inclui um script de backup que gera um `.zip` com carimbo de data/hora contendo código, configs e, se possível, dump do MySQL via Docker Compose.

Gerar backup:

```sh
npm run backup
```

O arquivo será salvo em `backups/backup_YYYY-MM-DD_HH-MM-SS.zip`.

Observações:

- Se o serviço `mysql` existir no `docker-compose.yml` e estiver rodando, o script tentará extrair um dump (`mysql_dump.sql`). Caso a senha seja solicitada, configure `MYSQL_PWD` antes de rodar o comando ou adapte as variáveis de ambiente no script.
- O backup ignora `node_modules` e `.git`.

O script de backup (`scripts/backup.sh`) cria o diretório `backups/` (se não existir) e zipa o projeto com timestamp. Se houver serviços de banco (ex.: MySQL via Docker), ele tenta incluir um dump — revise variáveis no script conforme seu ambiente.

Restauração (manual):

1. Extraia o `.zip` desejado em um diretório de trabalho.
2. Se houver `mysql_dump.sql`, importe no banco de dados alvo.

## 🔌 API Endpoints

### **Coleções**
- `GET /api/collections` - Listar coleções (com paginação e filtros)
- `POST /api/collections` - Criar nova coleção
- `PUT /api/collections/:id` - Atualizar coleção
- `DELETE /api/collections/:id` - Deletar coleção
- `GET /api/collections/slug/:slug` - Buscar por slug
- `PUT /api/collections/reorder` - Reordenar coleções
- `PATCH /api/collections/:id` - Atualizar campos específicos

### **Produtos**
- `GET /api/produtos` - Listar produtos
- `POST /api/produtos` - Criar produto
- `PUT /api/produtos/:id` - Atualizar produto
- `DELETE /api/produtos/:id` - Deletar produto

### **Coleções + Produtos**
- `GET /api/collections/:id/products` - Produtos de uma coleção
- `POST /api/collections/:id/products` - Adicionar produto à coleção
- `DELETE /api/collections/:id/products/:productId` - Remover produto da coleção
- `PUT /api/collections/:id/products/reorder` - Reordenar produtos na coleção

### **Página Sobre**
- `GET /api/sobre/content` - Conteúdo das seções
- `PUT /api/sobre/content/:section` - Atualizar seção específica
- `GET /api/sobre/values` - Valores da empresa
- `POST /api/sobre/values` - Criar valor
- `PUT /api/sobre/values/:id` - Atualizar valor
- `DELETE /api/sobre/values/:id` - Deletar valor
- `GET /api/sobre/team` - Membros da equipe
- `POST /api/sobre/team` - Criar membro
- `PUT /api/sobre/team/:id` - Atualizar membro
- `DELETE /api/sobre/team/:id` - Deletar membro
- `GET /api/sobre/stats` - Estatísticas
- `POST /api/sobre/stats` - Criar estatística
- `PUT /api/sobre/stats/:id` - Atualizar estatística
- `DELETE /api/sobre/stats/:id` - Deletar estatística
- `GET /api/sobre/contact` - Informações de contato
- `POST /api/sobre/contact` - Criar informação de contato
- `PUT /api/sobre/contact/:id` - Atualizar informação de contato
- `DELETE /api/sobre/contact/:id` - Deletar informação de contato

### **Upload de Imagens**
- `POST /api/sobre/upload-image` - Upload geral para página sobre
- `POST /api/sobre/team/:id/image` - Upload específico para membro da equipe

### **Sistema de Pagamento PIX**
- `POST /api/orders/:id/pix` - Gerar QR Code PIX para pedido
- `GET /api/orders/:id/status` - Consultar status de pagamento
- `POST /api/orders/:id/confirm-payment` - Confirmar pagamento (simulado)
- `POST /api/cart/pix-qr` - Gerar QR Code PIX para carrinho

### **WhatsApp Business API**
- `GET /api/whatsapp/config` - Obter configurações WhatsApp
- `PUT /api/whatsapp/config` - Salvar configurações WhatsApp
- `POST /api/whatsapp/test-webhook` - Testar webhook
- `GET /api/whatsapp/stats` - Estatísticas de mensagens
- `POST /api/whatsapp/send-message` - Enviar mensagem manual
- `GET /api/whatsapp/messages` - Listar mensagens (com paginação)

### **Configurações Gerais**
- `GET /api/settings` - Obter todas as configurações
- `PUT /api/settings` - Salvar configurações (PIX, WhatsApp, etc.)

## 🚀 Implantação

### Produção com PM2

1. Configure `.env` com a API local (proxy via Nginx):
```
VITE_API_URL=/api
```
2. Build do frontend e iniciar apps:
```
npm run build
pm2 start ecosystem.config.cjs
```
3. Verifique processos e logs:
```
pm2 status
pm2 logs
```

### Reverse Proxy (Nginx)

Exemplo de configuração para `muhlstore.re9suainternet.com.br` servindo o build do frontend e proxy para a API em 3001:

```
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name muhlstore.re9suainternet.com.br;

    ssl_certificate /etc/letsencrypt/live/muhlstore.re9suainternet.com.br/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/muhlstore.re9suainternet.com.br/privkey.pem; # managed by Certbot

    root /home/git-muhlstore/rare-toy-companion-final-8040/dist;
    index index.html;

    # API backend
    location /api/ {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Uploads gerados pela API
    location /lovable-uploads/ {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }

    # WhatsApp Webhook (se habilitado)
    location /whatsapp-webhook/ {
        proxy_pass http://127.0.0.1:3002/webhook;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # SPA fallback
    location / {
        try_files $uri $uri/ /index.html;
    }
}

server {
    listen 80;
    listen [::]:80;
    server_name muhlstore.re9suainternet.com.br;
    return 301 https://$server_name$request_uri;
}
```

Após alterar arquivos em `/etc/nginx/sites-available`, valide e recarregue:
```
sudo nginx -t && sudo systemctl restart nginx
```

### SSL (Let's Encrypt)

Gerar/renovar certificados automaticamente com certbot (modo nginx):
```
sudo certbot --nginx -d muhlstore.re9suainternet.com.br
```

### Troubleshooting de Rede

- As portas 80 e 443 devem estar liberadas no firewall/perímetro.
- Valide escuta local:
```
sudo ss -tulpn | grep -E ':80|:443'
```
- Teste HTTP/HTTPS local:
```
curl -I http://127.0.0.1/
curl -I https://127.0.0.1/ -k
```

## Segurança e Boas Práticas

- Variáveis sensíveis em `.env` (nunca commitar)
- Validação de entrada e limites de payload na API
- CORS e rate limiting configuráveis no servidor
- Validação de assinatura de webhook WhatsApp
- Atualize dependências e revise permissões de produção

## 📚 Documentação Adicional

- **[Manual de Configuração WhatsApp](./MANUAL_WHATSAPP.md)** - Guia completo para configurar WhatsApp Business API
- **[Próximos Passos](./PRÓXIMOS_PASSOS.md)** - Roadmap de funcionalidades e melhorias futuras

## 🔧 Troubleshooting WhatsApp

### Problemas Comuns

1. **Webhook não verificado**
   ```bash
   # Teste a conectividade
   curl -X GET "https://seu-dominio.com:3002/webhook?hub.mode=subscribe&hub.verify_token=seu-secret&hub.challenge=test"
   ```

2. **Mensagens não chegam**
   ```bash
   # Verifique logs do webhook
   pm2 logs whatsapp-webhook
   ```

3. **Token expirado**
   - Tokens temporários expiram em 24h
   - Gere novo token no Meta Business Manager
   - Atualize no painel administrativo

4. **Comandos não funcionam**
   - Verifique se resposta automática está ativada
   - Confirme processamento nos logs
   - Teste com mensagens simples primeiro
