const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.SERVER_PORT || 3001;

// Middleware
app.use(cors({
  origin: [
    'http://localhost:8040', 
    'http://localhost:3000', 
    'http://127.0.0.1:8040',
    'http://localhost:8040',
    'http://172.16.0.15:8040',
    'http://172.17.0.1:8040',
    'http://172.18.0.1:8040',
    'http://172.19.0.1:8040',
    'http://177.67.33.248:8040',
    'https://muhlstore.re9suainternet.com.br'
  ],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
// Cookies para identificar carrinho anônimo
const cookieParser = require('cookie-parser');
app.use(cookieParser());

// Behind nginx proxy
app.set('trust proxy', true);

// Helper to build absolute URL honoring proxy proto/host
function getPublicUrl(req, pathOrUrl) {
  if (!pathOrUrl) return null;
  if (/^https?:\/\//i.test(pathOrUrl)) return pathOrUrl;
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.get('host');
  const normalized = pathOrUrl.startsWith('/') ? pathOrUrl : `/${pathOrUrl}`;
  return `${proto}://${host}${normalized}`;
}

// Normalize any absolute http(s) URL to this host/proto. If relative, keep relative semantics.
function normalizeToThisOrigin(req, urlOrPath) {
  try {
    if (!urlOrPath) return null;
    if (!/^https?:\/\//i.test(urlOrPath)) {
      // Already relative; make it absolute with current origin
      return getPublicUrl(req, urlOrPath);
    }
    const u = new URL(urlOrPath);
    // Preserve path/search; rebuild on current origin
    const rebuilt = `${(req.headers['x-forwarded-proto'] || req.protocol || 'http')}://${(req.headers['x-forwarded-host'] || req.get('host'))}${u.pathname}${u.search || ''}`;
    return rebuilt;
  } catch {
    return getPublicUrl(req, urlOrPath);
  }
}

// Extrai o caminho de uploads mesmo quando a URL veio duplicada com host (ex.: http://host/http://host/.../lovable-uploads/arquivo.jpg)
function extractUploadPath(urlOrPath) {
  if (!urlOrPath || typeof urlOrPath !== 'string') return null;
  const marker = '/lovable-uploads/';
  const idx = urlOrPath.lastIndexOf(marker);
  if (idx >= 0) {
    return urlOrPath.slice(idx);
  }
  return urlOrPath.startsWith('/') ? urlOrPath : `/${urlOrPath}`;
}

// Corrigir URLs duplicadas do tipo /http://host/... → redirecionar para o caminho correto
app.get(/^\/https?:\/\/[^/]+(\/.*)$/i, (req, res) => {
  try {
    const match = req.path.match(/^\/https?:\/\/[^/]+(\/.*)$/i);
    const target = match && match[1] ? match[1] : '/';
    return res.redirect(301, target);
  } catch (e) {
    return res.status(404).end();
  }
});

// Serve static files from public directory (com headers para evitar ORB)
app.use('/lovable-uploads', (req, res, next) => {
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('Access-Control-Allow-Origin', '*');
  next();
}, express.static(path.join(__dirname, 'public/lovable-uploads')));
// Também servir uploads padrão
// servir /uploads do mesmo diretório base do multer
app.use('/uploads', (req, res, next) => {
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('Access-Control-Allow-Origin', '*');
  next();
}, express.static(path.join(__dirname, 'public')));
// Logar chaves do body para rotas de coleções
app.use((req, _res, next) => {
  if (req.path.startsWith('/api/collections')) {
    try {
      const keys = req.body && typeof req.body === 'object' ? Object.keys(req.body) : [];
      console.log(`📥 ${req.method} ${req.path}`, keys.length ? { keys } : {});
    } catch {}
  }
  next();
});

// Fallback: se o frontend pedir apenas o nome do arquivo (ex.: 1758....jpg),
// tentamos servir a partir de /public/uploads/collections ou /public/lovable-uploads
app.get('/:fileName', async (req, res, next) => {
  try {
    const fileName = req.params.fileName;
    if (!fileName || !/(\.jpg|\.jpeg|\.png|\.webp)$/i.test(fileName)) return next();
  const tryPaths = [
      path.join(__dirname, 'public', 'lovable-uploads', fileName),
      path.join(__dirname, 'public', fileName)
    ];
    for (const p of tryPaths) {
      if (fs.existsSync(p)) {
        return res.sendFile(p);
      }
    }
    return res.status(404).send('Not found');
  } catch (_) {
    return next();
  }
});

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'public/lovable-uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    cb(null, uniqueSuffix + extension);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  }
});

// MySQL connection pool
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST || '127.0.0.1',
  user: process.env.MYSQL_USER || 'root',
  password: process.env.MYSQL_PASSWORD || 'RSM_Rg51gti66',
  database: process.env.MYSQL_DATABASE || 'rare_toy_companion',
  port: parseInt(process.env.MYSQL_PORT || '3307'),
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  acquireTimeout: 60000,
  timeout: 60000,
  reconnect: true,
  ssl: false
});

// Transform database item to frontend format
function transformCarouselItem(dbItem, req) {
  return {
    id: dbItem.id || '',
    nome: dbItem.title || '',
    imagem: normalizeToThisOrigin(req, dbItem.image_url || ''),
    badge: dbItem.badge || 'Novo',
    descricao: dbItem.subtitle || '',
    ativo: dbItem.active === 1 || dbItem.active === true,
    order_index: dbItem.order_index || 0,
    button_text: dbItem.button_text || 'Ver Mais',
    button_link: dbItem.button_link || '#'
  };
}

// Transform frontend item to database format
const transformToDatabase = (item) => ({
  id: item.id || null,
  title: item.nome || null,
  subtitle: item.descricao || null,
  image_url: item.imagem || null,
  badge: item.badge || null,
  button_text: item.button_text || 'Ver Mais',
  button_link: item.button_link || '#',
  active: item.ativo !== undefined ? item.ativo : false,
  order_index: item.order_index || 0
});

// Filter out undefined values to prevent SQL errors
const filterUndefined = (obj) => {
  const filtered = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      filtered[key] = value;
    }
  }
  return filtered;
};

// Routes

// GET /api/carousel - Get all carousel items
app.get('/api/carousel', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM carousel_items ORDER BY order_index ASC, created_at ASC'
    );
    const items = rows.map(row => transformCarouselItem(row, req));
    res.json(items);
  } catch (error) {
    console.error('Error fetching carousel items:', error);
    res.status(500).json({ error: 'Failed to fetch carousel items' });
  }
});

// GET /api/carousel/active - Get active carousel items only
app.get('/api/carousel/active', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM carousel_items WHERE active = true ORDER BY order_index ASC, created_at ASC'
    );
    const items = rows.map(row => transformCarouselItem(row, req));
    res.json(items);
  } catch (error) {
    console.error('Error fetching active carousel items:', error);
    res.status(500).json({ error: 'Failed to fetch active carousel items' });
  }
});

// POST /api/carousel - Create new carousel item
app.post('/api/carousel', async (req, res) => {
  try {
    const item = req.body;
    const dbItem = filterUndefined(transformToDatabase(item));
    const newId = require('crypto').randomUUID();
    
    const [result] = await pool.execute(
      `INSERT INTO carousel_items 
       (id, title, subtitle, image_url, badge, button_text, button_link, active, order_index, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        newId,
        dbItem.title,
        dbItem.subtitle,
        dbItem.image_url,
        dbItem.badge,
        dbItem.button_text,
        dbItem.button_link,
        dbItem.active,
        dbItem.order_index
      ]
    );

    // Fetch the created item
    const [rows] = await pool.execute('SELECT * FROM carousel_items WHERE id = ?', [newId]);
    const createdItem = transformCarouselItem(rows[0]);
    
    res.status(201).json(createdItem);
  } catch (error) {
    console.error('Error creating carousel item:', error);
    res.status(500).json({ error: 'Failed to create carousel item' });
  }
});

// PUT /api/carousel/:id - Update carousel item
app.put('/api/carousel/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const item = req.body;
    const dbItem = filterUndefined(transformToDatabase(item));
    
    await pool.execute(
      `UPDATE carousel_items 
       SET title = ?, subtitle = ?, image_url = ?, button_text = ?, button_link = ?, 
           active = ?, order_index = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        dbItem.title,
        dbItem.subtitle,
        dbItem.image_url,
        dbItem.button_text,
        dbItem.button_link,
        dbItem.active,
        dbItem.order_index,
        id
      ]
    );

    // Fetch the updated item
    const [rows] = await pool.execute('SELECT * FROM carousel_items WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Carousel item not found' });
    }
    
    const updatedItem = transformCarouselItem(rows[0]);
    res.json(updatedItem);
  } catch (error) {
    console.error('Error updating carousel item:', error);
    res.status(500).json({ error: 'Failed to update carousel item' });
  }
});

// DELETE /api/carousel/:id - Delete carousel item
app.delete('/api/carousel/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const [result] = await pool.execute('DELETE FROM carousel_items WHERE id = ?', [id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Carousel item not found' });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting carousel item:', error);
    res.status(500).json({ error: 'Failed to delete carousel item' });
  }
});

// PUT /api/carousel/:id/toggle - Toggle item active status
app.put('/api/carousel/:id/toggle', async (req, res) => {
  try {
    const { id } = req.params;
    const { ativo } = req.body;
    
    await pool.execute(
      'UPDATE carousel_items SET active = ?, updated_at = NOW() WHERE id = ?',
      [ativo, id]
    );

    // Fetch the updated item
    const [rows] = await pool.execute('SELECT * FROM carousel_items WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Carousel item not found' });
    }
    
    const updatedItem = transformCarouselItem(rows[0]);
    res.json(updatedItem);
  } catch (error) {
    console.error('Error toggling carousel item:', error);
    res.status(500).json({ error: 'Failed to toggle carousel item' });
  }
});

// POST /api/carousel/bulk - Save all carousel items (bulk update)
app.post('/api/carousel/bulk', async (req, res) => {
  try {
    const items = req.body;
    
    // Start transaction
    const connection = await pool.getConnection();
    await connection.beginTransaction();
    
    try {
      // Get all existing items
      const [existingRows] = await connection.execute('SELECT id FROM carousel_items');
      const existingIds = new Set(existingRows.map(row => row.id));
      const newItemIds = new Set(items.map(item => item.id));

      // Delete items that were removed
      for (const existingRow of existingRows) {
        if (!newItemIds.has(existingRow.id)) {
          await connection.execute('DELETE FROM carousel_items WHERE id = ?', [existingRow.id]);
        }
      }

      // Update or create items
      for (let i = 0; i < items.length; i++) {
        const item = { ...items[i], order_index: i };
        const dbItem = filterUndefined(transformToDatabase(item));
        
        if (existingIds.has(item.id)) {
          // Update existing item
          await connection.execute(
            `UPDATE carousel_items 
             SET title = ?, subtitle = ?, image_url = ?, button_text = ?, button_link = ?, 
                 active = ?, order_index = ?, updated_at = NOW()
             WHERE id = ?`,
            [
              dbItem.title,
              dbItem.subtitle,
              dbItem.image_url,
              dbItem.button_text,
              dbItem.button_link,
              dbItem.active,
              dbItem.order_index,
              item.id
            ]
          );
        } else {
          // Create new item
          const newId = item.id || require('crypto').randomUUID();
          await connection.execute(
            `INSERT INTO carousel_items 
             (id, title, subtitle, image_url, button_text, button_link, active, order_index, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
            [
              newId,
              dbItem.title,
              dbItem.subtitle,
              dbItem.image_url,
              dbItem.button_text,
              dbItem.button_link,
              dbItem.active,
              dbItem.order_index
            ]
          );
        }
      }

      await connection.commit();
      res.json({ success: true });
      
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
    
  } catch (error) {
    console.error('Error saving carousel items:', error);
    res.status(500).json({ error: 'Failed to save carousel items' });
  }
});

// POST /api/upload - Upload image
app.post('/api/upload', upload.single('image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      filename: req.file.filename
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Upload failed', message: error.message });
  }
});

// ==================== PRODUTOS API ====================

// Buscar todos os produtos
app.get('/api/produtos', async (req, res) => {
  try {
    console.log('🔄 Buscando produtos...');
    const [rows] = await pool.execute(`
      SELECT 
        id, nome, descricao, preco, imagem_url as imagemUrl, categoria, estoque, 
        status, destaque, promocao, lancamento, avaliacao, total_avaliacoes as totalAvaliacoes,
        faixa_etaria as faixaEtaria, peso, dimensoes, material, marca, origem, fornecedor,
        codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt
      FROM products 
      ORDER BY created_at DESC
    `);
    
    console.log(`✅ ${rows.length} produtos encontrados`);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produtos = rows.map(produto => ({
      ...produto,
      preco: parseFloat(produto.preco),
      avaliacao: produto.avaliacao ? parseFloat(produto.avaliacao) : null,
      imagemUrl: produto.imagemUrl ? getPublicUrl(req, produto.imagemUrl) : null
    }));
    
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar produtos em destaque
app.get('/api/produtos/destaque', async (req, res) => {
  try {
    console.log('🔄 Buscando produtos em destaque...');
    
    const [rows] = await pool.execute(
      'SELECT *, imagem_url as imagemUrl, total_avaliacoes as totalAvaliacoes, faixa_etaria as faixaEtaria, codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt FROM products WHERE destaque = true ORDER BY created_at DESC'
    );
    
    console.log(`✅ ${rows.length} produtos em destaque encontrados`);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produtos = rows.map(produto => ({
      ...produto,
      preco: parseFloat(produto.preco),
      avaliacao: produto.avaliacao ? parseFloat(produto.avaliacao) : null,
      imagemUrl: produto.imagemUrl ? getPublicUrl(req, produto.imagemUrl) : null
    }));
    
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos em destaque:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar todas as categorias com contagem de produtos
app.get('/api/categorias', async (req, res) => {
  try {
    console.log('🔄 Buscando categorias...');
    
    const [rows] = await pool.execute(`
      SELECT 
        categoria as nome,
        COUNT(*) as quantidade,
        MIN(preco) as precoMinimo,
        MAX(preco) as precoMaximo,
        AVG(avaliacao) as avaliacaoMedia,
        MAX(created_at) as ultimoProduto
      FROM products 
      WHERE status = 'ativo' 
      GROUP BY categoria 
      ORDER BY quantidade DESC, categoria ASC
    `);
    
    console.log(`✅ ${rows.length} categorias encontradas`);
    
    // Adicionar ícones e cores baseadas na categoria
    const categoriasComIcones = rows.map(categoria => {
      const iconMap = {
        'Action Figures': '⚔️',
        'Colecionáveis': '👑',
        'Vintage': '⭐',
        'Gaming': '🎮',
        'Edição Limitada': '🛡️',
        'Bonecos de Ação': '🤖',
        'Carrinhos': '🚗',
        'Bonecas': '👸',
        'Jogos': '🎲',
        'Colecionáveis': '💎'
      };
      
      const colorMap = {
        'Action Figures': 'from-blue-500 to-blue-600',
        'Colecionáveis': 'from-purple-500 to-purple-600',
        'Vintage': 'from-yellow-500 to-orange-500',
        'Gaming': 'from-green-500 to-green-600',
        'Edição Limitada': 'from-red-500 to-red-600',
        'Bonecos de Ação': 'from-indigo-500 to-indigo-600',
        'Carrinhos': 'from-orange-500 to-orange-600',
        'Bonecas': 'from-pink-500 to-pink-600',
        'Jogos': 'from-teal-500 to-teal-600',
        'Colecionáveis': 'from-amber-500 to-amber-600'
      };
      
      return {
        ...categoria,
        id: categoria.nome.toLowerCase().replace(/\s+/g, '-'),
        icon: iconMap[categoria.nome] || '📦',
        cor: colorMap[categoria.nome] || 'from-gray-500 to-gray-600',
        descricao: `Encontre ${categoria.quantidade} produtos incríveis`,
        precoMinimo: parseFloat(categoria.precoMinimo),
        precoMaximo: parseFloat(categoria.precoMaximo),
        avaliacaoMedia: categoria.avaliacaoMedia ? parseFloat(categoria.avaliacaoMedia).toFixed(1) : null
      };
    });
    
    res.json(categoriasComIcones);
  } catch (error) {
    console.error('❌ Erro ao buscar categorias:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar produtos por categoria
app.get('/api/produtos/categoria/:categoria', async (req, res) => {
  try {
    const { categoria } = req.params;
    console.log(`🔄 Buscando produtos da categoria: ${categoria}`);
    
    const [rows] = await pool.execute(
      'SELECT *, imagem_url as imagemUrl, total_avaliacoes as totalAvaliacoes, faixa_etaria as faixaEtaria, codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt FROM products WHERE categoria = ? ORDER BY created_at DESC',
      [categoria]
    );
    
    console.log(`✅ ${rows.length} produtos encontrados na categoria ${categoria}`);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produtos = rows.map(produto => ({
      ...produto,
      preco: parseFloat(produto.preco),
      avaliacao: produto.avaliacao ? parseFloat(produto.avaliacao) : null,
      imagemUrl: produto.imagemUrl ? getPublicUrl(req, produto.imagemUrl) : null
    }));
    
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos por categoria:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar estatísticas gerais da loja
app.get('/api/stats', async (req, res) => {
  try {
    console.log('🔄 Buscando estatísticas da loja...');
    
    const [statsRows] = await pool.execute(`
      SELECT 
        COUNT(*) as totalProdutos,
        COUNT(CASE WHEN status = 'ativo' THEN 1 END) as produtosAtivos,
        COUNT(CASE WHEN destaque = true THEN 1 END) as produtosDestaque,
        COUNT(CASE WHEN promocao = true THEN 1 END) as produtosPromocao,
        AVG(avaliacao) as avaliacaoMedia,
        SUM(total_avaliacoes) as totalAvaliacoes,
        MIN(preco) as precoMinimo,
        MAX(preco) as precoMaximo,
        AVG(preco) as precoMedio
      FROM products
    `);
    
    const [categoriasRows] = await pool.execute(`
      SELECT COUNT(DISTINCT categoria) as totalCategorias
      FROM products WHERE status = 'ativo'
    `);
    
    const stats = {
      ...statsRows[0],
      totalCategorias: categoriasRows[0].totalCategorias,
      avaliacaoMedia: statsRows[0].avaliacaoMedia ? parseFloat(statsRows[0].avaliacaoMedia).toFixed(1) : null,
      precoMedio: parseFloat(statsRows[0].precoMedio).toFixed(2)
    };
    
    console.log('✅ Estatísticas carregadas:', stats);
    res.json(stats);
  } catch (error) {
    console.error('❌ Erro ao buscar estatísticas:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar compras recentes simuladas (para demonstração)
app.get('/api/compras-recentes', async (req, res) => {
  try {
    console.log('🔄 Buscando compras recentes...');
    
    // Buscar produtos aleatórios para simular compras recentes
    const [rows] = await pool.execute(`
      SELECT 
        p.nome as produto,
        p.categoria,
        p.preco,
        p.imagem_url as imagemUrl,
        NOW() - INTERVAL FLOOR(RAND() * 1440) MINUTE as dataCompra,
        CONCAT(
          CASE FLOOR(RAND() * 4)
            WHEN 0 THEN 'João'
            WHEN 1 THEN 'Maria'
            WHEN 2 THEN 'Pedro'
            WHEN 3 THEN 'Ana'
          END,
          ' ',
          CASE FLOOR(RAND() * 4)
            WHEN 0 THEN 'Silva'
            WHEN 1 THEN 'Santos'
            WHEN 2 THEN 'Costa'
            WHEN 3 THEN 'Oliveira'
          END
        ) as cliente,
        CASE FLOOR(RAND() * 5)
          WHEN 0 THEN 'São Paulo'
          WHEN 1 THEN 'Rio de Janeiro'
          WHEN 2 THEN 'Belo Horizonte'
          WHEN 3 THEN 'Salvador'
          WHEN 4 THEN 'Brasília'
        END as cidade
      FROM products p
      WHERE p.status = 'ativo'
      ORDER BY RAND()
      LIMIT 10
    `);
    
    const compras = rows.map(compra => ({
      ...compra,
      preco: parseFloat(compra.preco),
      imagemUrl: compra.imagemUrl ? getPublicUrl(req, compra.imagemUrl) : null,
      tempoAtras: Math.floor(Math.random() * 30) + 1 // 1-30 minutos atrás
    }));
    
    console.log(`✅ ${compras.length} compras recentes simuladas`);
    res.json(compras);
  } catch (error) {
    console.error('❌ Erro ao buscar compras recentes:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar produto por ID
app.get('/api/produtos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando produto ID: ${id}`);
    
    const [rows] = await pool.execute(
      'SELECT *, imagem_url as imagemUrl, total_avaliacoes as totalAvaliacoes, faixa_etaria as faixaEtaria, codigo_barras as codigoBarras, data_lancamento as dataLancamento, created_at as createdAt, updated_at as updatedAt FROM products WHERE id = ?',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    console.log('✅ Produto encontrado:', rows[0].nome);
    
    // Converter preços de string para number e corrigir URLs de imagem
    const produto = {
      ...rows[0],
      preco: parseFloat(rows[0].preco),
      avaliacao: rows[0].avaliacao ? parseFloat(rows[0].avaliacao) : null,
      imagemUrl: rows[0].imagemUrl ? getPublicUrl(req, rows[0].imagemUrl) : null
    };
    
    res.json(produto);
  } catch (error) {
    console.error('❌ Erro ao buscar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Criar novo produto
app.post('/api/produtos', async (req, res) => {
  try {
    const produtoData = req.body;
    console.log('🔄 Criando produto:', produtoData.nome);
    
    // Criar produto com campos obrigatórios
    const [result] = await pool.execute(`
      INSERT INTO products (
        id, nome, preco, categoria, imagem_url, descricao, estoque, status,
        destaque, promocao, lancamento, avaliacao, total_avaliacoes,
        faixa_etaria, peso, dimensoes, material, marca, origem, fornecedor,
        codigo_barras, data_lancamento
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      require('crypto').randomUUID(),
      produtoData.nome,
      produtoData.preco,
      produtoData.categoria,
      produtoData.imagemUrl || null,
      produtoData.descricao || null,
      produtoData.estoque || 0,
      produtoData.status || 'ativo',
      produtoData.destaque || false,
      produtoData.promocao || false,
      produtoData.lancamento || false,
      produtoData.avaliacao || 0,
      produtoData.totalAvaliacoes || 0,
      produtoData.faixaEtaria || null,
      produtoData.peso || null,
      produtoData.dimensoes || null,
      produtoData.material || null,
      produtoData.marca || null,
      produtoData.origem || null,
      produtoData.fornecedor || null,
      produtoData.codigoBarras || null,
      produtoData.dataLancamento || null
    ]);
    
    console.log('✅ Produto criado com ID:', result.insertId);
    res.status(201).json({ id: result.insertId, ...produtoData });
  } catch (error) {
    console.error('❌ Erro ao criar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar produto
app.put('/api/produtos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const produtoData = req.body;
    console.log(`🔄 Atualizando produto ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE products SET 
        nome = ?, descricao = ?, preco = ?, imagem_url = ?, categoria = ?, 
        estoque = ?, status = ?, destaque = ?, promocao = ?, lancamento = ?,
        avaliacao = ?, total_avaliacoes = ?, faixa_etaria = ?, peso = ?, 
        dimensoes = ?, material = ?, marca = ?, origem = ?, fornecedor = ?,
        codigo_barras = ?, data_lancamento = ?, updated_at = NOW()
      WHERE id = ?
    `, [
      produtoData.nome,
      produtoData.descricao || null,
      produtoData.preco,
      produtoData.imagemUrl || null,
      produtoData.categoria,
      produtoData.estoque || 0,
      produtoData.status || 'ativo',
      produtoData.destaque || false,
      produtoData.promocao || false,
      produtoData.lancamento || false,
      produtoData.avaliacao || 0,
      produtoData.totalAvaliacoes || 0,
      produtoData.faixaEtaria || null,
      produtoData.peso || null,
      produtoData.dimensoes || null,
      produtoData.material || null,
      produtoData.marca || null,
      produtoData.origem || null,
      produtoData.fornecedor || null,
      produtoData.codigoBarras || null,
      produtoData.dataLancamento || null,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    console.log('✅ Produto atualizado');
    res.json({ id, ...produtoData });
  } catch (error) {
    console.error('❌ Erro ao atualizar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Deletar produto
app.delete('/api/produtos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando produto ID: ${id}`);
    
    const [result] = await pool.execute(
      'DELETE FROM products WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    console.log('✅ Produto deletado');
    res.json({ message: 'Produto deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// ==================== EVENTOS API ====================

// Buscar todos os eventos
app.get('/api/events', async (req, res) => {
  try {
    console.log('🔄 Buscando eventos...');
    const [rows] = await pool.execute(`
      SELECT 
        id, titulo, descricao, data_evento, local, numero_vagas,
        vagas_limitadas, imagem_url, ativo, feira_fechada, renda_total,
        participantes_confirmados, created_at, updated_at
      FROM events 
      ORDER BY data_evento ASC
    `);
    
    console.log(`✅ ${rows.length} eventos encontrados`);
    
    // Converter renda_total de string para number e corrigir URLs de imagem
    const eventos = rows.map(evento => ({
      ...evento,
      renda_total: evento.renda_total ? parseFloat(evento.renda_total) : null,
      imagem_url: evento.imagem_url ? getPublicUrl(req, evento.imagem_url) : null
    }));
    
    res.json(eventos);
  } catch (error) {
    console.error('❌ Erro ao buscar eventos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar evento por ID
app.get('/api/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando evento ID: ${id}`);
    
    const [rows] = await pool.execute(
      'SELECT * FROM events WHERE id = ?',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Evento encontrado:', rows[0].titulo);
    
    // Converter renda_total de string para number e corrigir URLs de imagem
    const evento = {
      ...rows[0],
      renda_total: rows[0].renda_total ? parseFloat(rows[0].renda_total) : null,
      imagem_url: rows[0].imagem_url ? getPublicUrl(req, rows[0].imagem_url) : null
    };
    
    res.json(evento);
  } catch (error) {
    console.error('❌ Erro ao buscar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Criar novo evento
app.post('/api/events', async (req, res) => {
  try {
    const eventoData = req.body;
    console.log('🔄 Criando evento:', eventoData.titulo);
    
    const [result] = await pool.execute(`
      INSERT INTO events (
        id, titulo, descricao, data_evento, local, numero_vagas,
        vagas_limitadas, imagem_url, ativo, feira_fechada, renda_total,
        participantes_confirmados
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      require('crypto').randomUUID(),
      eventoData.titulo,
      eventoData.descricao || null,
      eventoData.data_evento,
      eventoData.local || null,
      eventoData.numero_vagas || null,
      eventoData.vagas_limitadas || false,
      eventoData.imagem_url || null,
      eventoData.ativo !== false,
      eventoData.feira_fechada || false,
      eventoData.renda_total || null,
      eventoData.participantes_confirmados || null
    ]);
    
    console.log('✅ Evento criado com ID:', result.insertId);
    res.status(201).json({ id: result.insertId, ...eventoData });
  } catch (error) {
    console.error('❌ Erro ao criar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar evento
app.put('/api/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const eventoData = req.body;
    console.log(`🔄 Atualizando evento ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE events SET 
        titulo = ?, descricao = ?, data_evento = ?, local = ?,
        numero_vagas = ?, vagas_limitadas = ?, imagem_url = ?, ativo = ?,
        feira_fechada = ?, renda_total = ?, participantes_confirmados = ?, updated_at = NOW()
      WHERE id = ?
    `, [
      eventoData.titulo,
      eventoData.descricao || null,
      eventoData.data_evento,
      eventoData.local || null,
      eventoData.numero_vagas || null,
      eventoData.vagas_limitadas || false,
      eventoData.imagem_url || null,
      eventoData.ativo !== false,
      eventoData.feira_fechada || false,
      eventoData.renda_total || null,
      eventoData.participantes_confirmados || null,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Evento atualizado');
    res.json({ id, ...eventoData });
  } catch (error) {
    console.error('❌ Erro ao atualizar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Fechar feira e registrar renda total
app.post('/api/events/:id/fechar-feira', async (req, res) => {
  try {
    const { id } = req.params;
    const { renda_total, participantes_confirmados } = req.body;
    console.log(`🔄 Fechando feira do evento ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE events SET 
        feira_fechada = true, 
        renda_total = ?, 
        participantes_confirmados = ?,
        updated_at = NOW()
      WHERE id = ?
    `, [
      renda_total || 0,
      participantes_confirmados || 0,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Feira fechada com sucesso');
    res.json({ 
      message: 'Feira fechada com sucesso',
      renda_total: renda_total || 0,
      participantes_confirmados: participantes_confirmados || 0
    });
  } catch (error) {
    console.error('❌ Erro ao fechar feira:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Deletar evento
app.delete('/api/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando evento ID: ${id}`);
    
    const [result] = await pool.execute(
      'DELETE FROM events WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    console.log('✅ Evento deletado');
    res.json({ message: 'Evento deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// ================================
// ROTAS DE USUÁRIOS
// ================================

// Buscar todos os usuários
app.get('/api/users', async (req, res) => {
  try {
    console.log('🔄 Buscando usuários...');
    const [rows] = await pool.execute(`
      SELECT 
        id, email, avatar_url, nome, telefone, endereco, cidade, estado, cep,
        created_at, updated_at
      FROM users 
      ORDER BY created_at DESC
    `);
    
    console.log(`✅ ${rows.length} usuários encontrados`);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar usuários:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar usuário por ID
app.get('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando usuário ID: ${id}`);
    
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE id = ?',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }
    
    console.log('✅ Usuário encontrado:', rows[0].nome);
    res.json(rows[0]);
  } catch (error) {
    console.error('❌ Erro ao buscar usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Criar novo usuário
app.post('/api/users', async (req, res) => {
  try {
    const userData = req.body;
    console.log('🔄 Criando usuário:', userData.nome);
    
    const [result] = await pool.execute(`
      INSERT INTO users (
        id, email, avatar_url, nome, telefone, endereco, cidade, estado, cep
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      require('crypto').randomUUID(),
      userData.email,
      userData.avatar_url || null,
      userData.nome,
      userData.telefone || null,
      userData.endereco || null,
      userData.cidade || null,
      userData.estado || null,
      userData.cep || null
    ]);
    
    console.log('✅ Usuário criado com ID:', result.insertId);
    res.status(201).json({ id: result.insertId, ...userData });
  } catch (error) {
    console.error('❌ Erro ao criar usuário:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email já está em uso' });
    } else {
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
});

// Atualizar usuário
app.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const userData = req.body;
    console.log(`🔄 Atualizando usuário ID: ${id}`);
    
    const [result] = await pool.execute(`
      UPDATE users SET 
        email = ?, avatar_url = ?, nome = ?, telefone = ?, endereco = ?, cidade = ?, 
        estado = ?, cep = ?, updated_at = NOW()
      WHERE id = ?
    `, [
      userData.email,
      userData.avatar_url || null,
      userData.nome,
      userData.telefone || null,
      userData.endereco || null,
      userData.cidade || null,
      userData.estado || null,
      userData.cep || null,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }
    
    console.log('✅ Usuário atualizado');
    res.json({ message: 'Usuário atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar usuário:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email já está em uso' });
    } else {
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
});

// Deletar usuário
app.delete('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando usuário ID: ${id}`);
    
    const [result] = await pool.execute(
      'DELETE FROM users WHERE id = ?',
      [id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }
    
    console.log('✅ Usuário deletado');
    res.json({ message: 'Usuário deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Health check endpoint
// ===== COLECÕES API =====

// GET /api/collections - Buscar todas as coleções
app.get('/api/collections', async (req, res) => {
  try {
    const { admin, status } = req.query;
    // paginação e filtro
    const page = Math.max(parseInt(req.query.page || '1', 10), 1);
    const pageSize = Math.min(Math.max(parseInt(req.query.pageSize || '12', 10), 1), 100);
    const q = (req.query.q || '').toString().trim();
    const sort = (req.query.sort || 'created_at').toString();
    const order = ((req.query.order || 'desc').toString().toUpperCase() === 'ASC') ? 'ASC' : 'DESC';
    console.log('🔄 Buscando coleções...');
    
    // Verificar qual banco está sendo usado
    const [dbCheck] = await pool.execute('SELECT DATABASE() as current_db');
    console.log('📊 Banco atual:', dbCheck[0].current_db);
    
    const whereParts = [];
    const vals = [];
    if (q) { whereParts.push('(nome LIKE ? OR descricao LIKE ?)'); vals.push(`%${q}%`, `%${q}%`); }
    const whereSql = whereParts.length ? `WHERE ${whereParts.join(' AND ')}` : '';

    const allowSort = new Set(['created_at','updated_at','nome','id']);
    const sortCol = allowSort.has(sort) ? sort : 'created_at';

    const [countRows] = await pool.execute(`SELECT COUNT(*) as total FROM collections ${whereSql}`, vals);
    const total = (Array.isArray(countRows) && countRows[0] && (countRows[0].total ?? countRows[0]['COUNT(*)'])) ? (countRows[0].total ?? countRows[0]['COUNT(*)']) : 0;

    const offset = (page - 1) * pageSize;
    const limitNum = Number.isFinite(pageSize) ? Math.max(0, Math.floor(pageSize)) : 12;
    const offsetNum = Number.isFinite(offset) ? Math.max(0, Math.floor(offset)) : 0;
    // detectar colunas opcionais
    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSetList = cols.map(c => c.COLUMN_NAME);
    const hasAtivo = colSetList.includes('ativo');
    const hasDestaque = colSetList.includes('destaque');
    const hasTags = colSetList.includes('tags');
    const hasOrdem = colSetList.includes('ordem');

    const optionalCols = [
      hasAtivo ? 'ativo' : null,
      hasDestaque ? 'destaque' : null,
      hasTags ? 'tags' : null,
      hasOrdem ? 'ordem' : null,
    ].filter(Boolean).join(', ');

    const selectCols = `id, nome, descricao, imagem_url${optionalCols ? ', ' + optionalCols : ''}, NOW() as created_at, NOW() as updated_at`;
    const sql = `SELECT ${selectCols} FROM collections ${whereSql} ORDER BY ${sortCol} ${order} LIMIT ${limitNum} OFFSET ${offsetNum}`;
    const [rows] = await pool.execute(sql, vals);
    
    console.log(`✅ ${rows.length} coleções encontradas`);
    
    const toPublic = (p) => normalizeToThisOrigin(req, p);

    const colecoes = rows.map(colecao => {
      const imgPath = extractUploadPath(colecao.imagem_url);
      return {
        id: colecao.id.toString(),
        nome: colecao.nome,
        descricao: colecao.descricao,
        imagem_url: imgPath || null,
        imagem: imgPath ? toPublic(imgPath) : null,
        produtos: parseInt(colecao.total_produtos) || 0,
        preco: 'R$ 0,00 - R$ 0,00',
        destaque: typeof colecao.destaque !== 'undefined' ? Boolean(colecao.destaque) : false,
        status: typeof colecao.ativo !== 'undefined' ? (colecao.ativo ? 'ativo' : 'inativo') : 'ativo',
        tags: typeof colecao.tags !== 'undefined' && colecao.tags ? (typeof colecao.tags === 'string' ? JSON.parse(colecao.tags) : colecao.tags) : [],
        ordem: typeof colecao.ordem !== 'undefined' ? (colecao.ordem || 0) : 0,
        created_at: colecao.created_at,
        updated_at: colecao.updated_at
      };
    });
    
    const withMeta = req.query.withMeta === '1' || req.query.withMeta === 'true';
    if (withMeta) {
      return res.json({ items: colecoes, page, pageSize, total, hasMore: offset + rows.length < total });
    }
    res.json(colecoes);
  } catch (error) {
    console.error('❌ Erro ao buscar coleções:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/collections/:id - Buscar coleção específica
app.get('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando coleção ${id}...`);
    // não dependemos de coluna ativo (alguns bancos não têm)
    const [rows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    const imgPath = extractUploadPath(rows[0].imagem_url ?? rows[0].image_url);
    const imagemAbs = imgPath ? normalizeToThisOrigin(req, imgPath) : null;

    const colecao = {
      id: rows[0].id?.toString?.() ?? rows[0].id,
      nome: rows[0].nome ?? rows[0].name,
      descricao: rows[0].descricao ?? rows[0].description,
      imagem_url: imgPath || null,
      imagem: imagemAbs,
      created_at: rows[0].created_at,
      updated_at: rows[0].updated_at
    };

    console.log(`✅ Coleção encontrada: ${colecao.nome}`);
    res.json(colecao);
  } catch (error) {
    console.error('❌ Erro ao buscar coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/collections/:id/full - coleção com produtos e imagem resolvida
app.get('/api/collections/:id/full', async (req, res) => {
  try {
    const { id } = req.params;
    const [cRows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    if (!cRows || cRows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });
    const imgPath = extractUploadPath(cRows[0].imagem_url ?? cRows[0].image_url);
    const imagemAbs = imgPath ? normalizeToThisOrigin(req, imgPath) : null;
    const colecao = {
      id: cRows[0].id?.toString?.() ?? cRows[0].id,
      nome: cRows[0].nome ?? cRows[0].name,
      descricao: cRows[0].descricao ?? cRows[0].description,
      imagem_url: imgPath || null,
      imagem: imagemAbs,
      created_at: cRows[0].created_at,
      updated_at: cRows[0].updated_at
    };

    const [links] = await pool.execute('SELECT * FROM collection_products WHERE collection_id = ? ORDER BY order_index ASC, created_at ASC', [id]);
    res.json({ ...colecao, products_count: links.length, links });
  } catch (error) {
    console.error('❌ Erro ao buscar coleção completa:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Opcional: suporte a slug (rota amigável)
app.get('/api/collections/slug/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    // slug é derivado do nome (lowercase, hifens). Buscar por nome aproximado
    const nomeAlvo = slug.replace(/-/g, ' ');
    const [rows] = await pool.execute('SELECT * FROM collections WHERE LOWER(nome) = LOWER(?) LIMIT 1', [nomeAlvo]);
    if (!rows || rows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });
    const imgPath = rows[0].imagem_url ?? rows[0].image_url;
    const imagemAbs = imgPath ? normalizeToThisOrigin(req, imgPath) : null;
    res.json({
      id: rows[0].id?.toString?.() ?? rows[0].id,
      nome: rows[0].nome,
      descricao: rows[0].descricao,
      imagem_url: imgPath || null,
      imagem: imagemAbs
    });
  } catch (error) {
    console.error('❌ Erro ao buscar coleção por slug:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PATCH toggles dinâmicos (ativo/destaque) - atualiza apenas colunas existentes
app.patch('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const body = req.body || {};
    const [exists] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    if (!exists || exists.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSet = new Set(cols.map(c => c.COLUMN_NAME));
    const parts = [];
    const vals = [];
    if (colSet.has('ativo') && typeof body.ativo !== 'undefined') { parts.push('ativo = ?'); vals.push(!!body.ativo); }
    if (colSet.has('destaque') && typeof body.destaque !== 'undefined') { parts.push('destaque = ?'); vals.push(!!body.destaque); }
    if (parts.length === 0) return res.status(400).json({ error: 'Nenhum campo suportado informado' });

    const sql = `UPDATE collections SET ${parts.join(', ')}, updated_at = NOW() WHERE id = ?`;
    await pool.execute(sql, [...vals, id]);

    const [rows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (error) {
    console.error('❌ Erro ao atualizar toggles da coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/collections/:id/products - Buscar produtos de uma coleção
app.get('/api/collections/:id/products', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Buscando produtos da coleção ${id}...`);
    
    // Verificar se a coleção existe
    const [collectionRows] = await pool.execute('SELECT id, nome FROM collections WHERE id = ?', [id]);
    if (collectionRows.length === 0) {
      return res.status(404).json({ error: 'Coleção não encontrada' });
    }
    
    // Buscar produtos vinculados na tabela collection_products
    const [linkRows] = await pool.execute(`
      SELECT 
        cp.id, cp.collection_id, cp.product_id, cp.order_index,
        p.id as product_id, p.nome, p.preco, p.categoria, p.imagem_url, p.descricao, 
        p.estoque, p.status, p.destaque, p.promocao, p.lancamento, p.avaliacao, 
        p.total_avaliacoes, p.faixa_etaria, p.peso, p.dimensoes, p.material, 
        p.marca, p.origem, p.fornecedor, p.codigo_barras, p.data_lancamento, 
        p.created_at, p.updated_at
      FROM collection_products cp
      LEFT JOIN products p ON cp.product_id = p.id
      WHERE cp.collection_id = ?
      ORDER BY cp.order_index ASC, cp.created_at ASC
    `, [id]);
    
    const produtos = linkRows.map(link => ({
      id: link.id,
      collection_id: link.collection_id,
      product_id: link.product_id,
      order_index: link.order_index,
      product: link.product_id ? {
        id: link.product_id,
        nome: link.nome,
        preco: parseFloat(link.preco || 0),
        categoria: link.categoria,
        imagem_url: link.imagem_url,
        descricao: link.descricao,
        estoque: link.estoque,
        status: link.status,
        destaque: link.destaque,
        promocao: link.promocao,
        lancamento: link.lancamento,
        avaliacao: link.avaliacao ? parseFloat(link.avaliacao) : null,
        total_avaliacoes: link.total_avaliacoes,
        faixa_etaria: link.faixa_etaria,
        peso: link.peso,
        dimensoes: link.dimensoes,
        material: link.material,
        marca: link.marca,
        origem: link.origem,
        fornecedor: link.fornecedor,
        codigo_barras: link.codigo_barras,
        data_lancamento: link.data_lancamento,
        created_at: link.created_at,
        updated_at: link.updated_at
      } : null
    }));
    
    console.log(`✅ ${produtos.length} produtos encontrados na coleção ${collectionRows[0].nome}`);
    res.json(produtos);
  } catch (error) {
    console.error('❌ Erro ao buscar produtos da coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Utilitário simples: salvar imagem base64 (opcional)
const UPLOAD_DIR = path.join(__dirname, 'public', 'lovable-uploads');
try { fs.mkdirSync(UPLOAD_DIR, { recursive: true }); } catch {}
app.use('/uploads', express.static(path.join(process.cwd(), 'public', 'uploads')));

function saveBase64ImageToCollectionsBase64(dataUrl) {
  try {
    if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:')) return null;
    const m = dataUrl.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!m) return null;
    const ext = (m[1].split('/')[1] || 'png').toLowerCase();
    const buf = Buffer.from(m[2], 'base64');
    const filename = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, filename), buf);
    return `/uploads/collections/${filename}`;
  } catch {
    return null;
  }
}

// POST /api/collections - Criar nova coleção
app.post('/api/collections', async (req, res) => {
  try {
    const { nome, descricao, imagem, name, description, image_url, destaque, ativo, tags, ordem } = req.body || {};
    const finalName = (name ?? nome) || '';
    const finalDescription = (description ?? descricao) || '';
    let finalImageUrl = (image_url ?? imagem) || null;
    console.log(`🔄 Criando coleção: ${finalName}`);
    
    // Validar dados obrigatórios
    if (!finalName || !finalDescription) {
      return res.status(400).json({ error: 'Nome e descrição são obrigatórios' });
    }
    // Salvar base64 se enviado
    if (finalImageUrl && typeof finalImageUrl === 'string' && finalImageUrl.startsWith('data:')) {
      const saved = saveBase64ImageToCollectionsBase64(finalImageUrl);
      if (saved) finalImageUrl = saved;
    }
    
    // Inserção alinhada ao schema PT (id varchar, nome, descricao, imagem_url)
    const newId = require('crypto').randomUUID();
    // detectar colunas opcionais
    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSet = new Set(cols.map(c => c.COLUMN_NAME));
    const extraCols = [];
    const extraVals = [];
    if (colSet.has('destaque')) { extraCols.push('destaque'); extraVals.push(!!destaque); }
    if (colSet.has('ativo')) { extraCols.push('ativo'); extraVals.push(ativo === false ? 0 : 1); }
    if (colSet.has('tags')) { extraCols.push('tags'); extraVals.push(tags ? JSON.stringify(tags) : JSON.stringify([])); }
    if (colSet.has('ordem')) { extraCols.push('ordem'); extraVals.push(Number.isFinite(ordem) ? ordem : 0); }

    const baseCols = ['id','nome','descricao','imagem_url','created_at','updated_at'];
    const basePlace = ['?','?','?','?','NOW()','NOW()'];
    const sql = `INSERT INTO collections (${baseCols.concat(extraCols).join(',')}) VALUES (${basePlace.concat(extraCols.map(()=>'?')).join(',')})`;
    await pool.execute(sql, [newId, finalName, finalDescription, finalImageUrl, ...extraVals]);
    
    const host = req.get('host');
    const proto = req.protocol || 'http';
    const publicUrl = finalImageUrl ? `${proto}://${host}${finalImageUrl.startsWith('/') ? '' : '/'}${finalImageUrl}` : null;
    const novaColecao = {
      id: newId,
      nome: finalName,
      descricao: finalDescription,
      imagem_url: finalImageUrl,
      imagem: publicUrl,
      produtos: 0,
      preco: 'R$ 0,00 - R$ 0,00',
      destaque: false,
      status: 'ativo',
      tags: [],
      ordem: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    console.log(`✅ Coleção criada com sucesso: ${finalName}`);
    res.status(201).json(novaColecao);
  } catch (error) {
    console.error('❌ Erro ao criar coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// PUT /api/collections/:id - Atualizar coleção
app.put('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, descricao, imagem, name, description, image_url, destaque, ativo, tags, ordem } = req.body || {};
    const finalName = (name ?? nome) || '';
    const finalDescription = (description ?? descricao) || '';
    let finalImageUrl = (image_url ?? imagem) || null;
    console.log(`🔄 Atualizando coleção ${id}: ${finalName}`);
    
    // Validar dados obrigatórios
    if (!finalName || !finalDescription) {
      return res.status(400).json({ error: 'Nome e descrição são obrigatórios' });
    }
    // Salvar base64 se enviado
    if (finalImageUrl && typeof finalImageUrl === 'string' && finalImageUrl.startsWith('data:')) {
      const saved = saveBase64ImageToCollectionsBase64(finalImageUrl);
      if (saved) finalImageUrl = saved;
    }

    // Update alinhado ao schema PT
    // detectar colunas opcionais para update
    const [cols2] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const colSet2 = new Set(cols2.map(c => c.COLUMN_NAME));
    const parts = ['nome = ?','descricao = ?','imagem_url = ?'];
    const params = [finalName, finalDescription, finalImageUrl];
    if (colSet2.has('destaque') && typeof destaque !== 'undefined') { parts.push('destaque = ?'); params.push(!!destaque); }
    if (colSet2.has('ativo') && typeof ativo !== 'undefined') { parts.push('ativo = ?'); params.push(ativo ? 1 : 0); }
    if (colSet2.has('tags') && typeof tags !== 'undefined') { parts.push('tags = ?'); params.push(tags ? JSON.stringify(tags) : JSON.stringify([])); }
    if (colSet2.has('ordem') && typeof ordem !== 'undefined') { parts.push('ordem = ?'); params.push(Number.isFinite(ordem) ? ordem : 0); }
    const sql = `UPDATE collections SET ${parts.join(', ')}, updated_at = NOW() WHERE id = ?`;
    await pool.execute(sql, [...params, id]);
    
    // Buscar coleção atualizada
    const [rows] = await pool.execute('SELECT * FROM collections WHERE id = ?', [id]);
    const imgPath = extractUploadPath(rows[0].imagem_url ?? rows[0].image_url);
    const colecaoAtualizada = {
      id: rows[0].id.toString(),
      nome: rows[0].nome ?? rows[0].name,
      descricao: rows[0].descricao ?? rows[0].description,
      imagem_url: imgPath || null,
      imagem: imgPath ? normalizeToThisOrigin(req, imgPath) : null,
      created_at: rows[0].created_at,
      updated_at: rows[0].updated_at
    };
    
    console.log(`✅ Coleção atualizada com sucesso: ${nome}`);
    res.json(colecaoAtualizada);
  } catch (error) {
    console.error('❌ Erro ao atualizar coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// DELETE /api/collections/:id - Deletar coleção
app.delete('/api/collections/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔄 Deletando coleção ${id}`);
    await pool.execute('DELETE FROM collections WHERE id = ?', [id]);
    console.log(`✅ Coleção deletada com sucesso`);
    res.json({ success: true });
  } catch (error) {
    console.error('❌ Erro ao deletar coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/debug/collections-schema - Inspeciona colunas da tabela collections
app.get('/api/debug/collections-schema', async (req, res) => {
  try {
    const [cols] = await pool.execute("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections' ORDER BY ORDINAL_POSITION");
    res.json({
      database: process.env.MYSQL_DATABASE,
      table: 'collections',
      columns: cols
    });
  } catch (error) {
    console.error('❌ Erro ao ler schema de collections:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// Ensure link table collection_products exists
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS collection_products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        collection_id VARCHAR(191) NOT NULL,
        product_id INT NOT NULL,
        order_index INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_collection (collection_id),
        INDEX idx_product (product_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    console.log('✅ Checked/created table: collection_products');

    // Garantir que as colunas collection_id e product_id são VARCHAR(191) (podem existir como INT em bancos antigos)
    try {
      const [colInfo] = await pool.execute(
        "SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collection_products' AND COLUMN_NAME IN ('collection_id', 'product_id')"
      );
      
      for (const col of colInfo) {
        if (col.COLUMN_NAME === 'collection_id' && (col.DATA_TYPE.toLowerCase() !== 'varchar' || Number(col.CHARACTER_MAXIMUM_LENGTH || 0) < 191)) {
          console.log('🛠️ Alterando tipo de collection_id para VARCHAR(191) em collection_products...');
          await pool.execute('ALTER TABLE collection_products MODIFY collection_id VARCHAR(191) NOT NULL');
          console.log('✅ collection_id agora é VARCHAR(191)');
        }
        if (col.COLUMN_NAME === 'product_id' && (col.DATA_TYPE.toLowerCase() !== 'varchar' || Number(col.CHARACTER_MAXIMUM_LENGTH || 0) < 191)) {
          console.log('🛠️ Alterando tipo de product_id para VARCHAR(191) em collection_products...');
          await pool.execute('ALTER TABLE collection_products MODIFY product_id VARCHAR(191) NOT NULL');
          console.log('✅ product_id agora é VARCHAR(191)');
        }
      }
    } catch (e) {
      console.warn('⚠️ Não foi possível verificar/alterar colunas:', e?.message || e);
    }
  } catch (err) {
    console.error('❌ Failed ensuring collection_products table:', { message: err?.message, code: err?.code });
  }
})();

// =====================================
// Settings (configurações gerenciáveis)
// =====================================
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS settings (
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        key_name VARCHAR(191) PRIMARY KEY,
        value_text TEXT,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    await pool.execute(`
      CREATE TABLE IF NOT EXISTS settings_audit (
        id INT AUTO_INCREMENT PRIMARY KEY,
        key_name VARCHAR(191) NOT NULL,
        old_value TEXT,
        new_value TEXT,
        admin_id VARCHAR(191) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_key (key_name),
        INDEX idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    await pool.execute(`
      CREATE TABLE IF NOT EXISTS recovery_emails (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'queued',
        error TEXT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        sent_at DATETIME NULL,
        INDEX idx_email (email),
        INDEX idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    // Seed básico se estiver vazio
    const [rows] = await pool.execute('SELECT COUNT(*) as cnt FROM settings');
    const count = Array.isArray(rows) ? Number(rows[0].cnt || 0) : 0;
    if (count === 0) {
      const defaults = [
        ['pix_discount_percent', '5'],
        ['digital_pay_discount_percent', '2'],
        ['free_shipping_min', '200'],
        ['shipping_base_price', '15'],
        ['enable_apple_pay', 'true'],
        ['enable_google_pay', 'true'],
        ['cart_recovery_enabled', 'true'],
        ['cart_recovery_banner_delay_ms', '120000'],
        ['cart_recovery_email_delay_ms', '600000']
      ];
      for (const [k, v] of defaults) {
        await pool.execute('INSERT IGNORE INTO settings (key_name, value_text) VALUES (?,?)', [k, v]);
      }
    // SMTP defaults (não sensível; senha não default)
    const smtpDefaults = [
      ['smtp_enabled', 'false'],
      ['smtp_host', ''],
      ['smtp_port', '587'],
      ['smtp_secure', 'false'],
      ['smtp_user', ''],
      ['smtp_from', ''],
    ];
    for (const [k, v] of smtpDefaults) {
      await pool.execute('INSERT IGNORE INTO settings (key_name, value_text) VALUES (?,?)', [k, v]);
    }
      console.log('✅ Settings default populated');
    }
  } catch (err) {
    console.error('❌ Failed ensuring settings table:', { message: err?.message, code: err?.code });
  }
})();

// Endpoints de Settings
app.get('/api/settings', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT key_name, value_text FROM settings');
    const settings = {};
    for (const r of rows) settings[r.key_name] = r.value_text;
    res.json({ settings });
  } catch (e) {
    console.error('Settings GET error', e);
    res.status(500).json({ error: 'settings_get_failed' });
  }
});

// Middleware simples de admin (cookie/flag de sessão)
function isAdminRequest(req) {
  try {
    // Estratégia simples: header X-Admin-Token ou cookie admin_token (apenas para painel interno)
    const token = (req.headers['x-admin-token'] || req.cookies?.admin_token || '').toString();
    // Em produção, troque por verificação de sessão/jwt com roles
    return Boolean(token && token.length >= 10);
  } catch {
    return false;
  }
}

app.put('/api/settings', express.json(), async (req, res) => {
  try {
    if (!isAdminRequest(req)) return res.status(401).json({ error: 'unauthorized' });
    const body = req.body || {};
    if (!body || typeof body !== 'object') return res.status(400).json({ error: 'payload_invalido' });
    const entries = Object.entries(body);
    if (!entries.length) return res.status(400).json({ error: 'payload_vazio' });
    // Validação simples de tipos/intervalos
    const validators = {
      pix_discount_percent: (v) => Number(v) >= 0 && Number(v) <= 50,
      digital_pay_discount_percent: (v) => Number(v) >= 0 && Number(v) <= 50,
      free_shipping_min: (v) => Number(v) >= 0 && Number(v) <= 100000,
      shipping_base_price: (v) => Number(v) >= 0 && Number(v) <= 10000,
      enable_apple_pay: (v) => ['true','false',true,false].includes(v),
      enable_google_pay: (v) => ['true','false',true,false].includes(v),
      cart_recovery_enabled: (v) => ['true','false',true,false].includes(v),
      cart_recovery_banner_delay_ms: (v) => Number(v) >= 0 && Number(v) <= 3600000,
      cart_recovery_email_delay_ms: (v) => Number(v) >= 0 && Number(v) <= 86400000,
      smtp_enabled: (v) => ['true','false',true,false].includes(v),
      smtp_host: (v) => typeof v === 'string' && v.length <= 255,
      smtp_port: (v) => Number(v) > 0 && Number(v) <= 65535,
      smtp_secure: (v) => ['true','false',true,false].includes(v),
      smtp_user: (v) => typeof v === 'string' && v.length <= 255,
      smtp_from: (v) => typeof v === 'string' && v.length <= 255,
      // smtp_pass validado mas não exposto em GET
      smtp_pass: (v) => typeof v === 'string' && v.length <= 255,
      // Configurações PIX
      pix_key: (v) => typeof v === 'string' && v.length <= 255,
      pix_key_type: (v) => ['email', 'cpf', 'cnpj', 'phone', 'random'].includes(v),
      pix_merchant_name: (v) => typeof v === 'string' && v.length <= 255,
      pix_city: (v) => typeof v === 'string' && v.length <= 255,
      pix_show_qr_cart: (v) => ['true','false',true,false].includes(v),
    };

    // Obter valores antigos para audit
    const [currentRows] = await pool.execute('SELECT key_name, value_text FROM settings');
    const current = {};
    for (const r of currentRows) current[r.key_name] = r.value_text;

    const adminId = (req.headers['x-admin-id'] || req.cookies?.admin_user || '').toString() || null;

    for (const [key, value] of entries) {
      if (validators[key] && !validators[key](value)) {
        return res.status(400).json({ error: 'validation_error', field: key });
      }
      await pool.execute('INSERT INTO settings (key_name, value_text) VALUES (?, ?) ON DUPLICATE KEY UPDATE value_text = VALUES(value_text), updated_at = NOW()', [String(key), value == null ? '' : String(value)]);
      try {
        const oldVal = current[String(key)] ?? null;
        const newVal = value == null ? '' : String(value);
        if (oldVal !== newVal) {
          await pool.execute('INSERT INTO settings_audit (key_name, old_value, new_value, admin_id) VALUES (?,?,?,?)', [String(key), oldVal, newVal, adminId]);
        }
      } catch (e) {
        console.log('⚠️ Audit insert failed:', e?.message || e);
      }
    }
    const [rows] = await pool.execute('SELECT key_name, value_text FROM settings');
    const settings = {};
    for (const r of rows) {
      if (r.key_name === 'smtp_pass') continue; // não retornar senha
      settings[r.key_name] = r.value_text;
    }
    res.json({ settings });
  } catch (e) {
    console.error('Settings PUT error', e);
    res.status(500).json({ error: 'settings_put_failed' });
  }
});

// Util: SMTP test (admin)
app.post('/api/utils/smtp-test', express.json(), async (req, res) => {
  try {
    if (!isAdminRequest(req)) return res.status(401).json({ error: 'unauthorized' });
    // Carregar settings
    const [rows] = await pool.execute('SELECT key_name, value_text FROM settings');
    const map = {};
    for (const r of rows) map[r.key_name] = r.value_text;
    const host = map.smtp_host || process.env.SMTP_HOST || '';
    const port = Number(map.smtp_port || process.env.SMTP_PORT || 587);
    const secure = String(map.smtp_secure || process.env.SMTP_SECURE || 'false') === 'true';
    const user = map.smtp_user || process.env.SMTP_USER || '';
    const pass = map.smtp_pass || process.env.SMTP_PASS || '';
    const from = map.smtp_from || process.env.SMTP_FROM || '';

    if (!host || !user || !pass || !from) return res.status(400).json({ error: 'smtp_incompleto' });

    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransport({ host, port, secure, auth: { user, pass } });

    const to = req.body?.to || user;
    await transporter.sendMail({ from, to, subject: 'Teste SMTP - Rare Toy Companion', text: 'Envio de teste realizado com sucesso.' });
    res.json({ ok: true });
  } catch (e) {
    console.error('SMTP test error', e);
    res.status(500).json({ error: 'smtp_test_failed', message: e?.message });
  }
});

// Recovery notify email (simplificado)
app.post('/api/recovery/notify', express.json(), async (req, res) => {
  try {
    const email = (req.body?.email || '').toString();
    if (!email) return res.status(400).json({ error: 'email_obrigatorio' });

    const [rows] = await pool.execute('SELECT key_name, value_text FROM settings');
    const map = {};
    for (const r of rows) map[r.key_name] = r.value_text;
    if (String(map.smtp_enabled) !== 'true') return res.status(400).json({ error: 'smtp_desativado' });

    const host = map.smtp_host || process.env.SMTP_HOST || '';
    const port = Number(map.smtp_port || process.env.SMTP_PORT || 587);
    const secure = String(map.smtp_secure || process.env.SMTP_SECURE || 'false') === 'true';
    const user = map.smtp_user || process.env.SMTP_USER || '';
    const pass = map.smtp_pass || process.env.SMTP_PASS || '';
    const from = map.smtp_from || process.env.SMTP_FROM || '';
    if (!host || !user || !pass || !from) return res.status(400).json({ error: 'smtp_incompleto' });

    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransport({ host, port, secure, auth: { user, pass } });
    const subject = 'Você deixou itens no carrinho 🛒';
    const text = 'Você ainda tem itens no carrinho. Volte e finalize sua compra!';
    let sent = false;
    let errorMsg = null;
    try {
      await transporter.sendMail({ from, to: email, subject, text });
      sent = true;
    } catch (e) {
      errorMsg = e?.message || String(e);
    }
    try {
      await pool.execute('INSERT INTO recovery_emails (email, status, error, sent_at) VALUES (?,?,?,?)', [email, sent ? 'sent' : 'failed', errorMsg, sent ? new Date() : null]);
    } catch (e) {
      console.log('⚠️ Failed to log recovery email:', e?.message || e);
    }
    if (!sent) return res.status(500).json({ error: 'smtp_send_failed', message: errorMsg });
    res.json({ ok: true });
  } catch (e) {
    console.error('Recovery notify error', e);
    res.status(500).json({ error: 'recovery_notify_failed', message: e?.message });
  }
});

// Admin: list recovery emails
app.get('/api/recovery/emails', async (req, res) => {
  try {
    if (!isAdminRequest(req)) return res.status(401).json({ error: 'unauthorized' });
    const page = Math.max(1, Number(req.query.page || 1));
    const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize || 20)));
    const offset = (page - 1) * pageSize;
    const emailFilter = (req.query.email || '').toString();
    const where = emailFilter ? `WHERE email LIKE ${pool.escape('%' + emailFilter + '%')}` : '';
  const sql = `SELECT id, email, status, error, created_at, sent_at FROM recovery_emails ${where} ORDER BY created_at DESC LIMIT ${Number(pageSize)} OFFSET ${Number(offset)}`;
  const [rows] = await pool.execute(sql);
  const countSql = `SELECT COUNT(*) as total FROM recovery_emails ${where}`;
  const [[countRow]] = await pool.execute(countSql);
  res.json({ page, pageSize, total: Number(countRow.total || 0), items: rows });
  } catch (e) {
    console.error('Recovery emails GET error', e);
    res.status(500).json({ error: 'recovery_emails_get_failed' });
  }
});

// Audit list (admin only)
app.get('/api/settings/audit', async (req, res) => {
  try {
    if (!isAdminRequest(req)) return res.status(401).json({ error: 'unauthorized' });
    const page = Math.max(1, Number(req.query.page || 1));
    const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize || 20)));
    const offset = (page - 1) * pageSize;
  const sql = `SELECT id, key_name, old_value, new_value, admin_id, created_at FROM settings_audit ORDER BY created_at DESC LIMIT ${Number(pageSize)} OFFSET ${Number(offset)}`;
  const [rows] = await pool.execute(sql);
  const [[countRow]] = await pool.execute('SELECT COUNT(*) as total FROM settings_audit');
  res.json({ page, pageSize, total: Number(countRow.total || 0), items: rows });
  } catch (e) {
    console.error('Settings audit GET error', e);
    res.status(500).json({ error: 'settings_audit_get_failed' });
  }
});

// =====================================
// Tabelas e endpoints de Carrinho/Pedidos
// =====================================
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS carts (
        id VARCHAR(191) PRIMARY KEY,
        user_id VARCHAR(191) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS cart_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cart_id VARCHAR(191) NOT NULL,
        product_id VARCHAR(191) NOT NULL,
        name VARCHAR(255),
        price DECIMAL(10,2) NOT NULL DEFAULT 0,
        image_url VARCHAR(500),
        quantity INT NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_cart (cart_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS orders (
        id VARCHAR(191) PRIMARY KEY,
        user_id VARCHAR(191) NULL,
        cart_id VARCHAR(191) NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'criado',
        total DECIMAL(10,2) NOT NULL DEFAULT 0,
        nome VARCHAR(255),
        email VARCHAR(255),
        telefone VARCHAR(50),
        endereco TEXT,
        metodo_pagamento VARCHAR(50),
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id VARCHAR(191) NOT NULL,
        product_id VARCHAR(191) NOT NULL,
        name VARCHAR(255),
        price DECIMAL(10,2) NOT NULL DEFAULT 0,
        image_url VARCHAR(500),
        quantity INT NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_order (order_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    
    // Migração: alterar product_id de INT para VARCHAR nas tabelas existentes
    try {
      await pool.execute(`ALTER TABLE cart_items MODIFY COLUMN product_id VARCHAR(191) NOT NULL`);
      console.log('✅ Migração: cart_items.product_id alterado para VARCHAR(191)');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ cart_items.product_id já é VARCHAR ou erro na migração:', e.message);
      }
    }
    
    try {
      await pool.execute(`ALTER TABLE order_items MODIFY COLUMN product_id VARCHAR(191) NOT NULL`);
      console.log('✅ Migração: order_items.product_id alterado para VARCHAR(191)');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ order_items.product_id já é VARCHAR ou erro na migração:', e.message);
      }
    }
    
    // Migração: adicionar colunas de entrega/pagamento na tabela orders se não existirem
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN nome VARCHAR(255) AFTER cart_id`);
      console.log('✅ Migração: coluna nome adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna nome já existe ou erro na migração:', e.message);
      }
    }
    
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN email VARCHAR(255) AFTER nome`);
      console.log('✅ Migração: coluna email adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna email já existe ou erro na migração:', e.message);
      }
    }
    
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN telefone VARCHAR(50) AFTER email`);
      console.log('✅ Migração: coluna telefone adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna telefone já existe ou erro na migração:', e.message);
      }
    }
    
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN endereco TEXT AFTER telefone`);
      console.log('✅ Migração: coluna endereco adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna endereco já existe ou erro na migração:', e.message);
      }
    }
    
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN metodo_pagamento VARCHAR(50) AFTER endereco`);
      console.log('✅ Migração: coluna metodo_pagamento adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna metodo_pagamento já existe ou erro na migração:', e.message);
      }
    }
    
    // Migração: adicionar colunas de pagamento
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN payment_status VARCHAR(50) DEFAULT 'pending' AFTER metodo_pagamento`);
      console.log('✅ Migração: coluna payment_status adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna payment_status já existe ou erro na migração:', e.message);
      }
    }
    
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN payment_data JSON AFTER payment_status`);
      console.log('✅ Migração: coluna payment_data adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna payment_data já existe ou erro na migração:', e.message);
      }
    }
    
    try {
      await pool.execute(`ALTER TABLE orders ADD COLUMN pix_qr_code TEXT AFTER payment_data`);
      console.log('✅ Migração: coluna pix_qr_code adicionada à tabela orders');
    } catch (e) {
      if (!e.message.includes('Duplicate column name')) {
        console.log('ℹ️ Coluna pix_qr_code já existe ou erro na migração:', e.message);
      }
    }
    
    console.log('✅ Tabelas de carrinho/pedidos verificadas');
  } catch (e) {
    console.error('❌ Erro nas tabelas de carrinho/pedidos:', e?.message || e);
  }
})();

// ================= AUTH BÁSICA (sessão por cookie) =================
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS sessions (
        id VARCHAR(191) PRIMARY KEY,
        user_email VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
  } catch (e) {
    console.error('❌ Erro criando tabela de sessões:', e?.message || e);
  }
})();

async function attachUserFromSession(req) {
  try {
    const sid = req.cookies?.session_id;
    if (!sid) return null;
    const [rows] = await pool.execute('SELECT user_email FROM sessions WHERE id = ? LIMIT 1', [sid]);
    if (!rows || rows.length === 0) return null;
    req.user = { email: rows[0].user_email };
    await pool.execute('UPDATE sessions SET last_seen = NOW() WHERE id = ?', [sid]);
    return req.user;
  } catch { return null; }
}

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, senha } = req.body || {};
    if (!email || !senha) return res.status(400).json({ error: 'credenciais_invalidas' });
    // Para agora, aceitar qualquer senha (apenas demo). Futuro: hash e validação real.
    const sid = require('crypto').randomUUID();
    await pool.execute('INSERT INTO sessions (id, user_email) VALUES (?, ?)', [sid, email]);
    res.cookie('session_id', sid, { httpOnly: false, sameSite: 'lax', secure: (req.headers['x-forwarded-proto'] || req.protocol) === 'https', maxAge: 1000*60*60*24*30 });
    // Vincular carrinho atual ao usuário
    const cartId = req.cookies?.cart_id;
    if (cartId) {
      await pool.execute('UPDATE carts SET user_id = ? WHERE id = ?', [email, cartId]);
    }
    res.json({ success: true, email });
  } catch (e) {
    res.status(500).json({ error: 'login_failed', message: e?.message });
  }
});

app.post('/api/auth/logout', async (req, res) => {
  try {
    const sid = req.cookies?.session_id;
    if (sid) await pool.execute('DELETE FROM sessions WHERE id = ?', [sid]);
    res.clearCookie('session_id');
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'logout_failed' });
  }
});

// ==========================
// Favoritos (por usuário mock_email ou cart_id)
// ==========================
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS favorites (
        id VARCHAR(191) PRIMARY KEY,
        user_email VARCHAR(255),
        cart_id VARCHAR(191),
        product_id VARCHAR(191) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_email),
        INDEX idx_cart (cart_id),
        UNIQUE KEY unique_user_product (user_email, product_id)
      )
    `);
    console.log('✅ Tabela favorites criada/verificada');
  } catch (e) {
    console.error('❌ Erro ao criar tabela favorites', e);
  }
})();

const { randomUUID: favUUID } = require('crypto');

function getCurrentUserEmail(req) {
  return (req.cookies && req.cookies.mock_email) || null;
}

app.get('/api/favorites', async (req, res) => {
  try {
    const email = getCurrentUserEmail(req);
    const cartId = getOrCreateCartId(req, res);
    const [rows] = await pool.execute('SELECT product_id FROM favorites WHERE user_email = ? OR (user_email IS NULL AND cart_id = ?)', [email, cartId]);
    const productIds = rows.map(r => r.product_id);
    if (productIds.length === 0) return res.json([]);
    const placeholders = productIds.map(() => '?').join(',');
    const [prod] = await pool.query(`SELECT * FROM products WHERE id IN (${placeholders})`, productIds);
    res.json((prod || []).map(p => ({
      id: p.id,
      nome: p.nome || p.name,
      preco: Number(p.preco || p.price || 0),
      imagemUrl: p.imagem_url || p.image_url || p.imagemUrl || p.image,
      categoria: p.categoria || p.category || '—',
      emEstoque: (p.estoque ?? 1) > 0,
      destaque: Boolean(p.destaque),
      promocao: Boolean(p.promocao),
    })));
  } catch (e) {
    console.error('Favorites list error', e);
    res.status(500).json({ error: 'favorites_list_failed' });
  }
});

// ==========================
// Auth real (leve): users table + token HMAC em cookie httpOnly
// ==========================
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(191) PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        nome VARCHAR(255),
        avatar_url VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela users criada/verificada');

    // Garantir colunas necessárias quando a tabela já existe com schema diferente
    try {
      const [cols] = await pool.execute('DESCRIBE users');
      const fields = new Set((cols || []).map(c => c.Field));
      if (!fields.has('password_hash')) {
        await pool.execute('ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) NOT NULL AFTER email');
        console.log('🔧 Adicionada coluna users.password_hash');
      }
      if (!fields.has('avatar_url')) {
        await pool.execute('ALTER TABLE users ADD COLUMN avatar_url VARCHAR(500) NULL AFTER nome');
        console.log('🔧 Adicionada coluna users.avatar_url');
      }
      if (!fields.has('nome')) {
        await pool.execute('ALTER TABLE users ADD COLUMN nome VARCHAR(255) NULL AFTER password_hash');
        console.log('🔧 Adicionada coluna users.nome');
      }
    } catch (e) {
      console.log('ℹ️ Não foi possível ajustar colunas de users:', e?.message);
    }
  } catch (e) {
    console.error('❌ Erro ao criar tabela users', e);
  }
})();

const crypto = require('crypto');
const AUTH_SECRET = process.env.AUTH_SECRET || 'dev-secret-change-me';

function signToken(payload) {
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', AUTH_SECRET).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verifyToken(token) {
  try {
    const [data, sig] = token.split('.');
    if (!data || !sig) return null;
    const expected = crypto.createHmac('sha256', AUTH_SECRET).update(data).digest('base64url');
    if (expected !== sig) return null;
    const json = JSON.parse(Buffer.from(data, 'base64url').toString('utf8'));
    return json;
  } catch {
    return null;
  }
}

function setAuthCookie(res, payload) {
  const token = signToken(payload);
  res.cookie('auth_token', token, { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 });
}

async function hashPassword(password) {
  return await new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16);
    crypto.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) return reject(err);
      resolve(`${salt.toString('hex')}:${derivedKey.toString('hex')}`);
    });
  });
}

async function verifyPassword(password, hash) {
  const [saltHex, keyHex] = String(hash || '').split(':');
  if (!saltHex || !keyHex) return false;
  return await new Promise((resolve) => {
    crypto.scrypt(password, Buffer.from(saltHex, 'hex'), 64, (err, derivedKey) => {
      if (err) return resolve(false);
      resolve(crypto.timingSafeEqual(Buffer.from(keyHex, 'hex'), derivedKey));
    });
  });
}

app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, senha, password, nome } = req.body || {};
    const mail = String(email || '').trim().toLowerCase();
    const pass = String(password || senha || '');
    if (!mail || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail)) return res.status(400).json({ ok: false, error: 'invalid_email' });
    if (pass.length < 6) return res.status(400).json({ ok: false, error: 'weak_password' });
    const id = crypto.randomUUID();
    const pw = await hashPassword(pass);
    await pool.execute('INSERT INTO users (id, email, password_hash, nome) VALUES (?,?,?,?)', [id, mail, pw, nome || null]);
    setAuthCookie(res, { id, email: mail });
    res.json({ ok: true });
  } catch (e) {
    if (e && e.code === 'ER_DUP_ENTRY') return res.status(409).json({ ok: false, error: 'email_in_use' });
    console.error('Register error', e);
    res.status(500).json({ ok: false, error: 'register_failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, senha, password } = req.body || {};
    const mail = String(email || '').trim().toLowerCase();
    const pass = String(password || senha || '');
    if (!mail || !pass) return res.status(400).json({ ok: false, error: 'missing_credentials' });
    const [rows] = await pool.execute('SELECT * FROM users WHERE email = ? LIMIT 1', [mail]);
    if (!Array.isArray(rows) || rows.length === 0) return res.status(401).json({ ok: false, error: 'invalid_credentials' });
    const user = rows[0];
    const ok = await verifyPassword(pass, user.password_hash);
    if (!ok) return res.status(401).json({ ok: false, error: 'invalid_credentials' });
    setAuthCookie(res, { id: user.id, email: user.email });
    res.json({ ok: true });
  } catch (e) {
    console.error('Login error', e);
    res.status(500).json({ ok: false, error: 'login_failed' });
  }
});

app.get('/api/auth/me', async (req, res) => {
  try {
    const token = req.cookies && req.cookies.auth_token;
    const payload = token && verifyToken(token);
    if (!payload) return res.json({ authenticated: false });
    const [rows] = await pool.execute('SELECT id, email, nome, avatar_url FROM users WHERE id = ? LIMIT 1', [payload.id]);
    if (!Array.isArray(rows) || rows.length === 0) return res.json({ authenticated: false });
    return res.json({ authenticated: true, user: rows[0] });
  } catch (e) {
    return res.json({ authenticated: false });
  }
});

app.post('/api/auth/logout', async (req, res) => {
  try { res.clearCookie('auth_token'); } catch {}
  res.json({ success: true });
});

app.post('/api/favorites', async (req, res) => {
  try {
    const email = getCurrentUserEmail(req);
    const cartId = getOrCreateCartId(req, res);
    const { product_id } = req.body || {};
    if (!product_id) return res.status(400).json({ ok: false, error: 'missing_product_id' });
    const id = favUUID();
    await pool.execute('INSERT IGNORE INTO favorites (id, user_email, cart_id, product_id) VALUES (?,?,?,?)', [id, email, cartId, product_id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('Favorites add error', e);
    res.status(500).json({ ok: false, error: 'favorites_add_failed' });
  }
});

app.delete('/api/favorites/:product_id', async (req, res) => {
  try {
    const email = getCurrentUserEmail(req);
    const cartId = getOrCreateCartId(req, res);
    const { product_id } = req.params;
    await pool.execute('DELETE FROM favorites WHERE product_id = ? AND (user_email = ? OR (user_email IS NULL AND cart_id = ?))', [product_id, email, cartId]);
    res.json({ ok: true });
  } catch (e) {
    console.error('Favorites delete error', e);
    res.status(500).json({ ok: false, error: 'favorites_delete_failed' });
  }
});

app.get('/api/auth/me', async (req, res) => {
  await attachUserFromSession(req);
  if (!req.user) return res.status(401).json({ authenticated: false });
  res.json({ authenticated: true, user: req.user });
});

function getOrCreateCartId(req, res) {
  let cartId = req.cookies?.cart_id;
  if (!cartId) {
    cartId = require('crypto').randomUUID();
    res.cookie('cart_id', cartId, { httpOnly: false, sameSite: 'lax', secure: (req.headers['x-forwarded-proto'] || req.protocol) === 'https', maxAge: 1000*60*60*24*30 });
  }
  return cartId;
}

async function ensureCartExists(cartId) {
  await pool.execute('INSERT IGNORE INTO carts (id) VALUES (?)', [cartId]);
}

function mapCartItemRow(r, req) {
  return {
    id: r.id,
    product_id: r.product_id,
    name: r.name,
    price: Number(r.price),
    image_url: r.image_url ? normalizeToThisOrigin(req, r.image_url) : null,
    quantity: r.quantity
  };
}

app.get('/api/cart', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    await ensureCartExists(cartId);
    const [rows] = await pool.execute('SELECT * FROM cart_items WHERE cart_id = ? ORDER BY created_at ASC', [cartId]);
    const items = rows.map(r => mapCartItemRow(r, req));
    const total = items.reduce((sum, it) => sum + (it.price * it.quantity), 0);
    res.json({ cart_id: cartId, items, total });
  } catch (e) {
    console.error('Cart GET error', e);
    res.status(500).json({ error: 'cart_get_failed' });
  }
});

app.post('/api/cart/items', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    await ensureCartExists(cartId);
    const { product_id, name, price, image_url, quantity } = req.body || {};
    console.log('🧾 add-to-cart body:', req.body);
    const priceNum = typeof price === 'string' ? Number(price.replace(/\./g, '').replace(',', '.')) : Number(price);
    const qtyNum = Number(quantity || 1);
    if (!product_id || !Number.isFinite(priceNum) || priceNum <= 0) {
      return res.status(400).json({ error: 'payload_invalido', details: { product_id, price } });
    }
    // Se item já existe, incrementa
    const [exist] = await pool.execute('SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? LIMIT 1', [cartId, product_id]);
    if (exist.length) {
      const q = Number(exist[0].quantity || 0) + qtyNum;
      await pool.execute('UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE id = ?', [q, exist[0].id]);
    } else {
      await pool.execute('INSERT INTO cart_items (cart_id, product_id, name, price, image_url, quantity) VALUES (?,?,?,?,?,?)', [cartId, product_id, name || null, priceNum, image_url || null, qtyNum]);
    }
    const [rows] = await pool.execute('SELECT * FROM cart_items WHERE cart_id = ? ORDER BY created_at ASC', [cartId]);
    const items = rows.map(r => mapCartItemRow(r, req));
    const total = items.reduce((sum, it) => sum + (it.price * it.quantity), 0);
    res.status(201).json({ cart_id: cartId, items, total });
  } catch (e) {
    console.error('Cart POST error', e?.message || e);
    res.status(500).json({ error: 'cart_add_failed', message: e?.message });
  }
});

app.patch('/api/cart/items/:id', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    const { id } = req.params;
    const { quantity } = req.body || {};
    if (!Number.isFinite(Number(quantity))) return res.status(400).json({ error: 'quantity inválido' });
    await pool.execute('UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE id = ? AND cart_id = ?', [Number(quantity), id, cartId]);
    const [rows] = await pool.execute('SELECT * FROM cart_items WHERE cart_id = ? ORDER BY created_at ASC', [cartId]);
    const items = rows.map(r => mapCartItemRow(r, req));
    const total = items.reduce((sum, it) => sum + (it.price * it.quantity), 0);
    res.json({ cart_id: cartId, items, total });
  } catch (e) {
    console.error('Cart PATCH error', e);
    res.status(500).json({ error: 'cart_update_failed' });
  }
});

app.delete('/api/cart/items/:id', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    const { id } = req.params;
    await pool.execute('DELETE FROM cart_items WHERE id = ? AND cart_id = ?', [id, cartId]);
    const [rows] = await pool.execute('SELECT * FROM cart_items WHERE cart_id = ? ORDER BY created_at ASC', [cartId]);
    const items = rows.map(r => mapCartItemRow(r, req));
    const total = items.reduce((sum, it) => sum + (it.price * it.quantity), 0);
    res.json({ cart_id: cartId, items, total });
  } catch (e) {
    console.error('Cart DELETE error', e);
    res.status(500).json({ error: 'cart_remove_failed' });
  }
});

// Criação de pedido a partir do carrinho atual
app.post('/api/orders', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    const [rows] = await pool.execute('SELECT * FROM cart_items WHERE cart_id = ?', [cartId]);
    if (!rows.length) return res.status(400).json({ error: 'carrinho_vazio' });
    
    const items = rows;
    const total = items.reduce((sum, it) => sum + Number(it.price) * Number(it.quantity), 0);
    const orderId = require('crypto').randomUUID();
    
    // Dados de entrega/pagamento do body
    const { nome, email, telefone, endereco, metodoPagamento, payment_status = 'pending' } = req.body || {};
    
    // Inserir pedido com dados de entrega
    console.log('🔍 Debug order insert:', { orderId, cartId, total, nome, email, telefone, endereco, metodoPagamento, payment_status });
    
    // Testar estrutura e inserir usando colunas existentes (compatível com schema atual)
    try {
      const [testRows] = await pool.execute('DESCRIBE orders');
      const columns = Array.isArray(testRows) ? testRows.map(r => r.Field) : [];
      console.log('🔍 Tabela orders columns:', columns);

      const hasCartId = columns.includes('cart_id');
      const hasPaymentMethod = columns.includes('payment_method') || columns.includes('metodo_pagamento');
      const hasShippingAddress = columns.includes('shipping_address') || columns.includes('endereco');
      const hasNome = columns.includes('nome');
      const hasEmail = columns.includes('email');
      const hasTelefone = columns.includes('telefone');
      const hasPaymentStatus = columns.includes('payment_status');

      // Montar colunas dinamicamente priorizando nomes do schema atual
      // Descobrir tipo de status
      const statusCol = (testRows || []).find((r) => r.Field === 'status');
      const isStatusNumeric = statusCol && typeof statusCol.Type === 'string' && /int|decimal|float|double/i.test(statusCol.Type);

      const insertCols = ['id', 'status', 'total'];
      const values = [orderId, isStatusNumeric ? 0 : 'pending', total];

      if (hasCartId) {
        insertCols.splice(1, 0, 'cart_id');
        values.splice(1, 0, cartId);
      }

      if (hasNome) {
        insertCols.push('nome');
        values.push(nome || null);
      }

      if (hasEmail) {
        insertCols.push('email');
        values.push(email || null);
      }

      if (hasTelefone) {
        insertCols.push('telefone');
        values.push(telefone || null);
      }

      if (hasShippingAddress) {
        insertCols.push(columns.includes('shipping_address') ? 'shipping_address' : 'endereco');
        values.push(endereco || null);
      }

      if (hasPaymentMethod) {
        insertCols.push(columns.includes('payment_method') ? 'payment_method' : 'metodo_pagamento');
        values.push(metodoPagamento || null);
      }

      if (hasPaymentStatus) {
        insertCols.push('payment_status');
        values.push(payment_status);
      }

      const placeholders = insertCols.map(() => '?').join(',');
      const sql = `INSERT INTO orders (${insertCols.join(', ')}) VALUES (${placeholders})`;
      await pool.execute(sql, values);
    } catch (e) {
      console.log('❌ Erro ao verificar estrutura da tabela orders:', e.message);
      // Fallback: schema padrão minimalista (id, status, total, payment_method, shipping_address)
      await pool.execute(
        'INSERT INTO orders (id, status, total, payment_method, shipping_address) VALUES (?,?,?,?,?)',
        [orderId, 'pending', total, metodoPagamento || null, endereco || null]
      );
    }

    // Inserir itens do pedido (compatível com diferentes schemas)
    {
      const [cols] = await pool.execute('DESCRIBE order_items');
      const colDefs = Array.isArray(cols) ? cols : [];
      const fields = new Set(colDefs.map((c) => c.Field));
      const hasId = fields.has('id');
      const idDef = hasId ? colDefs.find((c) => c.Field === 'id') : null;
      const idAuto = Boolean(idDef && idDef.Extra && idDef.Extra.includes('auto_increment'));
      const idIsNumeric = Boolean(idDef && typeof idDef.Type === 'string' && /int|decimal|float|double/i.test(idDef.Type));

      // Mapear colunas opcionais
      const nameCol = fields.has('name') ? 'name' : (fields.has('product_name') ? 'product_name' : null);
      const imageCol = fields.has('image_url') ? 'image_url' : (fields.has('image') ? 'image' : null);

      for (const it of items) {
        const insertCols = [];
        const insertVals = [];
        if (hasId && !idAuto) {
          insertCols.push('id');
          insertVals.push(idIsNumeric ? Math.floor(Date.now() % 2147483647) : require('crypto').randomUUID());
        }
        // Campos obrigatórios presentes
        if (fields.has('order_id')) { insertCols.push('order_id'); insertVals.push(orderId); }
        if (fields.has('product_id')) { insertCols.push('product_id'); insertVals.push(it.product_id); }
        if (nameCol) { insertCols.push(nameCol); insertVals.push(it.name || 'Produto'); }
        if (fields.has('price')) { insertCols.push('price'); insertVals.push(it.price); }
        if (imageCol) { insertCols.push(imageCol); insertVals.push(it.image_url || null); }
        if (fields.has('quantity')) { insertCols.push('quantity'); insertVals.push(it.quantity || 1); }

        const placeholdersItems = insertCols.map(() => '?').join(',');
        const sqlItems = `INSERT INTO order_items (${insertCols.join(', ')}) VALUES (${placeholdersItems})`;
        await pool.execute(sqlItems, insertVals);
      }
    }

    // Limpa carrinho
    await pool.execute('DELETE FROM cart_items WHERE cart_id = ?', [cartId]);
    
    res.status(201).json({ 
      id: orderId, 
      status: 'criado', 
      total,
      payment_status: payment_status,
      dadosEntrega: { nome: nome || null, email: email || null, telefone: telefone || null, endereco: endereco || null, metodoPagamento: metodoPagamento || null }
    });
  } catch (e) {
    console.error('Order create error', e);
    res.status(500).json({ error: 'order_create_failed' });
  }
});

// Endpoint para gerar QR Code Pix
app.post('/api/orders/:id/pix', async (req, res) => {
  try {
    const { id } = req.params;
    const { total } = req.body;
    
    if (!total || !Number(total)) {
      return res.status(400).json({ error: 'Total inválido' });
    }

    // Buscar configurações PIX
    const [settingsRows] = await pool.execute('SELECT key_name, value_text FROM settings WHERE key_name IN (?, ?, ?, ?)', [
      'pix_key', 'pix_key_type', 'pix_merchant_name', 'pix_city'
    ]);
    
    const settings = {};
    settingsRows.forEach(row => {
      settings[row.key_name] = row.value_text;
    });

    // Verificar se tem chave PIX configurada
    if (!settings.pix_key || !settings.pix_merchant_name) {
      return res.status(400).json({ error: 'Chave PIX não configurada. Configure nas configurações administrativas.' });
    }

    // Gerar código PIX real baseado na configuração
    const pixKey = settings.pix_key;
    const merchantName = settings.pix_merchant_name;
    const city = settings.pix_city || 'São Paulo';
    const amount = total.toFixed(2);
    const orderId = id;

    // Gerar código PIX Copia e Cola (formato EMV)
    const pixCode = generatePixCode({
      pixKey,
      merchantName,
      city,
      amount,
      orderId
    });

    // Gerar QR Code usando uma biblioteca simples (ou mock para demo)
    const qrCodeUrl = await generateQRCodeImage(pixCode);
    
    // Atualizar pedido com dados do Pix
    await pool.execute(`
      UPDATE orders 
      SET payment_status = 'waiting_payment', 
          pix_qr_code = ?,
          payment_data = ?
      WHERE id = ?
    `, [
      pixCode,
      JSON.stringify({
        method: 'pix',
        qr_code: pixCode,
        pix_key: pixKey,
        merchant_name: merchantName,
        expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString(), // 30 min
        amount: total
      }),
      id
    ]);
    
    res.json({
      success: true,
      qr_code: pixCode,
      qr_code_url: qrCodeUrl,
      pix_key: pixKey,
      merchant_name: merchantName,
      expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      amount: total,
      instructions: 'Escaneie o QR Code com seu aplicativo de pagamento ou copie o código Pix'
    });
  } catch (e) {
    console.error('Pix generation error', e);
    res.status(500).json({ error: 'pix_generation_failed' });
  }
});

// Função para gerar código PIX
function generatePixCode({ pixKey, merchantName, city, amount, orderId }) {
  // Formato EMV simplificado para PIX Copia e Cola
  const payload = [
    '00020126', // Payload Format Indicator
    '010211',   // Point of Initiation Method
    '520400005303986', // Merchant Account Information
    '5406' + amount.padStart(6, '0'), // Transaction Amount
    '5802BR', // Country Code
    '59' + (merchantName.length).toString().padStart(2, '0') + merchantName, // Merchant Name
    '60' + (city.length).toString().padStart(2, '0') + city, // Merchant City
    '62' + (orderId.length + 4).toString().padStart(2, '0') + '05' + orderId.length.toString().padStart(2, '0') + orderId, // Additional Data Field
    '6304' // CRC16
  ].join('');

  // Adicionar chave PIX
  const pixKeyLength = pixKey.length.toString().padStart(2, '0');
  const pixKeyField = '01' + pixKeyLength + pixKey;
  
  const fullPayload = payload.replace('520400005303986', '52' + (pixKeyField.length + 4).toString().padStart(2, '0') + '0001' + pixKeyField);
  
  // Calcular CRC16 (simplificado)
  const crc = calculateCRC16(fullPayload.substring(0, fullPayload.length - 4));
  const finalPayload = fullPayload.substring(0, fullPayload.length - 4) + crc.toString(16).padStart(4, '0').toUpperCase();
  
  return finalPayload;
}

// Função para calcular CRC16 (simplificada)
function calculateCRC16(str) {
  let crc = 0xFFFF;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i);
    for (let j = 0; j < 8; j++) {
      if (crc & 1) {
        crc = (crc >> 1) ^ 0x8408;
      } else {
        crc = crc >> 1;
      }
    }
  }
  return crc;
}

// Função para gerar QR Code (mock por enquanto)
async function generateQRCodeImage(pixCode) {
  // Em produção, usar uma biblioteca como 'qrcode' ou 'qrcode-generator'
  // Por enquanto, retornar uma imagem base64 mock
  return `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==`;
}

// Endpoint para gerar QR Code PIX do carrinho
app.post('/api/cart/pix-qr', async (req, res) => {
  try {
    const { total } = req.body;
    
    if (!total || !Number(total)) {
      return res.status(400).json({ error: 'Total inválido' });
    }

    // Buscar configurações PIX
    const [settingsRows] = await pool.execute('SELECT key_name, value_text FROM settings WHERE key_name IN (?, ?, ?, ?, ?)', [
      'pix_key', 'pix_key_type', 'pix_merchant_name', 'pix_city', 'pix_show_qr_cart'
    ]);
    
    const settings = {};
    settingsRows.forEach(row => {
      settings[row.key_name] = row.value_text;
    });

    // Verificar se deve mostrar QR no carrinho
    if (settings.pix_show_qr_cart !== 'true') {
      return res.status(400).json({ error: 'QR Code PIX no carrinho desabilitado' });
    }

    // Verificar se tem chave PIX configurada
    if (!settings.pix_key || !settings.pix_merchant_name) {
      return res.status(400).json({ error: 'Chave PIX não configurada' });
    }

    // Gerar código PIX para o carrinho
    const pixKey = settings.pix_key;
    const merchantName = settings.pix_merchant_name;
    const city = settings.pix_city || 'São Paulo';
    const amount = total.toFixed(2);
    const cartId = `cart_${Date.now()}`;

    // Gerar código PIX Copia e Cola (formato EMV)
    const pixCode = generatePixCode({
      pixKey,
      merchantName,
      city,
      amount,
      orderId: cartId
    });

    // Gerar QR Code
    const qrCodeUrl = await generateQRCodeImage(pixCode);
    
    res.json({
      success: true,
      qr_code: pixCode,
      qr_code_url: qrCodeUrl,
      pix_key: pixKey,
      merchant_name: merchantName,
      amount: total,
      instructions: 'Escaneie o QR Code para pagar via PIX',
      show_in_cart: true
    });
  } catch (e) {
    console.error('Cart Pix QR error', e);
    res.status(500).json({ error: 'cart_pix_qr_failed' });
  }
});

// Endpoint para consultar status de pagamento
app.get('/api/orders/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    
    const [rows] = await pool.execute(`
      SELECT id, status, payment_status, total, payment_data, created_at 
      FROM orders 
      WHERE id = ?
    `, [id]);
    
    if (!rows.length) {
      return res.status(404).json({ error: 'Pedido não encontrado' });
    }
    
    const order = rows[0];
    const paymentData = order.payment_data ? JSON.parse(order.payment_data) : null;
    
    res.json({
      id: order.id,
      status: order.status,
      payment_status: order.payment_status,
      total: order.total,
      payment_data: paymentData,
      created_at: order.created_at
    });
  } catch (e) {
    console.error('Order status error', e);
    res.status(500).json({ error: 'status_check_failed' });
  }
});

// Endpoint para simular pagamento confirmado (mock)
app.post('/api/orders/:id/confirm-payment', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Atualizar status do pedido
    await pool.execute(`
      UPDATE orders 
      SET payment_status = 'paid', 
          status = 'processing'
      WHERE id = ?
    `, [id]);
    
    res.json({
      success: true,
      message: 'Pagamento confirmado com sucesso',
      payment_status: 'paid',
      order_status: 'processing'
    });
  } catch (e) {
    console.error('Payment confirmation error', e);
    res.status(500).json({ error: 'payment_confirmation_failed' });
  }
});

// Lista pedidos simples (por cart_id)
app.get('/api/orders', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    // Detectar colunas da tabela orders para decidir filtro
    let hasCartId = false;
    try {
      const [cols] = await pool.execute('DESCRIBE orders');
      hasCartId = Array.isArray(cols) && cols.some(r => r.Field === 'cart_id');
    } catch (e) {
      console.log('⚠️ Não foi possível DESCREVER orders, listando sem filtro:', e.message);
    }

    const [orders] = hasCartId
      ? await pool.execute(
          `SELECT o.*, (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS items_count
             FROM orders o
            WHERE o.cart_id = ?
         ORDER BY o.created_at DESC`,
          [cartId]
        )
      : await pool.execute(
          `SELECT o.*, (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS items_count
             FROM orders o
         ORDER BY o.created_at DESC`
        );

    // Normalizar status e tipos para frontend
    const normalized = (orders || []).map((o) => {
      const rawStatus = o.status;
      let friendlyStatus = rawStatus || 'criado';
      try {
        if (rawStatus === 0 || String(rawStatus).toLowerCase() === 'pending') {
          friendlyStatus = 'processando';
        }
      } catch (_e) {}
      const count = Number(o.items_count || 0);
      return {
        id: o.id,
        status: friendlyStatus,
        total: Number(o.total || 0),
        created_at: o.created_at || null,
        items_count: count,
      };
    });

    res.json(normalized);
  } catch (e) {
    console.error('Orders list error', e);
    res.status(500).json({ error: 'orders_list_failed' });
  }
});

// Criar tabelas para página Sobre
(async () => {
  try {
    // Tabela para conteúdo da página Sobre
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS sobre_content (
        id VARCHAR(191) PRIMARY KEY,
        section VARCHAR(100) NOT NULL,
        title VARCHAR(255),
        subtitle VARCHAR(255),
        description TEXT,
        image_url VARCHAR(500),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        metadata JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_section (section)
      )
    `);
    console.log('✅ Tabela sobre_content criada/verificada');

    // Tabela para valores da empresa
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS company_values (
        id VARCHAR(191) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        icon VARCHAR(100),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela company_values criada/verificada');

    // Tabela para equipe
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS team_members (
        id VARCHAR(191) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        position VARCHAR(255),
        description TEXT,
        image_url VARCHAR(500),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela team_members criada/verificada');

    // Tabela para estatísticas
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS company_stats (
        id VARCHAR(191) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        value VARCHAR(100) NOT NULL,
        icon VARCHAR(100),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela company_stats criada/verificada');

    // Tabela para informações de contato
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS contact_info (
        id VARCHAR(191) PRIMARY KEY,
        type VARCHAR(100) NOT NULL,
        title VARCHAR(255) NOT NULL,
        value VARCHAR(255) NOT NULL,
        icon VARCHAR(100),
        order_index INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela contact_info criada/verificada');

    // Inserir dados iniciais para a seção hero se não existir
    const [existingHero] = await pool.execute('SELECT id FROM sobre_content WHERE section = ?', ['hero']);
    if (existingHero.length === 0) {
      const heroId = require('crypto').randomUUID();
      await pool.execute(`
        INSERT INTO sobre_content (id, section, title, subtitle, description, metadata, is_active)
        VALUES (?, 'hero', 'Nossa História', '', 'A MuhlStore nasceu do sonho de conectar pessoas através de brinquedos únicos e especiais. Desde 2020, nossa missão é descobrir e compartilhar tesouros de brinquedos raros e seminovos de todo o Brasil.', ?, TRUE)
      `, [heroId, JSON.stringify({
        badge_text: 'Nossa História',
        badge_icon: 'Sparkles',
        show_badge: true,
        buttons: [
          {
            id: '1',
            text: 'Conheça Nossos Produtos',
            icon: 'Gift',
            variant: 'primary',
            action: '/loja',
            color: 'orange'
          },
          {
            id: '2',
            text: 'Nossa Missão',
            icon: 'Heart',
            variant: 'outline',
            action: '/about',
            color: 'orange'
          }
        ]
      })]);
      console.log('✅ Dados iniciais da seção hero criados');
    }

  } catch (err) {
    console.error('❌ Erro ao criar tabelas da página Sobre:', { message: err?.message, code: err?.code });
  }
})();

// ==========================
// Endereços do cliente (por cart_id)
// ==========================
(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS addresses (
        id VARCHAR(191) PRIMARY KEY,
        cart_id VARCHAR(191) NOT NULL,
        nome VARCHAR(255),
        telefone VARCHAR(100),
        cep VARCHAR(20),
        endereco VARCHAR(255),
        numero VARCHAR(50),
        complemento VARCHAR(255),
        bairro VARCHAR(255),
        cidade VARCHAR(255),
        estado VARCHAR(50),
        shipping_default TINYINT(1) DEFAULT 0,
        billing_default TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_cart (cart_id)
      )
    `);
    console.log('✅ Tabela addresses criada/verificada');
  } catch (e) {
    console.error('❌ Erro ao criar tabela addresses', e);
  }
})();

const { randomUUID: uuidv4 } = require('crypto');

app.get('/api/addresses', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    const [rows] = await pool.execute('SELECT * FROM addresses WHERE cart_id = ? ORDER BY updated_at DESC', [cartId]);
    res.json(rows || []);
  } catch (e) {
    console.error('Addresses list error', e);
    res.status(500).json({ error: 'addresses_list_failed' });
  }
});

app.post('/api/addresses', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    const id = uuidv4();
    const { nome, telefone, cep, endereco, numero, complemento, bairro, cidade, estado, shipping_default, billing_default } = req.body || {};

    if (shipping_default) {
      await pool.execute('UPDATE addresses SET shipping_default = 0 WHERE cart_id = ?', [cartId]);
    }
    if (billing_default) {
      await pool.execute('UPDATE addresses SET billing_default = 0 WHERE cart_id = ?', [cartId]);
    }

    await pool.execute(
      `INSERT INTO addresses (id, cart_id, nome, telefone, cep, endereco, numero, complemento, bairro, cidade, estado, shipping_default, billing_default)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [id, cartId, nome || null, telefone || null, cep || null, endereco || null, numero || null, complemento || null, bairro || null, cidade || null, estado || null, shipping_default ? 1 : 0, billing_default ? 1 : 0]
    );
    const [row] = await pool.execute('SELECT * FROM addresses WHERE id = ? LIMIT 1', [id]);
    res.status(201).json(Array.isArray(row) && row[0] ? row[0] : { id });
  } catch (e) {
    console.error('Addresses create error', e);
    res.status(500).json({ error: 'addresses_create_failed' });
  }
});

app.put('/api/addresses/:id', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    const { id } = req.params;
    const { nome, telefone, cep, endereco, numero, complemento, bairro, cidade, estado, shipping_default, billing_default } = req.body || {};

    if (shipping_default) {
      await pool.execute('UPDATE addresses SET shipping_default = 0 WHERE cart_id = ?', [cartId]);
    }
    if (billing_default) {
      await pool.execute('UPDATE addresses SET billing_default = 0 WHERE cart_id = ?', [cartId]);
    }

    await pool.execute(
      `UPDATE addresses SET nome=?, telefone=?, cep=?, endereco=?, numero=?, complemento=?, bairro=?, cidade=?, estado=?, shipping_default=?, billing_default=? WHERE id = ? AND cart_id = ?`,
      [nome || null, telefone || null, cep || null, endereco || null, numero || null, complemento || null, bairro || null, cidade || null, estado || null, shipping_default ? 1 : 0, billing_default ? 1 : 0, id, cartId]
    );
    const [row] = await pool.execute('SELECT * FROM addresses WHERE id = ? AND cart_id = ? LIMIT 1', [id, cartId]);
    if (!Array.isArray(row) || row.length === 0) return res.status(404).json({ error: 'address_not_found' });
    res.json(row[0]);
  } catch (e) {
    console.error('Addresses update error', e);
    res.status(500).json({ error: 'addresses_update_failed' });
  }
});

app.delete('/api/addresses/:id', async (req, res) => {
  try {
    const cartId = getOrCreateCartId(req, res);
    const { id } = req.params;
    await pool.execute('DELETE FROM addresses WHERE id = ? AND cart_id = ?', [id, cartId]);
    res.json({ ok: true });
  } catch (e) {
    console.error('Addresses delete error', e);
    res.status(500).json({ error: 'addresses_delete_failed' });
  }
});

// GET /api/collections/:id/products - Listar produtos vinculados
app.get('/api/collections/:id/products', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔎 Listando produtos da coleção ${id}`);
    const [links] = await pool.execute('SELECT * FROM collection_products WHERE collection_id = ? ORDER BY order_index ASC, created_at ASC', [id]);
    console.log(`🔢 Vínculos encontrados: ${links.length}`);

    // Detect optional product columns to enrich response
    let productDetailsMap = {};
    if (links.length > 0) {
      const productIds = links.map(l => l.product_id);
      const [prodCols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products'");
      const prodColNames = new Set(prodCols.map(c => c.COLUMN_NAME));
      const idCol = prodColNames.has('id') ? 'id' : null;
      const nameCol = prodColNames.has('name') ? 'name' : (prodColNames.has('nome') ? 'nome' : null);
      const imageCol = prodColNames.has('image_url') ? 'image_url' : (prodColNames.has('imagem_url') ? 'imagem_url' : null);
      const priceCol = prodColNames.has('price') ? 'price' : (prodColNames.has('preco') ? 'preco' : null);

      if (idCol) {
        const [rows] = await pool.query(`SELECT * FROM products WHERE ${idCol} IN (${productIds.map(() => '?').join(',')})`, productIds);
        console.log(`🧾 Produtos carregados: ${rows.length}`);
        productDetailsMap = rows.reduce((acc, row) => {
          acc[row[idCol]] = {
            id: row[idCol],
            name: nameCol ? row[nameCol] : undefined,
            image_url: imageCol ? row[imageCol] : undefined,
            price: priceCol ? row[priceCol] : undefined
          };
          return acc;
        }, {});
      }
    }

    const result = links.map(l => ({
      id: l.id,
      collection_id: l.collection_id,
      product_id: l.product_id,
      order_index: l.order_index,
      product: productDetailsMap[l.product_id] || null
    }));
    res.json(result);
  } catch (error) {
    console.error('❌ Erro ao listar produtos da coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// POST /api/collections/:id/products - Vincular produto à coleção
app.post('/api/collections/:id/products', async (req, res) => {
  try {
    const { id } = req.params;
    const { product_id, order_index } = req.body || {};
    if (!product_id) {
      return res.status(400).json({ error: 'product_id é obrigatório' });
    }

    // Checar existência de coleção
    const [cRows] = await pool.execute('SELECT id FROM collections WHERE id = ?', [id]);
    if (!cRows || cRows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    // Checar existência de produto (se tabela products existir)
    try {
      const [pRows] = await pool.execute('SELECT id FROM products WHERE id = ?', [product_id]);
      if (!pRows || pRows.length === 0) return res.status(404).json({ error: 'Produto não encontrado' });
    } catch (e) {
      // Se não existir a tabela products, segue sem validar
    }

    const ord = Number.isFinite(order_index) ? order_index : 0;
    const [result] = await pool.execute(
      'INSERT INTO collection_products (collection_id, product_id, order_index, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
      [id, product_id, ord]
    );

    res.status(201).json({ id: result.insertId, collection_id: id, product_id, order_index: ord });
  } catch (error) {
    console.error('❌ Erro ao adicionar produto na coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// DELETE /api/collections/:id/products/:productId - Remover vínculo
app.delete('/api/collections/:id/products/:productId', async (req, res) => {
  try {
    const { id, productId } = req.params;
    await pool.execute('DELETE FROM collection_products WHERE collection_id = ? AND product_id = ?', [id, productId]);
    res.json({ success: true });
  } catch (error) {
    console.error('❌ Erro ao remover produto da coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// PATCH /api/collections/:id/products/reorder - Reordenar produtos vinculados
app.patch('/api/collections/:id/products/reorder', async (req, res) => {
  try {
    const { id } = req.params;
    const { product_ids } = req.body || {};
    if (!Array.isArray(product_ids) || product_ids.length === 0) {
      return res.status(400).json({ error: 'product_ids é obrigatório (array)' });
    }

    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      for (let i = 0; i < product_ids.length; i++) {
        await connection.execute(
          'UPDATE collection_products SET order_index = ?, updated_at = NOW() WHERE collection_id = ? AND product_id = ?',
          [i, id, product_ids[i]]
        );
      }
      await connection.commit();
    } catch (e) {
      await connection.rollback();
      throw e;
    } finally {
      connection.release();
    }

    res.json({ success: true });
  } catch (error) {
    console.error('❌ Erro ao reordenar produtos da coleção:', { message: error?.message, code: error?.code });
    res.status(500).json({ error: 'Erro interno do servidor', message: error?.message, code: error?.code });
  }
});

// DEBUG: resumo de coleção e vínculos
app.get('/api/debug/collections/:id/summary', async (req, res) => {
  try {
    const { id } = req.params;
    const [[cRows], [lRows]] = await Promise.all([
      pool.execute('SELECT * FROM collections WHERE id = ?', [id]),
      pool.execute('SELECT * FROM collection_products WHERE collection_id = ?', [id])
    ]);
    const collection = cRows && cRows[0] ? cRows[0] : null;
    res.json({ collection, links_count: lRows.length, sample_links: lRows.slice(0, 5) });
  } catch (error) {
    console.error('❌ Debug summary error:', error);
    res.status(500).json({ error: 'debug_failed' });
  }
});

// PUT /api/collections/reorder - Reordenar coleções
app.put('/api/collections/reorder', async (req, res) => {
  try {
    const { ids } = req.body;
    console.log('🔄 Reordenando coleções...');
    
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Lista de IDs é obrigatória' });
    }
    
    // Atualizar ordem de cada coleção (se a coluna ordem existir)
    const [cols] = await pool.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'collections'");
    const hasOrdem = cols.some((c) => c.COLUMN_NAME === 'ordem');
    for (let i = 0; i < ids.length; i++) {
      if (hasOrdem) {
        await pool.execute('UPDATE collections SET ordem = ?, updated_at = NOW() WHERE id = ?', [i, ids[i]]);
      } else {
        await pool.execute('UPDATE collections SET updated_at = NOW() WHERE id = ?', [ids[i]]);
      }
    }
    
    console.log(`✅ ${ids.length} coleções reordenadas com sucesso`);
    res.json({ message: 'Coleções reordenadas com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao reordenar coleções:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/collections/seed - Popular coleções de exemplo
app.post('/api/collections/seed', async (req, res) => {
  try {
    console.log('🔄 Populando coleções de exemplo...');
    
    const colecoesExemplo = [
      {
        nome: 'Action Figures Premium',
        descricao: 'Bonecos de ação de alta qualidade com detalhes incríveis e articulações avançadas',
        imagem_url: '/lovable-uploads/action-figures-collection.jpg',
        destaque: true
      },
      {
        nome: 'Colecionáveis Vintage',
        descricao: 'Itens raros e vintage para colecionadores apaixonados por peças únicas',
        imagem_url: '/lovable-uploads/vintage-collection.jpg',
        destaque: true
      },
      {
        nome: 'Brinquedos Educativos',
        descricao: 'Jogos e brinquedos que estimulam o aprendizado e desenvolvimento infantil',
        imagem_url: '/lovable-uploads/educational-toys.jpg',
        destaque: false
      },
      {
        nome: 'Pelúcias Premium',
        descricao: 'Pelúcias macias e fofas, perfeitas para conforto e decoração',
        imagem_url: '/lovable-uploads/plush-toys.jpg',
        destaque: false
      },
      {
        nome: 'Jogos de Tabuleiro',
        descricao: 'Clássicos e modernos jogos de tabuleiro para diversão em família',
        imagem_url: '/lovable-uploads/board-games.jpg',
        destaque: true
      },
      {
        nome: 'Carrinhos e Veículos',
        descricao: 'Carros, caminhões e veículos de todos os tipos para pequenos motoristas',
        imagem_url: '/lovable-uploads/vehicles-collection.jpg',
        destaque: false
      }
    ];
    
    for (const colecao of colecoesExemplo) {
      await pool.execute(
        'INSERT IGNORE INTO collections (nome, descricao, imagem_url, destaque, ativo, created_at, updated_at) VALUES (?, ?, ?, ?, 1, NOW(), NOW())',
        [colecao.nome, colecao.descricao, colecao.imagem_url, colecao.destaque]
      );
    }
    
    console.log(`✅ ${colecoesExemplo.length} coleções de exemplo criadas`);
    res.json({ message: `${colecoesExemplo.length} coleções de exemplo criadas com sucesso` });
  } catch (error) {
    console.error('❌ Erro ao popular coleções:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Upload de imagem para coleções
app.post('/api/collections/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    }

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    const fullUrl = getPublicUrl(req, imageUrl);
    
    console.log(`✅ Imagem de coleção enviada: ${req.file.filename}`);
    
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      fullUrl: fullUrl,
      filename: req.file.filename 
    });
  } catch (error) {
    console.error('❌ Erro no upload de imagem:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Upload direto da imagem da coleção (multipart) e atualizar registro
app.post('/api/collections/:id/image', upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    if (!req.file) return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    // garantir que a coleção existe
    const [rows] = await pool.execute('SELECT id FROM collections WHERE id = ?', [id]);
    if (!rows || rows.length === 0) return res.status(404).json({ error: 'Coleção não encontrada' });

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    await pool.execute('UPDATE collections SET imagem_url = ?, updated_at = NOW() WHERE id = ?', [imageUrl, id]);

    const host = req.get('host');
    const proto = req.protocol || 'http';
    const fullUrl = getPublicUrl(req, imageUrl);
    res.json({ success: true, id, imagem_url: imageUrl, imagem: fullUrl, filename: req.file.filename });
  } catch (error) {
    console.error('❌ Erro ao atualizar imagem da coleção:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rota para verificar estrutura da tabela collections
app.get('/api/debug/collections-structure', async (req, res) => {
  try {
    const [rows] = await pool.execute('DESCRIBE collections');
    res.json({ structure: rows });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Rota para adicionar colunas faltantes
app.post('/api/debug/fix-collections-table', async (req, res) => {
  try {
    console.log('🔄 Verificando e corrigindo estrutura da tabela collections...');
    
    // Verificar se a coluna destaque existe
    const [columns] = await pool.execute("SHOW COLUMNS FROM collections LIKE 'destaque'");
    if (columns.length === 0) {
      await pool.execute('ALTER TABLE collections ADD COLUMN destaque BOOLEAN DEFAULT FALSE');
      console.log('✅ Coluna destaque adicionada');
    }
    
    // Verificar se a coluna tags existe
    const [tagsColumns] = await pool.execute("SHOW COLUMNS FROM collections LIKE 'tags'");
    if (tagsColumns.length === 0) {
      await pool.execute('ALTER TABLE collections ADD COLUMN tags JSON');
      console.log('✅ Coluna tags adicionada');
    }
    
    // Verificar se a coluna ordem existe
    const [ordemColumns] = await pool.execute("SHOW COLUMNS FROM collections LIKE 'ordem'");
    if (ordemColumns.length === 0) {
      await pool.execute('ALTER TABLE collections ADD COLUMN ordem INT DEFAULT 0');
      console.log('✅ Coluna ordem adicionada');
    }
    
    res.json({ message: 'Estrutura da tabela corrigida com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao corrigir tabela:', error);
    res.status(500).json({ error: error.message });
  }
});

// ===== PÁGINA SOBRE API =====

// GET /api/sobre/content - Buscar conteúdo da página Sobre
app.get('/api/sobre/content', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM sobre_content 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar conteúdo da página Sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/content/:section - Atualizar conteúdo de uma seção
app.put('/api/sobre/content/:section', async (req, res) => {
  try {
    const { section } = req.params;
    const { title, subtitle, description, image_url, metadata } = req.body;
    
    const id = require('crypto').randomUUID();
    
    // Garantir que os valores não sejam undefined
    const safeTitle = title || null;
    const safeSubtitle = subtitle || null;
    const safeDescription = description || null;
    const safeImageUrl = image_url || null;
    const safeMetadata = metadata ? JSON.stringify(metadata) : null;
    
    
    await pool.execute(`
      INSERT INTO sobre_content (id, section, title, subtitle, description, image_url, metadata, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, TRUE)
      ON DUPLICATE KEY UPDATE
        title = VALUES(title),
        subtitle = VALUES(subtitle),
        description = VALUES(description),
        image_url = VALUES(image_url),
        metadata = VALUES(metadata),
        updated_at = CURRENT_TIMESTAMP
    `, [id, section, safeTitle, safeSubtitle, safeDescription, safeImageUrl, safeMetadata]);
    
    res.json({ success: true, message: 'Conteúdo atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar conteúdo da página Sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/content/:id - Atualizar conteúdo específico por ID
app.put('/api/sobre/content/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, subtitle, description, image_url, metadata } = req.body;
    
    // Garantir que os valores não sejam undefined
    const safeTitle = title || null;
    const safeSubtitle = subtitle || null;
    const safeDescription = description || null;
    const safeImageUrl = image_url || null;
    const safeMetadata = metadata ? JSON.stringify(metadata) : null;
    
    await pool.execute(`
      UPDATE sobre_content 
      SET title = ?, subtitle = ?, description = ?, image_url = ?, metadata = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `, [safeTitle, safeSubtitle, safeDescription, safeImageUrl, safeMetadata, id]);
    
    res.json({ success: true, message: 'Conteúdo atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar conteúdo da página Sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/upload-image - Upload de imagem para página Sobre
app.post('/api/sobre/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhuma imagem enviada' });
    }

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    res.json({ 
      success: true, 
      image_url: imageUrl,
      message: 'Imagem enviada com sucesso' 
    });
  } catch (error) {
    console.error('❌ Erro no upload de imagem da página Sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/values - Buscar valores da empresa
app.get('/api/sobre/values', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM company_values 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar valores da empresa:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/values - Criar novo valor
app.post('/api/sobre/values', async (req, res) => {
  try {
    const { title, description, icon, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO company_values (id, title, description, icon, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, TRUE)
    `, [id, title, description, icon, order_index || 0]);
    
    res.json({ success: true, id, message: 'Valor criado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar valor:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/values/:id - Atualizar valor
app.put('/api/sobre/values/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, icon, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE company_values 
      SET title = ?, description = ?, icon = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [title, description, icon, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Valor atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar valor:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/values/:id - Deletar valor
app.delete('/api/sobre/values/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM company_values WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Valor deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar valor:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/team - Buscar membros da equipe
app.get('/api/sobre/team', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM team_members 
      WHERE is_active = 1 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar membros da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/team - Criar novo membro da equipe
app.post('/api/sobre/team', async (req, res) => {
  try {
    const { name, position, description, image_url, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO team_members (id, name, position, description, image_url, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, ?, TRUE)
    `, [id, name, position, description, image_url, order_index || 0]);
    
    res.json({ success: true, id, message: 'Membro da equipe criado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/team/:id - Atualizar membro da equipe
app.put('/api/sobre/team/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, position, description, image_url, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE team_members 
      SET name = ?, position = ?, description = ?, image_url = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [name, position, description, image_url, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Membro da equipe atualizado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/team/:id - Deletar membro da equipe
app.delete('/api/sobre/team/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM team_members WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Membro da equipe deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/stats - Buscar estatísticas da empresa
app.get('/api/sobre/stats', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM company_stats 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar estatísticas da empresa:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/stats - Criar nova estatística
app.post('/api/sobre/stats', async (req, res) => {
  try {
    const { title, value, icon, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO company_stats (id, title, value, icon, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, TRUE)
    `, [id, title, value, icon, order_index || 0]);
    
    res.json({ success: true, id, message: 'Estatística criada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar estatística:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/stats/:id - Atualizar estatística
app.put('/api/sobre/stats/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, value, icon, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE company_stats 
      SET title = ?, value = ?, icon = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [title, value, icon, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Estatística atualizada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar estatística:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/stats/:id - Deletar estatística
app.delete('/api/sobre/stats/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM company_stats WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Estatística deletada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar estatística:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/sobre/contact - Buscar informações de contato
app.get('/api/sobre/contact', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT * FROM contact_info 
      WHERE is_active = TRUE 
      ORDER BY order_index ASC, created_at ASC
    `);
    res.json(rows);
  } catch (error) {
    console.error('❌ Erro ao buscar informações de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/sobre/contact - Criar nova informação de contato
app.post('/api/sobre/contact', async (req, res) => {
  try {
    const { type, title, value, icon, order_index } = req.body;
    const id = require('crypto').randomUUID();
    
    await pool.execute(`
      INSERT INTO contact_info (id, type, title, value, icon, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, ?, TRUE)
    `, [id, type, title, value, icon, order_index || 0]);
    
    res.json({ success: true, id, message: 'Informação de contato criada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao criar informação de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// PUT /api/sobre/contact/:id - Atualizar informação de contato
app.put('/api/sobre/contact/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { type, title, value, icon, order_index, is_active } = req.body;
    
    await pool.execute(`
      UPDATE contact_info 
      SET type = ?, title = ?, value = ?, icon = ?, order_index = ?, is_active = ?
      WHERE id = ?
    `, [type, title, value, icon, order_index || 0, is_active !== false, id]);
    
    res.json({ success: true, message: 'Informação de contato atualizada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao atualizar informação de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// DELETE /api/sobre/contact/:id - Deletar informação de contato
app.delete('/api/sobre/contact/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await pool.execute('DELETE FROM contact_info WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Informação de contato deletada com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar informação de contato:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// ===== UPLOAD DE IMAGENS PARA PÁGINA SOBRE =====

// Upload de imagem geral para página sobre
app.post('/api/sobre/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    }

    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    const fullUrl = getPublicUrl(req, imageUrl);
    
    console.log(`✅ Imagem da página sobre enviada: ${req.file.filename}`);
    
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      fullUrl: fullUrl,
      filename: req.file.filename 
    });
  } catch (error) {
    console.error('❌ Erro no upload de imagem da página sobre:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Upload de imagem para membro da equipe
app.post('/api/sobre/team/:id/image', upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    if (!req.file) return res.status(400).json({ error: 'Nenhuma imagem foi enviada' });
    
    const imageUrl = `/lovable-uploads/${req.file.filename}`;
    const fullUrl = getPublicUrl(req, imageUrl);
    
    // Atualizar o registro do membro da equipe
    await pool.execute(
      'UPDATE team_members SET image_url = ? WHERE id = ?',
      [fullUrl, id]
    );
    
    console.log(`✅ Imagem do membro da equipe ${id} atualizada: ${req.file.filename}`);
    
    res.json({ 
      success: true, 
      imageUrl: imageUrl,
      fullUrl: fullUrl,
      filename: req.file.filename 
    });
  } catch (error) {
    console.error('❌ Erro no upload de imagem do membro da equipe:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.get('/api/health', async (req, res) => {
  try {
    await pool.execute('SELECT 1');
    res.json({ status: 'healthy', database: 'connected' });
  } catch (error) {
    res.status(500).json({ status: 'unhealthy', database: 'disconnected', error: error.message });
  }
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Carousel API server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🎠 Carousel API: http://localhost:${PORT}/api/carousel`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down server...');
  await pool.end();
  process.exit(0);
});

app.get('/api/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    // Buscar pedido
    const [orders] = await pool.execute('SELECT * FROM orders WHERE id = ?', [id]);
    if (!Array.isArray(orders) || orders.length === 0) {
      return res.status(404).json({ error: 'order_not_found' });
    }
    const order = orders[0];

    // Buscar itens do pedido
    let items;
    try {
      const [cols] = await pool.execute('DESCRIBE order_items');
      const fields = Array.isArray(cols) ? cols.map((c) => c.Field) : [];
      const nameCol = fields.includes('name') ? 'name' : (fields.includes('product_name') ? 'product_name' : null);
      const imageCol = fields.includes('image_url') ? 'image_url' : (fields.includes('image') ? 'image' : null);
      const sql = `SELECT order_id, product_id, ${nameCol || "'Produto' AS name"}, price, ${imageCol || "NULL AS image_url"}, quantity FROM order_items WHERE order_id = ?`;
      const [rows] = await pool.execute(sql, [id]);
      items = rows;
    } catch {
      const [rows] = await pool.execute('SELECT order_id, product_id, price, quantity FROM order_items WHERE order_id = ?', [id]);
      items = rows.map((r) => ({ ...r, name: 'Produto', image_url: null }));
    }

    // Normalização básica de tipos e URLs
    let normalizedItems = (items || []).map((it) => ({
      order_id: it.order_id,
      product_id: it.product_id,
      name: it.name,
      price: Number(it.price || 0),
      image_url: it.image_url ? getPublicUrl(req, it.image_url) : null,
      quantity: Number(it.quantity || 1),
    }));

    // Enriquecer com dados de products quando faltar name/imagem
    try {
      const missing = normalizedItems.filter(i => !i.image_url || !i.name || i.name === 'Produto');
      const productIds = [...new Set(missing.map(i => i.product_id))];
      if (productIds.length > 0) {
        const placeholders = productIds.map(() => '?').join(',');
        // Detectar colunas reais de products
        let pRows;
        try {
          const [pCols] = await pool.execute('DESCRIBE products');
          const pFields = Array.isArray(pCols) ? pCols.map(c => c.Field) : [];
          const nameCol = pFields.includes('nome') ? 'nome' : (pFields.includes('name') ? 'name' : null);
          const imgCol = pFields.includes('imagem_url') ? 'imagem_url'
                         : (pFields.includes('image_url') ? 'image_url'
                         : (pFields.includes('imagemUrl') ? 'imagemUrl'
                         : (pFields.includes('image') ? 'image' : null)));
          const selectNome = nameCol ? nameCol : "NULL";
          const selectImg = imgCol ? imgCol : "NULL";
          const [rows] = await pool.query(
            `SELECT id, ${selectNome} AS nome, ${selectImg} AS imagem_url FROM products WHERE id IN (${placeholders})`,
            productIds
          );
          pRows = rows;
        } catch (_e) {
          // Fallback amplo
          const [rows] = await pool.query(
            `SELECT id, COALESCE(nome, name) AS nome, COALESCE(imagem_url, image_url) AS imagem_url FROM products WHERE id IN (${placeholders})`,
            productIds
          );
          pRows = rows;
        }
        const map = new Map((pRows || []).map(r => [String(r.id), r]));
        normalizedItems = normalizedItems.map(i => {
          const needsName = !i.name || i.name === 'Produto';
          const needsImage = !i.image_url;
          if (needsName || needsImage) {
            const p = map.get(String(i.product_id));
            if (p) {
              if (needsName) i.name = p.nome || 'Produto';
              if (needsImage) i.image_url = p.imagem_url ? getPublicUrl(req, p.imagem_url) : null;
            }
          }
          return i;
        });
      }
    } catch {}

    // Mapear campos conforme schema atual
    const paymentMethod = order.payment_method || order.metodo_pagamento || null;
    const shippingAddress = order.shipping_address || order.endereco || null;
    const rawStatus = order.status;
    let friendlyStatus = rawStatus || 'criado';
    try {
      if (rawStatus === 0 || String(rawStatus).toLowerCase() === 'pending') {
        friendlyStatus = 'processando';
      }
    } catch (_e) {}

    res.json({
      id: order.id,
      status: friendlyStatus,
      total: Number(order.total || 0),
      created_at: order.created_at || null,
      nome: order.nome || null,
      email: order.email || null,
      telefone: order.telefone || null,
      endereco: shippingAddress,
      metodo_pagamento: paymentMethod,
      items: normalizedItems,
    });
  } catch (e) {
    console.error('Order detail error', e);
    res.status(500).json({ error: 'order_detail_failed' });
  }
});

app.post('/api/orders/:id/reorder', async (req, res) => {
  try {
    const { id } = req.params;
    const cartId = getOrCreateCartId(req, res);

    // Buscar itens do pedido
    let items;
    try {
      const [cols] = await pool.execute('DESCRIBE order_items');
      const fields = Array.isArray(cols) ? cols.map((c) => c.Field) : [];
      const nameCol = fields.includes('name') ? 'name' : (fields.includes('product_name') ? 'product_name' : null);
      const imageCol = fields.includes('image_url') ? 'image_url' : (fields.includes('image') ? 'image' : null);
      const sql = `SELECT product_id, ${nameCol || "'Produto' AS name"}, price, ${imageCol || "NULL AS image_url"}, quantity FROM order_items WHERE order_id = ?`;
      const [rows] = await pool.execute(sql, [id]);
      items = rows;
    } catch {
      const [rows] = await pool.execute('SELECT product_id, price, quantity FROM order_items WHERE order_id = ?', [id]);
      items = rows.map((r) => ({ ...r, name: 'Produto', image_url: null }));
    }

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(404).json({ error: 'order_items_not_found' });
    }

    // Inserir/atualizar no carrinho: somar quantidades se já existir mesmo product_id
    for (const it of items) {
      // Verificar se já existe item igual no carrinho
      const [existing] = await pool.execute(
        'SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? LIMIT 1',
        [cartId, it.product_id]
      );

      if (Array.isArray(existing) && existing.length > 0) {
        const current = existing[0];
        await pool.execute('UPDATE cart_items SET quantity = ? WHERE id = ?', [Number(current.quantity) + Number(it.quantity || 1), current.id]);
      } else {
        await pool.execute(
          'INSERT INTO cart_items (cart_id, product_id, name, price, image_url, quantity) VALUES (?,?,?,?,?,?)',
          [cartId, it.product_id, it.name, it.price, it.image_url, it.quantity || 1]
        );
      }
    }

    // Retornar carrinho atualizado
    const [cart] = await pool.execute('SELECT * FROM cart_items WHERE cart_id = ?', [cartId]);
    res.json({ items: cart });
  } catch (e) {
    console.error('Order reorder error', e);
    res.status(500).json({ error: 'order_reorder_failed' });
  }
});

app.post('/api/orders/:id/resend', async (req, res) => {
  try {
    const { id } = req.params;
    // Buscar pedido completo e usar email se existir
    const [orders] = await pool.execute('SELECT * FROM orders WHERE id = ? LIMIT 1', [id]);
    if (!Array.isArray(orders) || orders.length === 0) {
      return res.status(404).json({ error: 'order_not_found' });
    }
    const order = orders[0];

    // Buscar itens e enriquecer nome/imagem
    const [items] = await pool.execute('SELECT product_id, quantity, price FROM order_items WHERE order_id = ?', [id]);
    const productIds = [...new Set((items || []).map(i => i.product_id))];
    let productsMap = new Map();
    if (productIds.length > 0) {
      const placeholders = productIds.map(() => '?').join(',');
      const [pCols] = await pool.execute('DESCRIBE products');
      const pFields = Array.isArray(pCols) ? pCols.map(c => c.Field) : [];
      const nameCol = pFields.includes('nome') ? 'nome' : (pFields.includes('name') ? 'name' : null);
      const imgCol = pFields.includes('imagem_url') ? 'imagem_url'
                     : (pFields.includes('image_url') ? 'image_url'
                     : (pFields.includes('imagemUrl') ? 'imagemUrl'
                     : (pFields.includes('image') ? 'image' : null)));
      const selectNome = nameCol ? nameCol : "NULL";
      const selectImg = imgCol ? imgCol : "NULL";
      const [pRows] = await pool.query(`SELECT id, ${selectNome} AS nome, ${selectImg} AS imagem_url FROM products WHERE id IN (${placeholders})`, productIds);
      productsMap = new Map((pRows || []).map(r => [String(r.id), r]));
    }

    const normalizedItems = (items || []).map((it) => {
      const p = productsMap.get(String(it.product_id));
      return {
        product_id: it.product_id,
        name: p?.nome || 'Produto',
        image_url: p?.imagem_url ? getPublicUrl(req, p.imagem_url) : null,
        quantity: Number(it.quantity || 1),
        price: Number(it.price || 0),
        total: Number(it.price || 0) * Number(it.quantity || 1)
      };
    });

    const total = normalizedItems.reduce((acc, i) => acc + i.total, 0);
    const createdAt = order.created_at || new Date();
    const paymentMethod = order.payment_method || order.metodo_pagamento || '—';
    const html = `
<!doctype html>
<html><head><meta charset="utf-8"/><title>Comprovante do Pedido ${order.id}</title>
<style>
body{font-family:ui-sans-serif,system-ui,Arial,sans-serif;color:#111}
.wrap{max-width:640px;margin:24px auto;padding:24px;border:1px solid #eee;border-radius:12px}
.h{font-size:20px;font-weight:700;margin:0 0 8px}
.muted{color:#666}
.row{display:flex;align-items:center;gap:10px}
.item{display:flex;gap:12px;border-top:1px solid #eee;padding:12px 0}
.img{width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid #ddd}
.right{text-align:right;margin-left:auto}
.total{font-weight:700}
</style></head>
<body>
  <div class="wrap">
    <div class="h">Comprovante do Pedido ${order.id}</div>
    <div class="muted">Realizado em ${new Date(createdAt).toLocaleString('pt-BR')}</div>
    <div class="muted">Pagamento: ${paymentMethod.toUpperCase()}</div>
    <div style="margin:16px 0"></div>
    ${normalizedItems.map(i => `
      <div class="item">
        ${i.image_url ? `<img class="img" src="${i.image_url}" alt="${i.name}"/>` : '<div class="img" style="background:#f6f6f6"></div>'}
        <div>
          <div>${i.name}</div>
          <div class="muted">Qtd: ${i.quantity} • Unit: R$ ${i.price.toFixed(2)}</div>
        </div>
        <div class="right">R$ ${i.total.toFixed(2)}</div>
      </div>
    `).join('')}
    <div class="item" style="border-top:2px solid #ddd"></div>
    <div class="row">
      <div class="muted">Total</div>
      <div class="right total">R$ ${total.toFixed(2)}</div>
    </div>
  </div>
</body></html>`;

    // Envio real por SMTP, se configurado
    let sent = false;
    try {
      const h = process.env.SMTP_HOST;
      const u = process.env.SMTP_USER;
      const p = process.env.SMTP_PASS;
      const from = process.env.SMTP_FROM || 'no-reply@localhost';
      const to = (order.email && String(order.email)) || process.env.SMTP_TO || '';
      if (h && u && p && from && to) {
        const nodemailer = require('nodemailer');
        const transporter = nodemailer.createTransport({
          host: h,
          port: Number(process.env.SMTP_PORT || 587),
          secure: Boolean(process.env.SMTP_SECURE === 'true'),
          auth: { user: u, pass: p }
        });
        await transporter.sendMail({
          from,
          to,
          subject: `Comprovante do Pedido ${order.id}`,
          html
        });
        sent = true;
        console.log(`✉️  Comprovante enviado para ${to} (pedido ${order.id})`);
      } else {
        console.log('ℹ️ SMTP não configurado ou e-mail do pedido ausente. Pulando envio.');
      }
    } catch (err) {
      console.error('Falha ao enviar e-mail SMTP', err);
    }

    // Retornar resultado e preview (útil para debug/UI)
    console.log(`✉️  Comprovante gerado para pedido ${order.id} (${normalizedItems.length} itens)`);
    res.setHeader('Content-Type', 'application/json');
    res.json({ ok: true, emailed: sent, preview_html: html });
  } catch (e) {
    console.error('Order resend error', e);
    res.status(500).json({ error: 'order_resend_failed' });
  }
});

app.get('/api/orders/:id/timeline', async (req, res) => {
  try {
    const { id } = req.params;
    const [orders] = await pool.execute('SELECT id, status, created_at FROM orders WHERE id = ? LIMIT 1', [id]);
    if (!Array.isArray(orders) || orders.length === 0) {
      return res.status(404).json({ error: 'order_not_found' });
    }
    const order = orders[0];

    // Timeline simples baseada no status atual
    const createdAt = order.created_at || new Date();
    const base = [{ status: 'criado', at: createdAt }];
    const status = (order.status || 'criado').toLowerCase();
    if (status === 'processando') base.push({ status: 'processando', at: createdAt });
    if (status === 'em_transito' || status === 'em trânsito') base.push({ status: 'em_transito', at: createdAt });
    if (status === 'entregue') base.push({ status: 'em_transito', at: createdAt }, { status: 'entregue', at: createdAt });

    res.json(base);
  } catch (e) {
    console.error('Order timeline error', e);
    res.status(500).json({ error: 'order_timeline_failed' });
  }
});

// ==========================
// Frete: cotação simples por CEP e subtotal
// ==========================
app.post('/api/shipping/quote', async (req, res) => {
  try {
    const { cep, subtotal } = req.body || {};
    const sub = Number(subtotal || 0);
    // Regra simples: frete grátis acima de 200; caso contrário, base por região
    if (sub >= 200) {
      return res.json({ price: 0, estimated_days: 3, rule: 'free_over_200' });
    }
    // Heurística por prefixo de CEP
    const cepStr = String(cep || '').replace(/\D/g, '');
    const prefix = cepStr.slice(0, 2);
    let base = 19.9; // padrão
    let days = 5;
    if (["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49"].includes(prefix)) { // Sudeste/Sul aproximado
      base = 15.0; days = 4;
    }
    if (["50","51","52","53","54","55","56","57","58","59","60","61","62","63","64","65","66","67","68","69"].includes(prefix)) { // Centro-Oeste/Norte
      base = 24.9; days = 7;
    }
    if (["70","71","72","73","74","75","76","77","78","79","80","81","82","83","84","85","86","87","88","89","90","91","92","93","94","95","96","97","98","99"].includes(prefix)) { // Nordeste/Norte
      base = 29.9; days = 8;
    }
    res.json({ price: Number(base.toFixed(2)), estimated_days: days, rule: 'region_base' });
  } catch (e) {
    console.error('Shipping quote error', e);
    res.status(500).json({ error: 'shipping_quote_failed' });
  }
});

// ==========================
// Cupons: validação simples
// ==========================
app.post('/api/coupons/validate', async (req, res) => {
  try {
    const { code, subtotal } = req.body || {};
    const normalized = String(code || '').trim().toUpperCase();
    const sub = Number(subtotal || 0);
    if (!normalized) return res.status(400).json({ valid: false, reason: 'empty' });

    if (normalized === 'FRETEGRATIS') {
      if (sub >= 50) {
        return res.json({ valid: true, type: 'shipping_free', min_subtotal: 50 });
      }
      return res.json({ valid: false, reason: 'min_subtotal', min_subtotal: 50 });
    }

    // Percentual: PERCENT10 => 10% de desconto sobre o subtotal
    const percentMatch = normalized.match(/^PERCENT(\d{1,2})$/);
    if (percentMatch) {
      const pct = Math.max(0, Math.min(90, Number(percentMatch[1])));
      if (pct > 0) {
        return res.json({ valid: true, type: 'percent', percent: pct });
      }
    }

    // Valor fixo: OFF50 => R$ 50,00 de desconto (limitado ao subtotal)
    const amountMatch = normalized.match(/^OFF(\d{1,4})$/);
    if (amountMatch) {
      const amount = Math.max(1, Math.min(1000, Number(amountMatch[1])));
      if (amount > 0) {
        return res.json({ valid: true, type: 'amount', amount });
      }
    }

    // Placeholder para mais cupons
    return res.json({ valid: false, reason: 'not_found' });
  } catch (e) {
    console.error('Coupon validate error', e);
    res.status(500).json({ error: 'coupon_validate_failed' });
  }
});

// ==========================
// Conta: alteração de senha (simulado)
// ==========================
app.post('/api/account/password', async (req, res) => {
  try {
    const { senhaAtual, novaSenha } = req.body || {};
    if (!novaSenha || String(novaSenha).length < 6) {
      return res.status(400).json({ ok: false, error: 'weak_password' });
    }
    // Em um cenário real: validar senhaAtual contra hash do usuário autenticado e persistir hash da nova senha.
    console.log('🔐 Alteração de senha solicitada');
    return res.json({ ok: true });
  } catch (e) {
    console.error('Change password error', e);
    res.status(500).json({ ok: false, error: 'change_password_failed' });
  }
});

// ========== ENDPOINTS WHATSAPP ==========

// Endpoint para obter configurações WhatsApp
app.get('/api/whatsapp/config', async (req, res) => {
  try {
    const [settingsRows] = await pool.execute(`
      SELECT key_name, value_text 
      FROM settings 
      WHERE key_name IN ('whatsapp_webhook_url', 'whatsapp_token', 'whatsapp_phone_id', 'whatsapp_webhook_secret', 'whatsapp_auto_reply', 'whatsapp_welcome_message')
    `);
    
    const settings = {};
    settingsRows.forEach(row => {
      settings[row.key_name] = row.value_text;
    });

    res.json({
      success: true,
      config: {
        webhook_url: settings.whatsapp_webhook_url || '',
        token: settings.whatsapp_token ? '***' + settings.whatsapp_token.slice(-4) : '',
        phone_id: settings.whatsapp_phone_id || '',
        webhook_secret: settings.whatsapp_webhook_secret ? '***' + settings.whatsapp_webhook_secret.slice(-4) : '',
        auto_reply: settings.whatsapp_auto_reply === 'true',
        welcome_message: settings.whatsapp_welcome_message || 'Olá! Como posso ajudá-lo hoje?'
      }
    });
  } catch (e) {
    console.error('WhatsApp config error', e);
    res.status(500).json({ error: 'config_fetch_failed' });
  }
});

// Endpoint para salvar configurações WhatsApp
app.put('/api/whatsapp/config', async (req, res) => {
  try {
    const { webhook_url, token, phone_id, webhook_secret, auto_reply, welcome_message } = req.body;

    const settings = [
      ['whatsapp_webhook_url', webhook_url],
      ['whatsapp_token', token],
      ['whatsapp_phone_id', phone_id],
      ['whatsapp_webhook_secret', webhook_secret],
      ['whatsapp_auto_reply', auto_reply ? 'true' : 'false'],
      ['whatsapp_welcome_message', welcome_message]
    ];

    for (const [key, value] of settings) {
      if (value !== undefined) {
        await pool.execute(`
          INSERT INTO settings (key_name, value_text, updated_at) 
          VALUES (?, ?, NOW()) 
          ON DUPLICATE KEY UPDATE value_text = VALUES(value_text), updated_at = NOW()
        `, [key, value]);
      }
    }

    res.json({ success: true, message: 'Configurações WhatsApp salvas com sucesso!' });
  } catch (e) {
    console.error('WhatsApp config save error', e);
    res.status(500).json({ error: 'config_save_failed' });
  }
});

// Endpoint para testar webhook WhatsApp
app.post('/api/whatsapp/test-webhook', async (req, res) => {
  try {
    const { webhook_url } = req.body;
    
    if (!webhook_url) {
      return res.status(400).json({ error: 'URL do webhook é obrigatória' });
    }

    // Simular teste do webhook
    const testData = {
      test: true,
      message: 'Teste de webhook realizado com sucesso!',
      timestamp: new Date().toISOString()
    };

    // Aqui você faria uma requisição real para testar o webhook
    // const response = await fetch(webhook_url, { method: 'POST', body: JSON.stringify(testData) });

    res.json({ 
      success: true, 
      message: 'Webhook testado com sucesso!',
      test_data: testData
    });
  } catch (e) {
    console.error('WhatsApp webhook test error', e);
    res.status(500).json({ error: 'webhook_test_failed' });
  }
});

// Endpoint para obter estatísticas WhatsApp
app.get('/api/whatsapp/stats', async (req, res) => {
  try {
    // Verificar se a tabela existe
    const [tableExists] = await pool.execute(`
      SELECT COUNT(*) as count 
      FROM information_schema.tables 
      WHERE table_schema = DATABASE() AND table_name = 'whatsapp_messages'
    `);

    if (tableExists[0].count === 0) {
      return res.json({
        success: true,
        stats: {
          total_messages: 0,
          incoming_messages: 0,
          outgoing_messages: 0,
          unique_contacts: 0,
          messages_today: 0
        }
      });
    }

    const [stats] = await pool.execute(`
      SELECT 
        COUNT(*) as total_messages,
        COUNT(CASE WHEN direction = 'incoming' THEN 1 END) as incoming_messages,
        COUNT(CASE WHEN direction = 'outgoing' THEN 1 END) as outgoing_messages,
        COUNT(DISTINCT from_phone) as unique_contacts,
        COUNT(CASE WHEN DATE(timestamp) = CURDATE() THEN 1 END) as messages_today
      FROM whatsapp_messages
    `);

    res.json({ success: true, stats: stats[0] });
  } catch (e) {
    console.error('WhatsApp stats error', e);
    res.status(500).json({ error: 'stats_fetch_failed' });
  }
});

// Endpoint para enviar mensagem WhatsApp
app.post('/api/whatsapp/send-message', async (req, res) => {
  try {
    const { to, message } = req.body;
    
    if (!to || !message) {
      return res.status(400).json({ error: 'Número e mensagem são obrigatórios' });
    }

    // Buscar token WhatsApp
    const [tokenRows] = await pool.execute('SELECT value_text FROM settings WHERE key_name = ?', ['whatsapp_token']);
    const [phoneIdRows] = await pool.execute('SELECT value_text FROM settings WHERE key_name = ?', ['whatsapp_phone_id']);
    
    if (tokenRows.length === 0 || phoneIdRows.length === 0) {
      return res.status(400).json({ error: 'Token ou Phone ID do WhatsApp não configurados' });
    }

    const token = tokenRows[0].value_text;
    const phoneId = phoneIdRows[0].value_text;

    // Enviar mensagem via WhatsApp API
    const response = await fetch(`https://graph.facebook.com/v18.0/${phoneId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: to,
        type: 'text',
        text: { body: message }
      })
    });

    if (!response.ok) {
      throw new Error('Falha ao enviar mensagem via WhatsApp API');
    }

    const result = await response.json();

    res.json({ 
      success: true, 
      message: 'Mensagem enviada com sucesso!',
      whatsapp_response: result
    });
  } catch (e) {
    console.error('WhatsApp send message error', e);
    res.status(500).json({ error: 'message_send_failed' });
  }
});

// Endpoint para obter mensagens WhatsApp
app.get('/api/whatsapp/messages', async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;

    // Verificar se a tabela existe
    const [tableExists] = await pool.execute(`
      SELECT COUNT(*) as count 
      FROM information_schema.tables 
      WHERE table_schema = DATABASE() AND table_name = 'whatsapp_messages'
    `);

    if (tableExists[0].count === 0) {
      return res.json({
        success: true,
        messages: [],
        pagination: { page: 1, limit, total: 0, pages: 0 }
      });
    }

    const [messages] = await pool.execute(`
      SELECT * FROM whatsapp_messages 
      ORDER BY timestamp DESC 
      LIMIT ? OFFSET ?
    `, [parseInt(limit), parseInt(offset)]);

    const [totalRows] = await pool.execute('SELECT COUNT(*) as total FROM whatsapp_messages');
    const total = totalRows[0].total;

    res.json({
      success: true,
      messages,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (e) {
    console.error('WhatsApp messages error', e);
    res.status(500).json({ error: 'messages_fetch_failed' });
  }
});

// ==========================
// Conta: atualização de perfil (simulado)
// ==========================
app.post('/api/account/profile', async (req, res) => {
  try {
    const { nome, email, telefone, avatar_url, endereco, cidade, estado, cep } = req.body || {};
    // Em um cenário real: atualizar tabela users vinculada ao auth
    console.log('👤 Atualização de perfil:', { nome, email, telefone });
    // Devolver os dados normalizados para o frontend atualizar contexto
    res.json({ ok: true, user: { nome, email, telefone, avatar_url, endereco, cidade, estado, cep } });
  } catch (e) {
    console.error('Profile update error', e);
    res.status(500).json({ ok: false, error: 'profile_update_failed' });
  }
});

// ==========================
// Auth simulado: me/logout para persistir sessão com cookie
// ==========================
app.get('/api/auth/me', async (req, res) => {
  try {
    const email = req.cookies?.mock_email;
    if (email) {
      return res.json({ authenticated: true, user: { email } });
    }
    res.json({ authenticated: false });
  } catch (e) {
    res.json({ authenticated: false });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email } = req.body || {};
    if (!email) return res.status(400).json({ ok: false, error: 'missing_email' });
    res.cookie('mock_email', email, { httpOnly: false, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false });
  }
});

app.post('/api/auth/logout', async (req, res) => {
  try {
    res.clearCookie('mock_email');
    res.json({ ok: true });
  } catch (e) {
    res.json({ ok: true });
  }
});
